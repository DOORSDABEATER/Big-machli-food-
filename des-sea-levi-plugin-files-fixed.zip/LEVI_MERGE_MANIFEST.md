# Leviathan merge manifest

This package is the existing `des-sea-build` project with the targeted files from
`levi-update` overlaid into their corresponding project locations.

## Added in their correct locations
- `modelengine/blueprints/levi.bbmodel` — ModelEngine main Levi blueprint.
- `modelengine/blueprints/levi_abyssal_spawn.bbmodel` — ModelEngine Abyssal Spawn blueprint.
- `mythic/Mobs/levi.yml` — MythicMobs definitions for Levi and the Abyssal Spawn.
- `LEVI.md` — Levi model, animation, attack and deployment notes.

## Updated integration files
- `src/main/java/com/des/sea/model/ModelBridge.java` — ModelEngine bridge.
- `src/main/java/com/des/sea/DesSeaPlugin.java` — initializes/exposes ModelBridge.
- `src/main/java/com/des/sea/boss/engine/BossEngine.java` — attaches models and plays configured animations.
- `src/main/java/com/des/sea/boss/LeviEncounter.java` — waits for the emergence/intro before revealing the title.
- `src/main/resources/bosses/levi.yml` — adds model, scale, emergence and animation settings to Levi's boss definition.
- `src/main/resources/config.yml` — adds ModelEngine settings and the Levi MythicMobs spawn command.
- `tools/` — Levi model generator and its helper/validation scripts; boss config generator updated.

## Preserved
- The existing sea expansion source, resources, resource pack, datapack, and unrelated mobs/assets.
- The uploaded standalone `levi.bbmodel`, `levi_abyssal_spawn.bbmodel`, and `levi.yml` were checked against the copies inside `levi-update`; they are identical.
- Existing resource-pack files were not replaced. The separately uploaded resource pack is already contained in the build (with 34 additional files in the build), and its overlapping files match byte-for-byte.
- The separate datapack is already present in the build; its biome files match.

## Deployment note
Copy the two `.bbmodel` blueprints into the server's `plugins/ModelEngine/blueprints/`
folder and import/reload them using the ModelEngine workflow supported by the installed version.
Copy `mythic/Mobs/levi.yml` into `plugins/MythicMobs/Mobs/`, then reload MythicMobs.
Build the plugin from this merged source and test on a staging server first.

The update package itself marks some ModelEngine/MythicMobs API and command syntax as
unverified. Confirm those against the exact installed plugin versions before a live boss fight.
