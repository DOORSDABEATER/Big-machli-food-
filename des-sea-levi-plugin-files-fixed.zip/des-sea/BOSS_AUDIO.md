# Boss Sound Events (all need .ogg files + sounds.json entries)

Pattern: des_sea:boss.<boss>.<event>

## levi
intro, defeat, enrage, phase1, phase2, phase3, phase4, phase5, abyssal_gaze.windup, abyssal_gaze.strike, undertow.windup, undertow.strike, crushing_wake.windup, crushing_wake.strike, devouring_charge.windup, devouring_charge.strike, abyssal_coil.windup, abyssal_coil.strike, depth_breaker.windup, depth_breaker.strike, tidal_collapse.windup, tidal_collapse.strike, black_current.windup, black_current.strike, call_of_the_deep.windup, call_of_the_deep.strike, abyssal_roar.windup, abyssal_roar.strike, worldbreaker.windup, worldbreaker.strike, devouring_depths.windup, devouring_depths.strike, leviathans_wrath.windup, leviathans_wrath.strike, rupture.windup, rupture.strike, final_descent.windup, final_descent.strike, sovereigns_maw.windup, sovereigns_maw.strike, last_cataclysm.windup, last_cataclysm.strike

## krakthor
intro, defeat, enrage, phase1, phase2, phase3, tentacle_slam.windup, tentacle_slam.strike, tentacle_sweep.windup, tentacle_sweep.strike, ink_cloud.windup, ink_cloud.strike, tentacle_grab.windup, tentacle_grab.strike, crushing_coil.windup, crushing_coil.strike, maelstrom.windup, maelstrom.strike, wreck_rain.windup, wreck_rain.strike, abyssal_whirlpool.windup, abyssal_whirlpool.strike, devouring_surge.windup, devouring_surge.strike

## thalzar
intro, defeat, enrage, phase1, phase2, phase3, royal_decree.windup, royal_decree.strike, tidal_prison.windup, tidal_prison.strike, summon_guards.windup, summon_guards.strike, flood_surge.windup, flood_surge.strike, crown_wave.windup, crown_wave.strike, sovereigns_edict.windup, sovereigns_edict.strike, drowning_court.windup, drowning_court.strike, throne_cracks.windup, throne_cracks.strike

## nyxara
intro, defeat, enrage, phase1, phase2, phase3, darkness_veil.windup, darkness_veil.strike, shadow_spawn.windup, shadow_spawn.strike, gaze_of_nothing.windup, gaze_of_nothing.strike, corrupted_call.windup, corrupted_call.strike, void_embrace.windup, void_embrace.strike, eclipse.windup, eclipse.strike, distortion.windup, distortion.strike, mothers_wail.windup, mothers_wail.strike

## orovax
intro, defeat, enrage, phase1, phase2, phase3, colossus_stomp.windup, colossus_stomp.strike, tremor.windup, tremor.strike, magma_lines.windup, magma_lines.strike, geyser_pull.windup, geyser_pull.strike, eruption.windup, eruption.strike, tremor_chain.windup, tremor_chain.strike

## drowned_admiral
intro, defeat, enrage, phase1, phase2, ghostly_broadside.windup, ghostly_broadside.strike, anchor_hook.windup, anchor_hook.strike, spectral_crew.windup, spectral_crew.strike, cutlass_arc.windup, cutlass_arc.strike

## the_lightless
intro, defeat, enrage, phase1, phase2, dark_pulse.windup, dark_pulse.strike, lightless_charge.windup, lightless_charge.strike, blackout.windup, blackout.strike

## coral_colossus
intro, defeat, enrage, phase1, phase2, coral_slam.windup, coral_slam.strike, spore_burst.windup, spore_burst.strike, root_lines.windup, root_lines.strike

## vesper_the_pale
intro, defeat, enrage, phase1, phase2, frost_breath.windup, frost_breath.strike, ice_spikes.windup, ice_spikes.strike, whiteout.windup, whiteout.strike, glacial_crash.windup, glacial_crash.strike

## abyssal_stalker_alpha
intro, defeat, enrage, phase1, lunge.windup, lunge.strike, shriek.windup, shriek.strike

## reef_breaker
intro, defeat, enrage, phase1, claw_slam.windup, claw_slam.strike, shell_charge.windup, shell_charge.strike

## siren_matriarch
intro, defeat, enrage, phase1, lure_song.windup, lure_song.strike, call_of_the_deep.windup, call_of_the_deep.strike, shriek.windup, shriek.strike

## shipwreck_guardian
intro, defeat, enrage, phase1, anchor_slam.windup, anchor_slam.strike, bilge_wave.windup, bilge_wave.strike

## deepwater_devourer
intro, defeat, enrage, phase1, gulp.windup, gulp.strike, maw_charge.windup, maw_charge.strike

## ancient_shellback
intro, defeat, enrage, phase1, shell_slam.windup, shell_slam.strike, tremor.windup, tremor.strike

