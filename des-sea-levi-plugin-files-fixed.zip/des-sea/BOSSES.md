# Boss Designs

All numbers are first-pass and untested. Boss behaviour is driven by the plugin's boss engine (data in `bosses/*.yml`).
Models and animations come from ModelEngine; sound events are listed in BOSS_AUDIO.md.

## LEVI, THE SOVEREIGN BENEATH
*Legendary (ritual-summoned). Concept, five phases, attack names, nodes/structures/core rules and rewards are exactly as established; the numbers and how each named attack plays are the new design.*

- Watcher (100-80%): orbits at range. Gaze = slow cyan beam sweep (break line of sight); Undertow = vortex at his maw; Crushing Wake = low shockwave from the tail (swim above/below it).
- Hunter (80-60%): chases. Devouring Charge = long telegraphed dash; Abyssal Coil = constricts two divers (damage him to break free); Depth Breaker = overhead slam on a marked circle.
- Sovereign (60-35%): untouchable until 3 Abyssal Nodes are destroyed. Tidal Collapse = double shockwave; Black Current = arena-wide push; Call of the Deep = spawn adds; Abyssal Roar = knockback + slow.
- Catastrophe (35-10%): Tidebound Shelters must be right-clicked to activate (they time out). Worldbreaker / Devouring Depths are lethal outside an active shelter. Leviathan's Wrath = 360 degree beam; Rupture = floor lines.
- Last Tide (10-0%): Core Plates shield him. Breaking all four exposes the core for a 10 second x2.5 damage window, then they regrow. Final Descent, Sovereign's Maw (pull, lethal near the mouth), Last Cataclysm (3 shockwave rings).

Base health 4500 (at 4 players), enrage 1080s, VFX colour #22d3ee + SOUL_FIRE_FLAME.

## KRAK'THOR, THE WORLD DEVOURER
*Ship Graveyard. Six independent, killable tentacles; the body is only vulnerable after they are cut.*

- Lurker (100-70%): tentacles slam and sweep. They are separate targets: cut them down to thin his attacks. Ink Cloud blinds the arena.
- Devourer (70-35%): body is shielded. Tentacle Grab pins and drags two players to the maw (damage him to free them). Cutting all six tentacles opens a 8.5s x2 window, then they regrow.
- World Devourer (35-0%): Hull Fragments (wreck cover, right-click to brace) are the only protection from Abyssal Whirlpool's lethal core. Wreck Rain drops debris lines; Devouring Surge sends rings.

Base health 4000 (at 4 players), enrage 900s, VFX colour #9f1239 + SQUID_INK.

## THAL'ZAR, THE DROWNED KING
*Drowned Kingdom throne room. A duelist-king with a guard court and spoken voice lines at every stage.*

- The Court (100-65%): fights up close. Royal Decree (scepter cone), Tidal Prison (slows a marked circle), calls guards.
- Wrath of the Tides (65-30%): Tide Pillars must be right-clicked to activate; Crown Wave is lethal outside one. Flood Surge shoves everyone.
- The Last Royal (30-0%): three Crown Shards shield him; breaking them opens a x2.2 window, then they re-form. Edict beam, Drowning Court vortex, cracking floor.

Base health 4200 (at 4 players), enrage 960s, VFX colour #eab308 + SOUL.

## NYXARA, THE LIGHTLESS MOTHER
*Black Trench. A darkness-and-illusion fight; light is the resource.*

- Veil (100-70%): darkness fills the arena. Lanterns (right-click) are your only safe light. Shadows and a sweeping gaze.
- Mother of Mirrors (70-35%): she is shielded by three Shadow Anchors (the illusions); break them, then keep a Lantern lit for Eclipse (lethal in the dark).
- Lightless Mother (35-0%): constant Eclipse, environment-bending currents, Void Embrace. Light is everything.

Base health 3800 (at 4 players), enrage 960s, VFX colour #312e81 + LARGE_SMOKE.

## OROVAX, THE TIDAL COLOSSUS
*Volcanic Expanse arena. A slow, heavy, environment-driven fight.*

- Awakened Stone (100-66%): stomps, ground-hugging shockwaves, magma lines across the floor.
- Coral Carapace (66-33%): four Carapace Plates shield him; breaking them opens a 10s x2.2 window, then regrows.
- Eruption (33-0%): Obsidian Shells (right-click to brace) are the only cover from Eruption (lethal). Triple tremor rings.

Base health 5000 (at 4 players), enrage 1000s, VFX colour #f97316 + LAVA.

## DROWNED ADMIRAL
*Forgotten Waters / Ghost Fleet. Roaming guardian of the ghost ships.*

- Phase 1 close-quarters cone and anchor hook that drags a diver in; phase 2 adds broadsides across the water and a ghostly crew.

Base health 1800 (at 4 players), enrage 600s, VFX colour #34d399 + SOUL.

## THE LIGHTLESS
*Black Trench regional boss. Hunts in total darkness.*

- Blacks out the arena then charges from the dark; pulses push divers off.

Base health 2200 (at 4 players), enrage 600s, VFX colour #0f172a + LARGE_SMOKE.

## CORAL COLOSSUS
*Verdant Reef regional boss. A walking reef.*

- Shielded by three Coral Hearts (window when broken); root lines cross the floor.

Base health 2400 (at 4 players), enrage 600s, VFX colour #fb7185 + BUBBLE_POP.

## VESPER, THE PALE
*Frozen Abyss regional boss. Slows and shatters.*

- Frost cone and spikes; below 50% a whiteout current pushes divers around the cavern.

Base health 2600 (at 4 players), enrage 600s, VFX colour #bae6fd + SNOWFLAKE.

## ABYSSAL STALKER ALPHA
*Roaming mini-boss in the Black Trench.*

- Fast lunges from the dark.

Base health 900 (at 4 players), enrage 600s, VFX colour #0ea5e9 + SQUID_INK.

## REEF BREAKER
*Mini-boss that wrecks reef structures (not your builds).*

- Slams and shell charges.

Base health 1000 (at 4 players), enrage 600s, VFX colour #f43f5e + BUBBLE_POP.

## SIREN MATRIARCH
*Mini-boss. Lures divers with song.*

- Pulls divers in and summons thralls.

Base health 1100 (at 4 players), enrage 600s, VFX colour #a78bfa + GLOW.

## SHIPWRECK GUARDIAN
*Structure guardian of sunken ships.*

- Slams and shockwaves while you loot.

Base health 1300 (at 4 players), enrage 600s, VFX colour #94a3b8 + SOUL.

## DEEPWATER DEVOURER
*Rare roaming mini-boss.*

- Gulp pull with a bite at the center.

Base health 1500 (at 4 players), enrage 600s, VFX colour #1d4ed8 + SQUID_INK.

## ANCIENT SHELLBACK
*Neutral giant that fights only when provoked.*

- Slow heavy slams.

Base health 1400 (at 4 players), enrage 600s, VFX colour #84cc16 + BUBBLE_POP.

