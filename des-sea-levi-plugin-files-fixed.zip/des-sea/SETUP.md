# DeS Sea Rework - Setup and Test Guide

Status: written but NEVER compiled or run. Work on a COPY of your server first, with a full backup of the live world.

## 1. Build
1. Install a JDK matching your server's Java (the build file assumes 25; edit `build.gradle.kts` if different).
2. Check `build.gradle.kts`: the `paper-api:26.2.build.+` coordinate is a guess. Confirm it on repo.papermc.io.
3. `gradle build` -> jar in `build/libs/`. Fix any compile errors (send them to Claude).
   Known risk spots if 26.2 differs: `Player#getCurrentInput()`, `TeleportFlag.EntityState.RETAIN_PASSENGERS`,
   `ItemMeta#setItemModel`, `getPluginMeta()`, `Bukkit#getTPS()`.

## 2. First start
1. Drop the jar into `plugins/` on the TEST server and start it. All gameplay modules are OFF by default.
2. Open `plugins/DeSSea/compat-report.txt` and send it with any errors from the console.
3. In game: `/dessea status`, `/dessea report`.

## 3. Resource pack and datapack (ALREADY GENERATED)
The finished assets are in `resourcepack/` and `datapack/` (zips: `build/des_sea_resourcepack.zip`, `build/des_sea_datapack.zip`).
Regenerate any time with `python3 tools/gen_assets.py --pack-format <N>` (needs Pillow, numpy, scipy, PyYAML, ffmpeg) and check with `python3 tools/validate_pack.py`.
Merge `resourcepack/assets/des_sea` into your existing DeS pack (and the two `minecraft/blockstates` notes below). The zip's own pack.mcmeta is only for standalone testing.

(Older manual steps, still valid if you only want blocks/models:)
1. `python3 tools/gen_blocks.py` (only if you edit the block list), then `python3 tools/build_pack.py --pack-format <N>` (N = your client's resource pack format; also used for the datapack).
2. Merge `build/resourcepack/assets/des_sea/**` into your existing DeS pack. Do not overwrite your pack.
3. `build/resourcepack/assets/minecraft/blockstates/` REPLACES vanilla blockstates for `note_block` and the 20 coral/coral-fan blocks (custom blocks ride on them: every vanilla coral now looks like a custom plant). MERGE by hand if your pack already has any of these files. The note_block file lists every vanilla note state; if a state is missing in your version it shows the missing texture.
4. Copy `pack-src/datapack/data/des_sea` into the world's datapacks folder. Watch the console for datapack errors:
   the biome JSON follows the 1.21-era format and may need changes for 26.2.
5. The generator lists missing textures. Missing art shows as the missing-texture pattern in game.

## 4. Enable modules ONE AT A TIME (`config.yml`, then `/dessea reload`)
Test each before moving on. Order suggested:
1. `journal` then `journal_gui` (`/journal`). Walk into a des_sea biome to test discovery.
2. `structures` (`/dessea structure preview <type>`). Also set `world.allowed-worlds`. Nothing places blocks yet.
3. `events` (`/dessea event start crystal_surge`).
4. `crystal_depths` (ambience in the biome).
5. `vehicles` (`/dessea vehicle give <you> jet_boat`, right-click water). Check smoothness and tune speeds.
6. `creatures`: needs `spawns.spawn-command` and the MythicMobs files (see 5).
7. `levi` and `bosses`: need spawn commands, tagged MythicMobs mobs, an altar/arena (`/dessea boss altar <boss>`).

### Structures: capture, place, roll back (test world only!)
1. Build a structure by hand in a creative test area. Stand at one corner: `/dessea structure pos1`; opposite corner: `pos2`.
2. `/dessea structure capture <template-name>` saves `plugins/DeSSea/templates/<name>.tpl.gz`. Name it exactly like a structure type (e.g. `crystal_hollow`) to spawn it by type.
3. `/dessea structure preview <type>` shows what would block a placement. `/dessea structure rotate <type> 90` sets the next rotation.
4. `/dessea structure spawn <type>` places it, centred on you. It refuses unless every overwritten block is on `structures.replaceable`, and it saves a rollback snapshot first.
5. `/dessea structure remove <id> confirm` rolls the blocks back. `regenerate <id> confirm` rolls back then places again.
6. Placement is blocked until a claim-plugin check exists. On a test world with no claims set `structures.require-claim-check: false`. Never on the live world.
7. Not captured/restored: chests and other inventories, entities, signs' text. Rotation uses `BlockData#rotate`, unverified on 26.2.

### Lost Cargo and Ghost Fleet events
1. Capture a template named `lost_cargo` (and `ghost_ship`) with the structure tools above. Put chests/barrels in it EMPTY.
2. Provide loot tables in a datapack and set `events.lost_cargo.loot-table`. Empty chests near the placement get that table.
3. Set `events.<id>.enabled: true`. Test first with `/dessea event start lost_cargo` (needs a player in an allowed world, and `world.allowed-worlds` filled).
4. Structures are rolled back automatically when the event ends; leftovers after a crash are cleaned up on the next start.

### Levi, step by step (model + attacks)
1. Copy `modelengine/blueprints/levi.bbmodel` and `levi_abyssal_spawn.bbmodel` to `plugins/ModelEngine/blueprints/`, run `/meg reload`; add the generated model resources to your pack as ModelEngine instructs.
2. Copy `mythic/Mobs/levi.yml` to `plugins/MythicMobs/Mobs/`, run `/mm reload`.
3. Enable `modules.levi`, `boss_engine`, `items`, `journal`, `bosses` (adds), then `/dessea reload`.
4. Stand at the altar spot: `/dessea boss altar levi`. Test the whole fight with `/dessea boss spawn levi` (skips the ritual).
5. Watch the console for "[ModelEngine bridge]" warnings on first spawn and send them if any appear. Read `LEVI.md` for what each animation does and what could not be verified.

### Bosses (engine)
1. Enable `modules.boss_engine: true`, `modules.items: true`, `modules.journal: true`, and `modules.levi` and/or `modules.bosses`.
2. `bosses/*.yml` are copied to `plugins/DeSSea/bosses/` on first start. Edit them live; `/dessea reload` re-reads them. They are generated from `tools/gen_bosses.py`.
3. Create each boss as a MythicMobs mob (+ ModelEngine model). It must apply the scoreboard tag `des_boss_<id>` (Levi: `des_levi`). Summoned adds must carry `des_add_<boss id>`. Set `spawn-command` and `engine.add-command`.
4. Stand at the arena centre: `/dessea boss altar <id>`; then `/dessea boss spawn <id>`.
5. The engine drives the boss (movement by teleport, attacks, health). It sets the mob to NoAI. Boss health is a virtual pool: base health x (4-8 players -> 1.0-2.0).
6. The engine never edits blocks. Right-click Shelters (Interaction entities) to activate; destroy Nodes (invisible shulkers with a pack model) to drop shields.
7. After a restart mid-fight the boss is re-attached with full health.

### Ecosystem and events
- `modules.behaviors: true` adds schooling/fleeing/predator behaviour to tagged creatures (rules in `behaviors.defs`).
- Volcanic Awakening needs vents: stand on a vent and run `/dessea vent add`. Events never change blocks.
- Whale Migration and Volcanic creatures use `spawns.spawn-command`. Great Hunt needs `modules.bosses`, `modules.boss_engine` and the boss's spawn command.
- Test any event with `/dessea event start <name>`.

### Custom blocks and terrain
1. `modules.blocks: true` then `/dessea block list`, `/dessea block give <you> crystal_seabed`, place and break it. `/dessea block set <id>` swaps the block you look at (testing).
2. Terrain: `modules.terrain: true` (needs `blocks`), fill `world.allowed-worlds`, keep `terrain.biomes: [crystal_depths]` for the first test. ONLY newly generated ocean chunks change. Fly into unexplored ocean to test, never on explored chunks.
3. `/dessea biome locate crystal_depths` shows the nearest region centre. `/dessea biome regenerate <name> confirm` only re-applies chunks the plugin itself generated and that players have not explored.
4. Add more biomes to `terrain.biomes` by APPENDING (the order decides the layout). Black Trench carves the seabed up to 28 blocks.
5. Volcanic regions register vents automatically for the Volcanic Awakening event.
6. Limits: custom blocks mine at the carrier's speed (note block / coral), glow uses invisible light blocks, and terrain never crosses chunk borders (big structures come from templates).

## 5. MythicMobs
Copy `mythic/Mobs/des_crystal_depths.yml` into MythicMobs' Mobs folder, `/mm reload`, and check every line:
syntax was written from memory for 5.14.0. Mobs must apply the tags `des_creature`, `des_mob_<name>`;
bosses must apply `des_boss_<id>` (Levi: `des_levi`).

## 6. Safety rules
- Never enable worldgen/structure modules on the live world before testing on a copy.
- Structure placement is blocked until a claim-plugin check exists, by design.
- Admin actions are logged with an [AUDIT] prefix in the console.
