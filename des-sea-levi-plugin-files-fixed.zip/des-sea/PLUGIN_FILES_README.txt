DeS Sea + Leviathan — Separate Plugin Files

This package contains the DeS Sea Java plugin SOURCE project and the separate
plugin-side integration files. It intentionally does NOT contain the resource
pack or datapack; those are supplied as separate downloads.

CONTENTS
- src/main/java/                 DeS Sea plugin Java source
- src/main/resources/            plugin.yml, config.yml, blocks.yml, boss configs
- build.gradle.kts              Gradle build definition
- modelengine/blueprints/        levi.bbmodel and levi_abyssal_spawn.bbmodel
- mythic/Mobs/levi.yml           MythicMobs Levi + Abyssal Spawn definitions
- tools/                         project generators and validation scripts
- SETUP.md / LEVI.md             build, installation and testing instructions

IMPORTANT: This is NOT a compiled .jar. The source project has not been compiled
or runtime-tested. Build it with the required JDK/Gradle after verifying the
Paper API dependency in build.gradle.kts. The setup guide documents known
unverified compatibility points.

SERVER DESTINATIONS
1. Build the Java project; place the resulting JAR from build/libs/ into
   the server's plugins/ folder.
2. Copy modelengine/blueprints/*.bbmodel into
   plugins/ModelEngine/blueprints/ and follow the installed ModelEngine version's
   import/reload workflow.
3. Copy mythic/Mobs/levi.yml into plugins/MythicMobs/Mobs/ and reload MythicMobs.
4. The plugin's own defaults/configs are packaged from src/main/resources when
   building. Live generated configs are under plugins/DeSSea/ after first start.

Do not overwrite a live server installation without a backup. Test on a staging
server first. Keep the separately supplied resource pack and datapack separate.
