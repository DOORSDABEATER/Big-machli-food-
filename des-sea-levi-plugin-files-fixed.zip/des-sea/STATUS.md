# DeS Abyssal Expansion - Build Status

Legend: CODE = plugin code written, never compiled or run. NEEDS = blocked on something only you can provide. NONE = not started.
Nothing here is verified. "Done" means "written", not "works".

## Spec section -> status
| Spec | Status |
|---|---|
| 1A Custom (non-vanilla) environments | Custom terrain for new ocean chunks in all 8 biomes via a post-generation populator (CODE): custom seabeds, crystal spires/clusters, coral trees, volcanoes (auto-registered vents), ice pillars, glowing kelp/mushrooms, Black Trench carving, ship wrecks, kingdom ruins. Textures generated (procedural) |
| 1B Animation (ModelEngine) | NEEDS .bbmodel files and animations (creatures, bosses). Static cuboid vehicle/boss-part models are generated; no skeletal animation exists yet |
| 1C Custom VFX | Placeholder vanilla particles in events/ambience (CODE). Real VFX: NEEDS art/shaders |
| 1D Custom sound | 123 synthesized sound files and 284 sound events generated and wired (CODE+ASSET, procedural quality). Recorded/designed audio would be better |
| 2 Biomes | Region layout, terrain and vegetation for all 8 (CODE). Only crystal_depths has a datapack biome JSON (fog/water colours/ambience, format unverified); the other 7 biome JSONs: NONE (terrain still works, biome tag unchanged until they exist) |
| 3 Wildlife | Spawner with caps/rare cooldown, 5 Crystal Depths mob files, creature discovery (CODE). Ecosystem behaviours: schooling, fleeing players/bosses/predators, predators hunting prey, Blood Tide aggression, whale migration (CODE, velocity-based, untuned). Resting in caves: NONE. Models: NEEDS |
| 4 Legendary bosses | All 5 designed (BOSSES.md) and playable through the boss engine: phases, telegraphed attacks, shields/windows/shelters, scaled health, boss bar, rewards (CODE, numbers untuned). Levi's concept kept exactly. Models/animations/audio: NEEDS art |
| 5 Regional bosses | 4 regional + 6 mini-bosses designed and defined (CODE). Arenas/structures: NEEDS builds. Models/audio: NEEDS art |
| 6 Structures | Registry, validation, template capture, safe placement, rollback, regenerate, Lost Cargo + Ghost Fleet events (CODE). Actual structure builds: NEEDS builders |
| 7 Blocks/vegetation | 44 custom blocks + 20 vegetation types allocated and generated (CODE): placing, breaking, drops, physics protection, glow via invisible light blocks. Textures/models: NEEDS art. Limits: break speed follows the carrier block, fixed light levels, opaque sea glass |
| 8 Vehicles | 6 types, controls, collision, depth limit, items, persistence (CODE). Lights, upgrades, pressure/oxygen, trails: NONE. Blueprint recipes (CODE, ingredients NEEDS) |
| 9 Journal | Data + GUI (CODE). Pack art: NEEDS |
| 10 Exploration activities | Fishing discoveries (CODE, catches NEEDS). Treasure diving/mechanisms/puzzles: NONE |
| 11 Events | All 10 (CODE): Blood Tide, Silent Waters, Levi's Shadow, Whale Migration, Abyssal Storm, Ghost Fleet, The Great Hunt, Lost Cargo, Crystal Surge, Volcanic Awakening. Visuals/sounds are placeholders |
| 13 Admin commands | All groups in the spec: help/reload/status, structure, biome, mob, boss, event, vehicle, discovery, plus item/vent/block helpers (CODE) |
| 14 Existing ocean protection | Chunk-inhabited check, allowed-worlds, claim-check hook (no claim plugin integration yet), rollback snapshots (CODE). Biome change/regenerate commands: NONE |
| 15-16 Architecture/performance | Module system with clean disable, TPS gating, capped particles, tick-sliced world edits (CODE) |

## Decisions still needed from you (all in config.yml)
All previously open design decisions were made by Claude and marked 'DESIGN DECISION' in config.yml (Levi ritual conditions, Ghost Vessel wake, blueprint mapping, placeholder recipes, boss rewards). Still needed: your claim plugin name, and any decision you want changed.

## Highest-risk assumptions (check first when it fails to build/run)
Paper API coordinate and Java version; Player#getCurrentInput; TeleportFlag RETAIN_PASSENGERS; ItemMeta#setItemModel;
BlockData#rotate; MythicMobs spawn command + addtag mechanic; datapack biome JSON format; red_mushroom_block states unused by vanilla.
