plugins {
    java
}

group = "com.des"
version = "0.1.0"

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    // UNVERIFIED coordinate: confirm the exact 26.2 artifact version on repo.papermc.io
    compileOnly("io.papermc.paper:paper-api:26.2.build.+")
}

java {
    // UNVERIFIED: 26.x servers need a newer Java than 21. Set to your server's Java version.
    toolchain.languageVersion.set(JavaLanguageVersion.of(25))
}

tasks.processResources {
    filesMatching("plugin.yml") { expand("version" to project.version) }
}
