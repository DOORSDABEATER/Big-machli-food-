package com.des.sea.discovery;

public record DiscoveryEntry(String id, Category category, String name, String hint) {
    public enum Category { BIOME, CREATURE, BOSS_ENCOUNTERED, BOSS_DEFEATED, STRUCTURE, BLUEPRINT, RECIPE, ARTIFACT, FISHING, SECRET, LOCATION }
}
