package com.des.sea.boss;

import com.des.sea.DesSeaPlugin;
import com.des.sea.core.DesModule;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.WaterMob;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * Levi: ritual state, awakening sequence, attempt lifecycle, retreat and reward handling.
 * This is the SAFE LIFECYCLE around the fight. Phases, attacks, model and animations live in MythicMobs/ModelEngine.
 * Levi's established design is untouched: nothing here changes phases, attacks, ritual items or rewards.
 */
public final class LeviEncounter implements DesModule, Listener {
    public enum State { DORMANT, AWAKENING, ACTIVE }

    public static final String TAG = "des_levi"; // MythicMobs mob must apply this scoreboard tag (see config notes)

    private final DesSeaPlugin plugin;
    private final File file;

    private State state = State.DORMANT;
    private String attemptId;
    private Location altar;
    private double scale = 1.0;

    // Ritual components (what each one physically is gets decided by the altar/shrine builds)
    private final Set<Integer> seals = new TreeSet<>();   // 0..2
    private final Set<Integer> pillars = new TreeSet<>();
    private boolean heart, offering, verse;

    private final Set<UUID> participants = new LinkedHashSet<>();
    private final Map<UUID, Set<String>> pending = new HashMap<>(); // undelivered rewards: player -> attempt ids

    private final List<BukkitTask> tasks = new ArrayList<>();
    private BukkitTask monitor;
    private int emptyChecks;

    public LeviEncounter(DesSeaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "levi.yml");
    }

    @Override public String id() { return "levi"; }

    @Override
    public void enable() {
        load();
        if (state == State.AWAKENING) { // crashed mid-sequence: abort cleanly, keep ritual so it stays recoverable
            plugin.getLogger().warning("Levi was mid-awakening at last shutdown; reset to DORMANT.");
            state = State.DORMANT;
            attemptId = null;
            participants.clear();
            save();
        }
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
        monitor = plugin.getServer().getScheduler().runTaskTimer(plugin, this::monitorTick, 100L, 40L);
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll(this);
        cancelTasks();
        if (monitor != null) monitor.cancel();
        monitor = null;
        if (state == State.AWAKENING) { state = State.DORMANT; attemptId = null; participants.clear(); }
        save();
    }

    // ---------- public API (used by altar/shrine/pillar interactions and admin commands) ----------

    public State state() { return state; }
    public Location altar() { return altar; }
    public void setAltar(Location l) { altar = l.clone(); save(); }

    public void placeSeal(int i) { if (i >= 0 && i < 3) { seals.add(i); save(); } }
    public void activatePillar(int i) { if (i >= 0) { pillars.add(i); save(); } }
    public void insertHeart() { heart = true; save(); }
    public void presentOffering() { offering = true; save(); }
    public void speakVerse() { verse = true; save(); }

    public String progress() {
        return "seals=" + seals.size() + "/3, pillars=" + pillars.size() + "/" + pillarCount()
                + ", heart=" + heart + ", offering=" + offering + ", verse=" + verse;
    }

    private int pillarCount() { return plugin.getConfig().getInt("levi.pillar-count", 3); }

    /** Empty list = ready. Reasons are for admins/logs; players should only ever get vague feedback. */
    public List<String> problems(Player p) {
        List<String> out = new ArrayList<>();
        if (state != State.DORMANT) out.add("Encounter is " + state + ".");
        if (altar == null) out.add("Altar location not set.");
        if (seals.size() < 3) out.add("Seals missing.");
        if (pillars.size() < pillarCount()) out.add("Pillars not all active.");
        if (!heart) out.add("Heart not inserted.");
        if (!offering) out.add("Offering not presented.");
        if (!verse) out.add("Verse not spoken.");
        if (altar != null && p != null) {
            if (!p.getWorld().equals(altar.getWorld())) out.add("Wrong world.");
            if (p.getLocation().getY() > plugin.getConfig().getDouble("levi.max-y", 0)) out.add("Not deep enough.");
            if (plugin.getConfig().getBoolean("levi.require-storm", true) && !p.getWorld().hasStorm()) out.add("Weather condition not met.");
        }
        return out;
    }

    /** Player-triggered path: all ritual conditions must hold. */
    public List<String> tryAwaken(Player p) {
        List<String> pr = problems(p);
        if (pr.isEmpty()) startAwakening();
        return pr;
    }

    /** Admin path (skips ritual requirements, still needs an altar). */
    public boolean forceAwaken() {
        if (state != State.DORMANT || altar == null) return false;
        startAwakening();
        return true;
    }

    public void adminRetreat(String reason) { retreat(reason); }

    public void adminReset() {
        retreat("admin reset");
        clearRitual();
        save();
    }

    public String info() {
        return "state=" + state + ", attempt=" + attemptId + ", participants=" + participants.size()
                + ", scale=" + scale + ", altar=" + (altar == null ? "unset" : fmt(altar)) + ", " + progress();
    }

    private static String fmt(Location l) { return l.getWorld().getName() + " " + l.getBlockX() + " " + l.getBlockY() + " " + l.getBlockZ(); }

    // ---------- awakening ----------

    private void startAwakening() {
        state = State.AWAKENING;
        attemptId = UUID.randomUUID().toString();
        participants.clear();
        emptyChecks = 0;
        double r = plugin.getConfig().getDouble("levi.participant-radius", 150);
        for (Player p : altar.getWorld().getPlayers()) {
            if (p.getLocation().distance(altar) <= r) participants.add(p.getUniqueId());
        }
        scale = Math.max(4, Math.min(8, participants.size())) / 4.0; // 4..8 players -> 1.0..2.0 (MythicMobs must read this)
        save();
        plugin.getLogger().info("Levi awakening, attempt " + attemptId + ", participants=" + participants.size());

        long step = plugin.getConfig().getLong("levi.awakening-step-ticks", 80);
        for (int i = 1; i <= 9; i++) {
            final int n = i;
            tasks.add(plugin.getServer().getScheduler().runTaskLater(plugin, () -> awakeningStep(n), step * (i - 1)));
        }
    }

    private void awakeningStep(int n) {
        if (state != State.AWAKENING) return;
        // Every step plays a distinct sound event; real VFX/audio assets replace these later.
        for (UUID u : participants) {
            Player p = Bukkit.getPlayer(u);
            if (p == null) continue;
            if (n == 1) { p.stopSound(SoundCategory.AMBIENT); p.stopSound(SoundCategory.MUSIC); } // environmental silence
            p.playSound(altar, "des_sea:levi.awaken.step" + n, SoundCategory.MASTER, 1.0f, 1.0f);
        }
        if (n == 3) scareCreatures();
        if (n == 9) emerge();
    }

    /** Nearby water creatures flee from the altar. Bounded to 50 entities. */
    private void scareCreatures() {
        int count = 0;
        for (Entity e : altar.getWorld().getNearbyEntities(altar, 64, 64, 64)) {
            if (!(e instanceof WaterMob) || count++ >= 50) continue;
            e.setVelocity(e.getLocation().toVector().subtract(altar.toVector()).normalize().multiply(0.8));
        }
    }

    private void emerge() {
        String cmd = plugin.getConfig().getString("levi.mythic-spawn-command", "")
                .replace("%world%", altar.getWorld().getName())
                .replace("%x%", String.valueOf(altar.getBlockX()))
                .replace("%y%", String.valueOf(altar.getBlockY()))
                .replace("%z%", String.valueOf(altar.getBlockZ()));
        if (cmd.isBlank()) {
            plugin.getLogger().severe("levi.mythic-spawn-command is empty; aborting awakening (ritual kept).");
            retreat("no spawn command");
            return;
        }
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
        // Verify the spawn actually produced a tagged entity; otherwise roll back safely.
        tasks.add(plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (state != State.AWAKENING) return;
            if (findLevi().isEmpty()) {
                plugin.getLogger().severe("Spawn command ran but no entity tagged '" + TAG + "' exists. Check the MythicMobs mob file.");
                retreat("spawn failed");
                return;
            }
            state = State.ACTIVE;
            save();
            plugin.engine().attach(findLevi().get(0), "levi", altar, scale, () -> participants);
            Bukkit.broadcast(Component.text("Something ancient has answered."));
            for (UUID u : participants) plugin.discovery().unlock(u, "boss.encountered.levi");
            // The title is revealed only after emergence.
            tasks.add(plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                for (UUID u : participants) {
                    Player p = Bukkit.getPlayer(u);
                    if (p != null) p.showTitle(Title.title(Component.text("LEVI"), Component.text("The Sovereign Beneath")));
                }
            }, 300L)); // 10 s emergence + 5 s intro: the title is revealed only after he has fully risen
        }, 40L));
    }

    // ---------- active fight lifecycle ----------

    private List<Entity> findLevi() {
        List<Entity> out = new ArrayList<>();
        if (altar == null) return out;
        for (Entity e : altar.getWorld().getNearbyEntities(altar, 400, 400, 400)) {
            if (e.getScoreboardTags().contains(TAG)) out.add(e);
        }
        return out;
    }

    private void monitorTick() {
        if (state != State.ACTIVE) return;
        List<Entity> found = findLevi();
        if (found.isEmpty()) { retreat("entity vanished"); return; }
        // After a restart the fight state is gone: re-attach (boss health resets to full)
        if (plugin.modules().isRunning("boss_engine") && !plugin.engine().isFighting(found.get(0))) plugin.engine().attach(found.get(0), "levi", altar, scale, () -> participants);
        boolean anyAlive = false;
        for (UUID u : participants) {
            Player p = Bukkit.getPlayer(u);
            if (p != null && !p.isDead() && p.getWorld().equals(altar.getWorld()) && p.getLocation().distance(altar) <= 400) { anyAlive = true; break; }
        }
        emptyChecks = anyAlive ? 0 : emptyChecks + 1;
        if (emptyChecks >= plugin.getConfig().getInt("levi.wipe-grace-checks", 5)) retreat("group wiped or left");
    }

    /** Levi retreats: entity removed, state back to DORMANT. Ritual kept or cleared per config. */
    private void retreat(String reason) {
        cancelTasks();
        for (Entity e : findLevi()) e.remove();
        state = State.DORMANT;
        attemptId = null;
        participants.clear();
        emptyChecks = 0;
        if (!plugin.getConfig().getBoolean("levi.retreat-keeps-ritual", true)) clearRitual();
        save();
        plugin.getLogger().info("Levi retreated: " + reason);
    }

    private void clearRitual() {
        seals.clear(); pillars.clear(); heart = offering = verse = false;
    }

    @EventHandler
    public void onDamage(EntityDamageByEntityEvent e) {
        if (state != State.ACTIVE || !e.getEntity().getScoreboardTags().contains(TAG)) return;
        Entity d = e.getDamager();
        if (d instanceof Projectile pr && pr.getShooter() instanceof Entity s) d = s;
        if (d instanceof Player p && participants.add(p.getUniqueId())) save();
    }

    @EventHandler
    public void onDeath(EntityDeathEvent e) {
        LivingEntity ent = e.getEntity();
        if (state == State.ACTIVE && ent.getScoreboardTags().contains(TAG)) defeat();
    }

    private void defeat() {
        String id = attemptId;
        Set<UUID> winners = new LinkedHashSet<>(participants);
        cancelTasks();
        state = State.DORMANT;
        attemptId = null;
        participants.clear();
        clearRitual(); // a successful run consumes the ritual
        for (UUID u : winners) {
            pending.computeIfAbsent(u, k -> new LinkedHashSet<>()).add(id);
            plugin.discovery().unlock(u, "boss.defeated.levi");
        }
        save(); // persist BEFORE delivering, so a crash can never double-reward
        plugin.getLogger().info("Levi defeated, attempt " + id + ", winners=" + winners.size());
        for (UUID u : winners) {
            Player p = Bukkit.getPlayer(u);
            if (p != null) deliver(p);
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) { deliver(e.getPlayer()); }

    /** At-most-once delivery: the pending entry is removed and saved before any reward command runs. */
    private void deliver(Player p) {
        Set<String> ids = pending.get(p.getUniqueId());
        if (ids == null || ids.isEmpty()) return;
        List<String> cmds = plugin.getConfig().getStringList("levi.reward-commands");
        if (cmds.isEmpty()) {
            plugin.getLogger().warning("Rewards pending for " + p.getName() + " but levi.reward-commands is empty; kept pending.");
            return;
        }
        int n = ids.size();
        pending.remove(p.getUniqueId());
        save();
        for (int i = 0; i < n; i++) {
            for (String c : cmds) Bukkit.dispatchCommand(Bukkit.getConsoleSender(), c.replace("%player%", p.getName()));
        }
    }

    private void cancelTasks() {
        tasks.forEach(BukkitTask::cancel);
        tasks.clear();
    }

    // ---------- persistence ----------

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration c = YamlConfiguration.loadConfiguration(file);
        try { state = State.valueOf(c.getString("state", "DORMANT")); } catch (IllegalArgumentException ex) { state = State.DORMANT; }
        attemptId = c.getString("attempt");
        scale = c.getDouble("scale", 1.0);
        String w = c.getString("altar.world");
        World world = w == null ? null : Bukkit.getWorld(w);
        altar = world == null ? null : new Location(world, c.getDouble("altar.x"), c.getDouble("altar.y"), c.getDouble("altar.z"));
        seals.clear(); seals.addAll(c.getIntegerList("ritual.seals"));
        pillars.clear(); pillars.addAll(c.getIntegerList("ritual.pillars"));
        heart = c.getBoolean("ritual.heart"); offering = c.getBoolean("ritual.offering"); verse = c.getBoolean("ritual.verse");
        participants.clear();
        for (String s : c.getStringList("participants")) try { participants.add(UUID.fromString(s)); } catch (IllegalArgumentException ignored) {}
        pending.clear();
        ConfigurationSection ps = c.getConfigurationSection("pending");
        if (ps != null) for (String k : ps.getKeys(false)) {
            try { pending.put(UUID.fromString(k), new LinkedHashSet<>(ps.getStringList(k))); } catch (IllegalArgumentException ignored) {}
        }
    }

    private void save() {
        YamlConfiguration c = new YamlConfiguration();
        c.set("state", state.name());
        c.set("attempt", attemptId);
        c.set("scale", scale);
        if (altar != null) {
            c.set("altar.world", altar.getWorld().getName());
            c.set("altar.x", altar.getX()); c.set("altar.y", altar.getY()); c.set("altar.z", altar.getZ());
        }
        c.set("ritual.seals", new ArrayList<>(seals));
        c.set("ritual.pillars", new ArrayList<>(pillars));
        c.set("ritual.heart", heart); c.set("ritual.offering", offering); c.set("ritual.verse", verse);
        c.set("participants", participants.stream().map(UUID::toString).toList());
        pending.forEach((u, ids) -> c.set("pending." + u, new ArrayList<>(ids)));
        try {
            plugin.getDataFolder().mkdirs();
            c.save(file);
        } catch (IOException ex) {
            plugin.getLogger().severe("Could not save levi.yml: " + ex.getMessage());
        }
    }
}
