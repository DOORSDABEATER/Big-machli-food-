package com.des.sea.boss;

import com.des.sea.DesSeaPlugin;
import com.des.sea.core.DesModule;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * Generic safe lifecycle for every boss EXCEPT Levi (who has his own ritual module): spawn, verify, track participants,
 * retreat on wipe, at-most-once rewards. Each boss's attacks, phases, model and arena mechanics live in MythicMobs/ModelEngine.
 * A boss is declared under "bosses.<id>" in config.yml and its MythicMobs mob must add the scoreboard tag des_boss_<id>.
 */
public final class BossManager implements DesModule, Listener {
    public static final String TAG_PREFIX = "des_boss_";

    private static final class Run {
        String attempt;
        Location arena;
        boolean active;
        int emptyChecks;
        double scale = 1.0;
        final Set<UUID> participants = new LinkedHashSet<>();
        BukkitTask verify;
    }

    private final DesSeaPlugin plugin;
    private final File file;
    private final Map<String, Run> runs = new LinkedHashMap<>();
    private final Map<UUID, Set<String>> pending = new HashMap<>(); // player -> "bossId|attempt"
    private BukkitTask monitor;

    public BossManager(DesSeaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "bosses.yml");
    }

    @Override public String id() { return "bosses"; }

    @Override
    public void enable() {
        load();
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
        monitor = plugin.getServer().getScheduler().runTaskTimer(plugin, this::monitorTick, 100L, 40L);
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll(this);
        if (monitor != null) monitor.cancel();
        monitor = null;
        runs.values().forEach(r -> { if (r.verify != null) r.verify.cancel(); r.verify = null; });
        save();
    }

    public Set<String> ids() {
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("bosses");
        return s == null ? Set.of() : s.getKeys(false);
    }

    public boolean isActive(String id) { Run r = runs.get(id); return r != null && r.active; }

    private Run run(String id) { return runs.computeIfAbsent(id, k -> new Run()); }
    private String tag(String id) { return TAG_PREFIX + id; }

    public void setArena(String id, Location l) { run(id).arena = l.clone(); save(); }

    public String info(String id) {
        Run r = run(id);
        return id + ": " + (r.active ? "ACTIVE" : "DORMANT") + ", attempt=" + r.attempt + ", participants=" + r.participants.size()
                + ", scale=" + r.scale + ", arena=" + (r.arena == null ? "unset"
                : r.arena.getWorld().getName() + " " + r.arena.getBlockX() + " " + r.arena.getBlockY() + " " + r.arena.getBlockZ());
    }

    /** Returns null on success, else the reason it could not start. */
    public String start(String id) {
        if (!ids().contains(id)) return "Unknown boss '" + id + "'. Declare it under bosses." + id + " in config.yml.";
        Run r = run(id);
        if (r.active) return "Already active.";
        if (r.arena == null) return "Arena location not set (/dessea boss altar " + id + ").";
        String tpl = plugin.getConfig().getString("bosses." + id + ".spawn-command", "");
        if (tpl.isBlank()) return "bosses." + id + ".spawn-command is empty.";

        r.attempt = UUID.randomUUID().toString();
        r.active = true;
        r.emptyChecks = 0;
        r.participants.clear();
        double rad = plugin.getConfig().getDouble("bosses." + id + ".arena-radius", 150);
        for (Player p : r.arena.getWorld().getPlayers()) if (p.getLocation().distance(r.arena) <= rad) r.participants.add(p.getUniqueId());
        r.scale = Math.max(4, Math.min(8, r.participants.size())) / 4.0; // MythicMobs must read this to scale health
        save();

        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), tpl.replace("%world%", r.arena.getWorld().getName())
                .replace("%x%", String.valueOf(r.arena.getBlockX())).replace("%y%", String.valueOf(r.arena.getBlockY()))
                .replace("%z%", String.valueOf(r.arena.getBlockZ())));
        r.verify = plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            r.verify = null;
            if (!r.active) return;
            if (find(id, r).isEmpty()) {
                plugin.getLogger().severe("Boss " + id + ": spawn command ran but no entity tagged '" + tag(id) + "' exists. Check its MythicMobs file.");
                retreat(id, "spawn failed");
                return;
            }
            plugin.engine().attach(find(id, r).get(0), id, r.arena, r.scale, () -> r.participants);
            for (UUID u : r.participants) plugin.discovery().unlock(u, "boss.encountered." + id);
        }, 40L);
        return null;
    }

    private List<Entity> find(String id, Run r) {
        List<Entity> out = new ArrayList<>();
        if (r.arena == null) return out;
        for (Entity e : r.arena.getWorld().getNearbyEntities(r.arena, 400, 400, 400)) if (e.getScoreboardTags().contains(tag(id))) out.add(e);
        return out;
    }

    public void retreat(String id, String reason) {
        Run r = run(id);
        if (r.verify != null) { r.verify.cancel(); r.verify = null; }
        for (Entity e : find(id, r)) e.remove();
        r.active = false;
        r.attempt = null;
        r.participants.clear();
        r.emptyChecks = 0;
        save();
        plugin.getLogger().info("Boss " + id + " retreated: " + reason);
    }

    private void monitorTick() {
        for (Map.Entry<String, Run> en : new ArrayList<>(runs.entrySet())) {
            Run r = en.getValue();
            if (!r.active || r.verify != null) continue;
            String id = en.getKey();
            List<Entity> found = find(id, r);
            if (found.isEmpty()) { retreat(id, "entity vanished"); continue; }
            if (plugin.modules().isRunning("boss_engine") && !plugin.engine().isFighting(found.get(0))) plugin.engine().attach(found.get(0), id, r.arena, r.scale, () -> r.participants);
            boolean alive = false;
            for (UUID u : r.participants) {
                Player p = Bukkit.getPlayer(u);
                if (p != null && !p.isDead() && p.getWorld().equals(r.arena.getWorld()) && p.getLocation().distance(r.arena) <= 400) { alive = true; break; }
            }
            r.emptyChecks = alive ? 0 : r.emptyChecks + 1;
            if (r.emptyChecks >= plugin.getConfig().getInt("bosses." + id + ".wipe-grace-checks", 5)) retreat(id, "group wiped or left");
        }
    }

    private String bossOf(Entity e) {
        for (String t : e.getScoreboardTags()) if (t.startsWith(TAG_PREFIX)) return t.substring(TAG_PREFIX.length());
        return null;
    }

    @EventHandler
    public void onDamage(EntityDamageByEntityEvent e) {
        String id = bossOf(e.getEntity());
        if (id == null || !run(id).active) return;
        Entity d = e.getDamager();
        if (d instanceof Projectile pr && pr.getShooter() instanceof Entity s) d = s;
        if (d instanceof Player p && run(id).participants.add(p.getUniqueId())) save();
    }

    @EventHandler
    public void onDeath(EntityDeathEvent e) {
        String id = bossOf(e.getEntity());
        if (id != null && run(id).active) defeat(id);
    }

    private void defeat(String id) {
        Run r = run(id);
        String attempt = r.attempt;
        Set<UUID> winners = new LinkedHashSet<>(r.participants);
        if (r.verify != null) { r.verify.cancel(); r.verify = null; }
        r.active = false;
        r.attempt = null;
        r.participants.clear();
        for (UUID u : winners) {
            pending.computeIfAbsent(u, k -> new LinkedHashSet<>()).add(id + "|" + attempt);
            plugin.discovery().unlock(u, "boss.defeated." + id);
        }
        save(); // persist before delivering: a crash can never double-reward
        plugin.getLogger().info("Boss " + id + " defeated, attempt " + attempt + ", winners=" + winners.size());
        for (UUID u : winners) { Player p = Bukkit.getPlayer(u); if (p != null) deliver(p); }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) { deliver(e.getPlayer()); }

    /** At-most-once: entries are removed and saved before any reward command runs. Bosses without reward commands stay pending. */
    private void deliver(Player p) {
        Set<String> keys = pending.get(p.getUniqueId());
        if (keys == null || keys.isEmpty()) return;
        List<String> toRun = new ArrayList<>();
        for (Iterator<String> it = keys.iterator(); it.hasNext(); ) {
            String key = it.next();
            String id = key.substring(0, key.indexOf('|'));
            List<String> cmds = plugin.getConfig().getStringList("bosses." + id + ".reward-commands");
            if (cmds.isEmpty()) { plugin.getLogger().warning("Reward pending for " + p.getName() + " (" + id + ") but no reward-commands configured; kept."); continue; }
            it.remove();
            for (String c : cmds) toRun.add(c.replace("%player%", p.getName()));
        }
        if (keys.isEmpty()) pending.remove(p.getUniqueId());
        save();
        for (String c : toRun) Bukkit.dispatchCommand(Bukkit.getConsoleSender(), c);
    }

    private void load() {
        runs.clear();
        pending.clear();
        if (!file.exists()) return;
        YamlConfiguration c = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection bs = c.getConfigurationSection("bosses");
        if (bs != null) for (String id : bs.getKeys(false)) {
            ConfigurationSection s = bs.getConfigurationSection(id);
            if (s == null) continue;
            Run r = run(id);
            World w = s.getString("arena.world") == null ? null : Bukkit.getWorld(s.getString("arena.world"));
            if (w != null) r.arena = new Location(w, s.getDouble("arena.x"), s.getDouble("arena.y"), s.getDouble("arena.z"));
            r.active = s.getBoolean("active");
            r.attempt = s.getString("attempt");
            r.scale = s.getDouble("scale", 1.0);
            for (String u : s.getStringList("participants")) try { r.participants.add(UUID.fromString(u)); } catch (IllegalArgumentException ignored) {}
        }
        ConfigurationSection ps = c.getConfigurationSection("pending");
        if (ps != null) for (String k : ps.getKeys(false)) try { pending.put(UUID.fromString(k), new LinkedHashSet<>(ps.getStringList(k))); } catch (IllegalArgumentException ignored) {}
    }

    private void save() {
        YamlConfiguration c = new YamlConfiguration();
        runs.forEach((id, r) -> {
            String p = "bosses." + id + ".";
            c.set(p + "active", r.active);
            c.set(p + "attempt", r.attempt);
            c.set(p + "scale", r.scale);
            c.set(p + "participants", r.participants.stream().map(UUID::toString).toList());
            if (r.arena != null) {
                c.set(p + "arena.world", r.arena.getWorld().getName());
                c.set(p + "arena.x", r.arena.getX()); c.set(p + "arena.y", r.arena.getY()); c.set(p + "arena.z", r.arena.getZ());
            }
        });
        pending.forEach((u, ks) -> c.set("pending." + u, new ArrayList<>(ks)));
        try {
            plugin.getDataFolder().mkdirs();
            c.save(file);
        } catch (IOException ex) {
            plugin.getLogger().severe("Could not save bosses.yml: " + ex.getMessage());
        }
    }
}
