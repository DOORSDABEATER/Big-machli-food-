package com.des.sea.command;

import com.des.sea.DesSeaPlugin;
import com.des.sea.core.CompatReport;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.*;

public final class DesSeaCommand implements CommandExecutor, TabCompleter {
    private static final String PERM = "des.sea.admin";
    private static final List<String> NOT_BUILT = List.of();

    private final DesSeaPlugin plugin;
    private final Map<String, SubCommand> groups = new LinkedHashMap<>();

    public DesSeaCommand(DesSeaPlugin plugin) {
        this.plugin = plugin;
        groups.put("discovery", new DiscoverySub(plugin));
        groups.put("structure", new StructureSub(plugin));
        groups.put("event", new EventSub(plugin));
        groups.put("boss", new BossSub(plugin));
        groups.put("vehicle", new VehicleSub(plugin));
        groups.put("item", new ItemSub(plugin));
        groups.put("vent", new VentSub(plugin));
        groups.put("block", new BlockSub(plugin));
        groups.put("biome", new BiomeSub(plugin));
        groups.put("mob", new MobSub(plugin));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission(PERM)) {
            sender.sendMessage("You don't have permission to use this command.");
            return true;
        }
        String sub = args.length == 0 ? "help" : args[0].toLowerCase(Locale.ROOT);
        SubCommand group = groups.get(sub);
        if (group != null) {
            group.run(sender, Arrays.copyOfRange(args, 1, args.length));
            return true;
        }
        switch (sub) {
            case "help" -> sender.sendMessage("/dessea help | reload | status | report | structure | event | discovery | boss | vehicle | item | vent | block | biome | mob"
                    + "  (not built yet: " + String.join(", ", NOT_BUILT) + ")");
            case "reload" -> {
                plugin.reload();
                plugin.audit(sender.getName(), "reload");
                sender.sendMessage("DeS Sea reloaded.");
            }
            case "status" -> {
                sender.sendMessage("DeS Sea " + plugin.getPluginMeta().getVersion() + " - modules:");
                plugin.modules().status().forEach((k, v) -> sender.sendMessage("  " + k + ": " + (v ? "running" : "off")));
            }
            case "report" -> {
                CompatReport.write(plugin);
                plugin.audit(sender.getName(), "report");
                CompatReport.build(plugin).forEach(sender::sendMessage);
            }
            default -> sender.sendMessage(NOT_BUILT.contains(sub)
                    ? "'" + sub + "' commands are not built yet (planned for a later phase)."
                    : "Unknown subcommand '" + sub + "'. Try /dessea help.");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission(PERM)) return List.of();
        if (args.length == 1) {
            List<String> top = new ArrayList<>(List.of("help", "reload", "status", "report"));
            top.addAll(groups.keySet());
            top.addAll(NOT_BUILT);
            return DiscoverySub.filter(top, args[0]);
        }
        SubCommand g = groups.get(args[0].toLowerCase(Locale.ROOT));
        return g == null ? List.of() : g.complete(sender, Arrays.copyOfRange(args, 1, args.length));
    }
}
