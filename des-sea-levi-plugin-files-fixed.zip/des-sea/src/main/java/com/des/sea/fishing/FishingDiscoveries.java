package com.des.sea.fishing;

import com.des.sea.DesSeaPlugin;
import com.des.sea.core.Biomes;
import com.des.sea.core.DesModule;
import com.des.sea.discovery.DiscoveryEntry.Category;
import com.des.sea.discovery.DiscoveryRegistry;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerFishEvent;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Rare, config-defined catches. Nothing is invented here: with no entries in config.yml this module does nothing.
 * Each catch defines a discovery entry (shown in the journal's Fishing tab), a chance, optional biome, and reward commands.
 */
public final class FishingDiscoveries implements DesModule, Listener {
    private record Catch(String id, String name, String hint, double chance, String biome, boolean replace, List<String> commands) {}

    private final DesSeaPlugin plugin;
    private final List<Catch> catches = new ArrayList<>();
    private final List<String> registeredIds = new ArrayList<>();

    public FishingDiscoveries(DesSeaPlugin plugin) { this.plugin = plugin; }

    @Override public String id() { return "fishing"; }

    @Override
    public void enable() {
        for (Map<?, ?> m : plugin.getConfig().getMapList("fishing.catches")) {
            try {
                String id = String.valueOf(m.get("id"));
                if (!id.matches("[a-z0-9_]+")) throw new IllegalArgumentException("bad id");
                List<String> cmds = new ArrayList<>();
                if (m.get("reward-commands") instanceof List<?> l) for (Object o : l) cmds.add(String.valueOf(o));
                catches.add(new Catch("fishing." + id, String.valueOf(m.get("name")),
                        m.get("hint") == null ? "Something strange on the line." : String.valueOf(m.get("hint")),
                        m.get("chance") instanceof Number n ? n.doubleValue() : 0.01,
                        m.get("biome") == null ? null : String.valueOf(m.get("biome")),
                        Boolean.TRUE.equals(m.get("replace-catch")), cmds));
            } catch (RuntimeException ex) {
                plugin.getLogger().warning("Bad fishing catch entry: " + m);
            }
        }
        for (Catch c : catches) {
            DiscoveryRegistry.register(c.id(), Category.FISHING, c.name(), c.hint());
            registeredIds.add(c.id());
        }
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
        plugin.getLogger().info("Fishing discoveries loaded: " + catches.size());
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll(this);
        registeredIds.forEach(DiscoveryRegistry::unregister);
        registeredIds.clear();
        catches.clear();
    }

    @EventHandler
    public void onFish(PlayerFishEvent e) {
        if (e.getState() != PlayerFishEvent.State.CAUGHT_FISH || !plugin.modules().isRunning("journal")) return;
        Player p = e.getPlayer();
        String biome = Biomes.desBiome(p.getLocation());
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (Catch c : catches) {
            if (c.biome() != null && !c.biome().equals(biome)) continue;
            if (r.nextDouble() >= c.chance()) continue;
            plugin.discovery().unlock(p.getUniqueId(), c.id());
            Entity caught = e.getCaught();
            if (c.replace() && caught != null) caught.remove();
            for (String cmd : c.commands()) Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("%player%", p.getName()));
            return; // at most one special catch per cast
        }
    }
}
