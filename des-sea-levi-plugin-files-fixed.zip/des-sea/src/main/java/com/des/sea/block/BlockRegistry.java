package com.des.sea.block;

import com.des.sea.DesSeaPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.data.BlockData;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** The custom block library from blocks.yml: cubes on note-block states, plants on coral blocks. */
public final class BlockRegistry {
    public record Def(String id, String name, Material material, boolean plant, int light, BlockData data) {}

    private final Map<String, Def> byId = new LinkedHashMap<>();
    private final Map<String, Def> cubeByState = new HashMap<>();
    private final Map<Material, Def> plantByMaterial = new HashMap<>();
    private final Set<Material> plantMaterials = EnumSet.noneOf(Material.class);

    public BlockRegistry(DesSeaPlugin plugin) {
        try (InputStream in = plugin.getResource("blocks.yml")) {
            if (in == null) { plugin.getLogger().severe("blocks.yml missing from the jar"); return; }
            ConfigurationSection s = YamlConfiguration.loadConfiguration(new InputStreamReader(in, StandardCharsets.UTF_8)).getConfigurationSection("blocks");
            if (s == null) return;
            for (String id : s.getKeys(false)) {
                ConfigurationSection b = s.getConfigurationSection(id);
                Material m = Material.matchMaterial(b.getString("material", ""));
                if (m == null) { plugin.getLogger().warning("Unknown carrier material for block " + id); continue; }
                BlockData data = Bukkit.createBlockData(m, "[" + b.getString("state", "") + "]");
                boolean plant = "plant".equals(b.getString("kind"));
                Def d = new Def(id, b.getString("name", id), m, plant, b.getInt("light", 0), data);
                byId.put(id, d);
                if (plant) { plantByMaterial.put(m, d); plantMaterials.add(m); } else cubeByState.put(data.getAsString(), d);
            }
        } catch (Exception e) {
            plugin.getLogger().severe("Could not load blocks.yml: " + e);
        }
        plugin.getLogger().info("Custom blocks loaded: " + byId.size());
    }

    public Collection<Def> all() { return byId.values(); }
    public Def get(String id) { return byId.get(id); }
    public BlockData data(String id) { Def d = byId.get(id); return d == null ? null : d.data().clone(); }

    /** Cheap pre-filter for hot events (physics): could this material be one of ours? */
    public boolean mayBeCustom(Material m) { return m == Material.NOTE_BLOCK || plantMaterials.contains(m); }

    /** Returns the custom definition for a block's current state, or null for vanilla blocks. */
    public Def lookup(BlockData d) {
        Material m = d.getMaterial();
        if (m == Material.NOTE_BLOCK) return cubeByState.get(d.getAsString());
        return plantByMaterial.get(m); // any state of a carrier coral counts as ours (waterlogged or not)
    }
}
