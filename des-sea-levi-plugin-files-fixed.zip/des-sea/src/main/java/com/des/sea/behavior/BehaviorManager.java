package com.des.sea.behavior;

import com.des.sea.DesSeaPlugin;
import com.des.sea.core.DesModule;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Light ecosystem behaviour for creatures tagged des_creature + des_mob_<id>: schooling, wandering, fleeing from players,
 * bosses and predators, and predators hunting prey (more aggressive during Blood Tide). Movement is velocity nudges, only for
 * creatures near players, in capped batches. Rules per creature are under behaviors.defs.<id> in config.yml. UNTESTED.
 */
public final class BehaviorManager implements DesModule {
    private final DesSeaPlugin plugin;
    private final Map<UUID, Long> biteCooldown = new HashMap<>();
    private BukkitTask task;
    private int offset;
    private long tickCount;

    public BehaviorManager(DesSeaPlugin plugin) { this.plugin = plugin; }

    @Override public String id() { return "behaviors"; }

    @Override
    public void enable() {
        long iv = Math.max(5, plugin.getConfig().getLong("behaviors.tick-interval", 10));
        task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, iv, iv);
    }

    @Override
    public void disable() {
        if (task != null) task.cancel();
        task = null;
        biteCooldown.clear();
    }

    private String idOf(Entity e) {
        for (String t : e.getScoreboardTags()) if (t.startsWith("des_mob_")) return t.substring(8);
        return null;
    }

    private boolean bloodTide() {
        var e = plugin.events() == null ? null : plugin.events().get("blood_tide");
        return e != null && e.running();
    }

    private void tick() {
        tickCount++;
        Set<Entity> near = new LinkedHashSet<>();
        for (Player p : Bukkit.getOnlinePlayers())
            for (Entity e : p.getNearbyEntities(48, 48, 48)) if (e instanceof LivingEntity && e.getScoreboardTags().contains("des_creature")) near.add(e);
        if (near.isEmpty()) return;
        List<Entity> all = new ArrayList<>(near);
        int max = plugin.getConfig().getInt("behaviors.max-per-tick", 60);
        int n = all.size();
        offset = (offset + max) % Math.max(1, n);
        List<Location> bosses = plugin.engine() == null ? List.of() : plugin.engine().activeBossLocations();
        boolean tide = bloodTide();

        for (int i = 0; i < Math.min(max, n); i++) {
            Entity e = all.get((offset + i) % n);
            String id = idOf(e);
            ConfigurationSection d = id == null ? null : plugin.getConfig().getConfigurationSection("behaviors.defs." + id);
            if (d == null || !e.isValid()) continue;
            Location loc = e.getLocation();
            Vector steer = new Vector();

            // 1. flee (strongest)
            Vector flee = new Vector();
            double fp = d.getDouble("flee-players", 0);
            if (fp > 0) for (Player p : e.getWorld().getPlayers()) {
                double dist = p.getLocation().distance(loc);
                if (dist < fp && !p.isSneaking()) flee.add(loc.toVector().subtract(p.getLocation().toVector()).normalize().multiply((fp - dist) / fp));
            }
            double fb = d.getDouble("flee-bosses", 0);
            if (fb > 0) for (Location b : bosses) if (b.getWorld().equals(loc.getWorld()) && b.distance(loc) < fb) flee.add(loc.toVector().subtract(b.toVector()).normalize().multiply(1.5));
            if (d.getBoolean("flee-predators")) for (Entity o : all) {
                if (o == e || !"predator".equals(plugin.getConfig().getString("behaviors.defs." + idOf(o) + ".type")) || o.getLocation().distance(loc) > 12) continue;
                flee.add(loc.toVector().subtract(o.getLocation().toVector()).normalize());
            }
            if (flee.lengthSquared() > 0) { e.setVelocity(clamp(e.getVelocity().multiply(0.5).add(flee.normalize().multiply(0.3)), 0.4)); continue; }

            // 2. type behaviour
            switch (d.getString("type", "wander")) {
                case "school" -> {
                    Vector center = new Vector(), align = new Vector(), sep = new Vector();
                    int c = 0;
                    for (Entity o : all) {
                        if (o == e || !Objects.equals(idOf(o), id)) continue;
                        double dist = o.getLocation().distance(loc);
                        if (dist > 8) continue;
                        c++;
                        center.add(o.getLocation().toVector());
                        align.add(o.getVelocity());
                        if (dist < 1.6) sep.add(loc.toVector().subtract(o.getLocation().toVector()));
                    }
                    if (c > 0) {
                        center.multiply(1.0 / c).subtract(loc.toVector()).multiply(0.03);
                        steer.add(center).add(align.multiply(0.5 / c)).add(sep.multiply(0.1));
                    }
                    steer.add(wander(0.03));
                }
                case "predator" -> {
                    double range = d.getDouble("range", 20) * (tide ? 1.5 : 1.0);
                    double speed = d.getDouble("speed", 0.22) * (tide ? 1.3 : 1.0);
                    List<String> prey = d.getStringList("prey");
                    Entity target = null;
                    double best = range;
                    for (Entity o : all) {
                        if (o == e || !prey.contains(idOf(o))) continue;
                        double dist = o.getLocation().distance(loc);
                        if (dist < best) { best = dist; target = o; }
                    }
                    if (tide && d.getBoolean("hunt-players-in-tide", true)) {
                        for (Player p : e.getWorld().getPlayers()) {
                            double dist = p.getLocation().distance(loc);
                            if (dist < best && p.isUnderWater()) { best = dist; target = p; }
                        }
                    }
                    if (target != null) {
                        steer.add(target.getLocation().toVector().subtract(loc.toVector()).normalize().multiply(speed));
                        if (best < 2.0 && target instanceof LivingEntity victim && bite(e, d.getInt("bite-cooldown", 30))) victim.damage(d.getDouble("bite-damage", 4), e);
                    } else steer.add(wander(0.05));
                }
                default -> steer.add(wander(0.04));
            }
            if (steer.lengthSquared() > 0) e.setVelocity(clamp(e.getVelocity().multiply(0.7).add(steer), 0.35));
        }
    }

    private boolean bite(Entity e, int cooldownTicks) {
        long now = Bukkit.getCurrentTick();
        if (now - biteCooldown.getOrDefault(e.getUniqueId(), -9999L) < cooldownTicks) return false;
        biteCooldown.put(e.getUniqueId(), now);
        if (biteCooldown.size() > 500) biteCooldown.keySet().removeIf(u -> Bukkit.getEntity(u) == null);
        return true;
    }

    private Vector wander(double s) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        return new Vector(r.nextDouble(-1, 1), r.nextDouble(-0.3, 0.3), r.nextDouble(-1, 1)).multiply(s);
    }

    private Vector clamp(Vector v, double max) {
        return v.lengthSquared() > max * max ? v.normalize().multiply(max) : v;
    }
}
