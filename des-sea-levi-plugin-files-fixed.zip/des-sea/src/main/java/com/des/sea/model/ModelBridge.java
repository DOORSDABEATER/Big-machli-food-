package com.des.sea.model;

import com.des.sea.DesSeaPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Optional;

/**
 * Talks to ModelEngine through reflection, so the plugin compiles and loads even if ModelEngine's API differs.
 * Written from memory of the ModelEngine R4 API (ModelEngineAPI, ModeledEntity, ActiveModel, AnimationHandler).
 * Every call is guarded: on failure it logs ONE warning with the exact exception, and fights continue without animation.
 * UNVERIFIED against ModelEngine 4.1.1: if a warning appears, send it so the call can be corrected.
 */
public final class ModelBridge {
    private static final String API = "com.ticxo.modelengine.api.ModelEngineAPI";
    private final DesSeaPlugin plugin;
    private final boolean present;
    private final java.util.Set<String> warned = new java.util.HashSet<>();

    public ModelBridge(DesSeaPlugin plugin) {
        this.plugin = plugin;
        this.present = Bukkit.getPluginManager().getPlugin("ModelEngine") != null;
    }

    public boolean available() { return present; }

    /** Adds the blueprint 'modelId' to the entity (if not already attached) and hides the base entity. */
    public boolean attach(Entity e, String modelId, double scale) {
        if (!present) { warnOnce("absent", "ModelEngine is not installed: models will not be attached."); return false; }
        try {
            Class<?> api = Class.forName(API);
            Object me = modeled(api, e);
            if (me == null) me = firstOk(api, new String[]{"createModeledEntity", "getOrCreateModeledEntity"}, e);
            if (me == null) { warnOnce("me", "Could not get or create a ModeledEntity for " + e.getType()); return false; }
            if (unwrap(invokeSafe(me, "getModel", modelId)) != null) return true; // already attached (e.g. by a MythicMobs mob file)
            Object active = invokeStatic(api, "createActiveModel", modelId);
            invoke(me, "addModel", active, true);
            try { invoke(active, "setScale", scale); } catch (Exception ignored) { warnOnce("scale", "ActiveModel#setScale not found; use the model's own size instead."); }
            try { invoke(me, "setBaseEntityVisible", false); } catch (Exception ignored) { /* ModelEngine usually hides the base entity itself */ }
            return true;
        } catch (Throwable t) {
            warnOnce("attach:" + modelId, "Could not attach model '" + modelId + "': " + root(t));
            return false;
        }
    }

    /** Plays an animation by name (forced, short blend). */
    public void play(Entity e, String modelId, String anim) {
        if (!present) return;
        try {
            Class<?> api = Class.forName(API);
            Object me = modeled(api, e);
            if (me == null) return;
            Object model = unwrap(invoke(me, "getModel", modelId));
            if (model == null) return;
            Object handler = invoke(model, "getAnimationHandler");
            invoke(handler, "playAnimation", anim, 0.1, 0.1, 1.0, true);
        } catch (Throwable t) {
            warnOnce("play", "Could not play animation '" + anim + "': " + root(t));
        }
    }

    // ------------------------------------------------------------ reflection helpers
    private Object modeled(Class<?> api, Entity e) throws Exception {
        for (Object arg : new Object[]{e, e.getUniqueId()}) {
            try { Object r = invokeStatic(api, "getModeledEntity", arg); if (r != null) return r; } catch (Exception ignored) { }
        }
        return null;
    }

    private Object firstOk(Class<?> api, String[] names, Object... args) {
        for (String n : names) { try { Object r = invokeStatic(api, n, args); if (r != null) return r; } catch (Exception ignored) { } }
        return null;
    }

    private static Object unwrap(Object o) { return o instanceof Optional<?> opt ? opt.orElse(null) : o; }

    private static Object invokeStatic(Class<?> c, String name, Object... args) throws Exception { return call(c, null, name, args); }
    private static Object invoke(Object target, String name, Object... args) throws Exception { return call(target.getClass(), target, name, args); }
    private static Object invokeSafe(Object target, String name, Object... args) { try { return invoke(target, name, args); } catch (Exception e) { return null; } }

    private static Object call(Class<?> c, Object target, String name, Object[] args) throws Exception {
        Exception last = null;
        for (Method m : c.getMethods()) {
            if (!m.getName().equals(name) || m.getParameterCount() != args.length) continue;
            try {
                Class<?>[] pt = m.getParameterTypes(); Object[] conv = new Object[args.length];
                for (int i = 0; i < args.length; i++) conv[i] = convert(pt[i], args[i]);
                return m.invoke(target, conv);
            } catch (IllegalArgumentException | InvocationTargetException | IllegalAccessException ex) { last = ex instanceof InvocationTargetException ite && ite.getCause() instanceof Exception ce ? ce : ex; }
        }
        throw last != null ? last : new NoSuchMethodException(c.getName() + "#" + name + "/" + args.length);
    }

    private static Object convert(Class<?> t, Object a) {
        if (a instanceof Number n) {
            if (t == double.class || t == Double.class) return n.doubleValue();
            if (t == float.class || t == Float.class) return n.floatValue();
            if (t == int.class || t == Integer.class) return n.intValue();
        }
        return a;
    }

    private static String root(Throwable t) { while (t.getCause() != null) t = t.getCause(); return t.getClass().getSimpleName() + ": " + t.getMessage(); }

    private void warnOnce(String key, String msg) { if (warned.add(key)) plugin.getLogger().warning("[ModelEngine bridge] " + msg); }
}
