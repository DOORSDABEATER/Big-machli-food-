package com.des.sea.command;

import com.des.sea.DesSeaPlugin;
import com.des.sea.block.BlockRegistry;
import org.bukkit.Bukkit;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.Locale;

final class BlockSub implements SubCommand {
    private final DesSeaPlugin plugin;

    BlockSub(DesSeaPlugin plugin) { this.plugin = plugin; }

    @Override
    public void run(CommandSender s, String[] a) {
        if (!plugin.modules().isRunning("blocks")) { s.sendMessage("The blocks module is off. Set modules.blocks: true in config.yml and /dessea reload."); return; }
        var cb = plugin.blocks();
        String sub = a.length == 0 ? "list" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "list" -> {
                long plants = cb.registry().all().stream().filter(BlockRegistry.Def::plant).count();
                s.sendMessage("Custom blocks: " + cb.registry().all().size() + " (" + plants + " plants)");
                s.sendMessage(String.join(", ", cb.registry().all().stream().map(BlockRegistry.Def::id).toList()));
            }
            case "give" -> {
                if (a.length < 3) { s.sendMessage("Usage: /dessea block give <player> <block> [amount]"); return; }
                Player p = Bukkit.getPlayerExact(a[1]);
                if (p == null) { s.sendMessage("Player '" + a[1] + "' is not online."); return; }
                int n = 1;
                if (a.length > 3) try { n = Integer.parseInt(a[3]); } catch (NumberFormatException ex) { s.sendMessage("Amount must be a number."); return; }
                ItemStack it = cb.createItem(a[2], n);
                if (it == null) { s.sendMessage("Unknown block '" + a[2] + "'."); return; }
                p.getInventory().addItem(it).values().forEach(l -> p.getWorld().dropItemNaturally(p.getLocation(), l));
                plugin.audit(s.getName(), "block give " + a[1] + " " + a[2] + " x" + n);
                s.sendMessage("Gave " + a[2] + " to " + p.getName() + ".");
            }
            case "set" -> { // test helper: replaces the block you are looking at
                if (!(s instanceof Player p) || a.length < 2) { s.sendMessage("Usage (player only): /dessea block set <block>"); return; }
                Block b = p.getTargetBlockExact(6);
                if (b == null) { s.sendMessage("Look at a block within 6 blocks."); return; }
                plugin.audit(s.getName(), "block set " + a[1] + " @ " + b.getX() + "," + b.getY() + "," + b.getZ());
                s.sendMessage(cb.set(b, a[1]) ? "Set." : "Unknown block '" + a[1] + "'.");
            }
            default -> s.sendMessage("Usage: /dessea block <list|give|set>");
        }
    }

    @Override
    public List<String> complete(CommandSender s, String[] a) {
        if (a.length == 1) return DiscoverySub.filter(List.of("list", "give", "set"), a[0]);
        if (a.length == 2 && a[0].equals("give")) return DiscoverySub.filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), a[1]);
        List<String> ids = plugin.blocks() == null ? List.of() : plugin.blocks().registry().all().stream().map(BlockRegistry.Def::id).toList();
        if ((a.length == 3 && a[0].equals("give")) || (a.length == 2 && a[0].equals("set"))) return DiscoverySub.filter(ids, a[a.length - 1]);
        return List.of();
    }
}
