package com.des.sea.item;

import com.des.sea.DesSeaPlugin;
import com.des.sea.core.DesModule;
import com.des.sea.discovery.DiscoveryEntry.Category;
import com.des.sea.discovery.DiscoveryRegistry;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.*;

/**
 * Config-defined collectible items (trophies, relics, materials, cosmetics). No weapons or armour.
 * Each item is a pack-modelled item (des_sea:item/<model>) and unlocks an "artifact.<id>" journal entry when given.
 */
public final class ItemManager implements DesModule {
    private final DesSeaPlugin plugin;
    private final NamespacedKey key;
    private final List<String> registered = new ArrayList<>();

    public ItemManager(DesSeaPlugin plugin) {
        this.plugin = plugin;
        this.key = new NamespacedKey(plugin, "item");
    }

    @Override public String id() { return "items"; }

    @Override
    public void enable() {
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("items");
        if (s == null) return;
        for (String id : s.getKeys(false)) {
            String name = s.getString(id + ".name", id);
            DiscoveryRegistry.register("artifact." + id, Category.ARTIFACT, name, "A relic of something vast.");
            registered.add("artifact." + id);
        }
        plugin.getLogger().info("Items loaded: " + registered.size());
    }

    @Override
    public void disable() {
        registered.forEach(DiscoveryRegistry::unregister);
        registered.clear();
    }

    public Set<String> ids() {
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("items");
        return s == null ? Set.of() : s.getKeys(false);
    }

    public ItemStack create(String id, int amount) {
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("items." + id);
        if (s == null) return null;
        ItemStack it = new ItemStack(Material.PAPER, Math.max(1, Math.min(64, amount)));
        ItemMeta m = it.getItemMeta();
        m.setItemModel(NamespacedKey.fromString("des_sea:item/" + s.getString("model", id)));
        m.displayName(Component.text(s.getString("name", id), NamedTextColor.AQUA).decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        for (String l : s.getStringList("lore")) lore.add(Component.text(l, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false));
        m.lore(lore);
        m.getPersistentDataContainer().set(key, PersistentDataType.STRING, id);
        it.setItemMeta(m);
        return it;
    }

    /** Gives the item (overflow drops at the player's feet) and unlocks its journal entry. */
    public boolean give(Player p, String id, int amount) {
        ItemStack it = create(id, amount);
        if (it == null) return false;
        p.getInventory().addItem(it).values().forEach(left -> p.getWorld().dropItemNaturally(p.getLocation(), left));
        if (plugin.modules().isRunning("journal")) plugin.discovery().unlock(p.getUniqueId(), "artifact." + id);
        return true;
    }
}
