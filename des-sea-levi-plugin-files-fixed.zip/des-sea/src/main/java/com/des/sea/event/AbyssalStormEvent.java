package com.des.sea.event;

import com.des.sea.DesSeaPlugin;
import com.des.sea.core.Biomes;
import net.kyori.adventure.text.Component;
import org.bukkit.Particle;
import org.bukkit.SoundCategory;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Dangerous underwater storm for divers inside des_sea biomes: violent currents, darkness, periodic pressure damage.
 * Vanilla potion effects and particles are placeholders for custom VFX. Damage/intervals are untuned config values.
 * Effects are short-lived and expire on their own, so stopping the event leaves nothing behind.
 */
public final class AbyssalStormEvent implements DesEvent {
    private final DesSeaPlugin plugin;
    private BukkitTask task;
    private int ticksLeft, elapsed;
    private Runnable onEnd;

    public AbyssalStormEvent(DesSeaPlugin plugin) { this.plugin = plugin; }

    @Override public String id() { return "abyssal_storm"; }
    @Override public boolean running() { return task != null; }

    @Override
    public void start(Runnable onEnd) {
        if (task != null) return;
        this.onEnd = onEnd;
        elapsed = 0;
        ticksLeft = plugin.getConfig().getInt("events.abyssal_storm.duration-seconds", 90) * 20;
        task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 0L, 20L);
    }

    private void tick() {
        ticksLeft -= 20;
        elapsed++;
        if (ticksLeft <= 0) {
            Runnable cb = onEnd;
            stop();
            if (cb != null) cb.run();
            return;
        }
        ThreadLocalRandom r = ThreadLocalRandom.current();
        double dmg = plugin.getConfig().getDouble("events.abyssal_storm.damage", 1.0);
        int every = Math.max(1, plugin.getConfig().getInt("events.abyssal_storm.damage-interval-seconds", 5));
        for (Player p : plugin.getServer().getOnlinePlayers()) {
            if (!p.isUnderWater() || Biomes.desBiome(p.getLocation()) == null) continue;
            p.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, 60, 0, true, false));
            p.setVelocity(p.getVelocity().add(new Vector(r.nextDouble(-0.25, 0.25), r.nextDouble(-0.1, 0.1), r.nextDouble(-0.25, 0.25))));
            for (int i = 0; i < 5; i++) { // capped
                p.spawnParticle(Particle.BUBBLE, p.getLocation().add(r.nextDouble(-4, 4), r.nextDouble(-2, 3), r.nextDouble(-4, 4)), 1, 0, 0.1, 0, 0.05);
            }
            if (elapsed % 3 == 0) p.playSound(p.getLocation(), "des_sea:event.abyssal_storm.rumble", SoundCategory.AMBIENT, 0.8f, 1f);
            if (dmg > 0 && elapsed % every == 0) p.damage(dmg);
            if (elapsed == 1) p.sendActionBar(Component.text("The water churns violently."));
        }
    }

    @Override
    public void stop() {
        if (task != null) task.cancel();
        task = null;
        onEnd = null;
    }
}
