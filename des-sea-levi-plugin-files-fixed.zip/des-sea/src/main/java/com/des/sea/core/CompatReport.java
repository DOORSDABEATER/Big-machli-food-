package com.des.sea.core;

import com.des.sea.DesSeaPlugin;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/** Collects real environment data from the running server so nobody has to type it out. */
public final class CompatReport {
    private static final String[] WATCHED = {"ModelEngine", "MythicMobs", "WorldGuard", "GriefPrevention",
            "GriefDefender", "Lands", "ItemsAdder", "Nexo", "Oraxen", "ProtocolLib", "packetevents"};

    private CompatReport() {
    }

    public static List<String> build(DesSeaPlugin plugin) {
        List<String> out = new ArrayList<>();
        out.add("DeS Sea compatibility report - " + Instant.now());
        out.add("Server: " + Bukkit.getName() + " " + Bukkit.getVersion());
        out.add("Minecraft: " + Bukkit.getMinecraftVersion());
        out.add("Java: " + System.getProperty("java.version") + " (" + System.getProperty("java.vendor") + ")");
        out.add("Plugin api-version: " + plugin.getPluginMeta().getAPIVersion());
        out.add("");
        out.add("Watched plugins:");
        for (String name : WATCHED) {
            Plugin p = Bukkit.getPluginManager().getPlugin(name);
            if (p == null) {
                out.add("  - " + name + ": not installed");
            } else {
                out.add("  - " + name + ": " + p.getPluginMeta().getVersion()
                        + (p.isEnabled() ? " (enabled)" : " (DISABLED)"));
            }
        }
        out.add("");
        out.add("Expected: ModelEngine " + plugin.getConfig().getString("expected.modelengine")
                + ", MythicMobs " + plugin.getConfig().getString("expected.mythicmobs"));
        out.add("");
        out.add("All plugins on server:");
        for (Plugin p : Bukkit.getPluginManager().getPlugins()) {
            out.add("  - " + p.getName() + " " + p.getPluginMeta().getVersion());
        }
        return out;
    }

    public static void write(DesSeaPlugin plugin) {
        try {
            Files.createDirectories(plugin.getDataFolder().toPath());
            Path file = plugin.getDataFolder().toPath().resolve("compat-report.txt");
            Files.write(file, build(plugin));
            plugin.getLogger().info("Wrote " + file);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not write compat report: " + e.getMessage());
        }
    }
}
