package com.des.sea.event;

import com.des.sea.DesSeaPlugin;
import com.des.sea.core.Biomes;
import org.bukkit.SoundCategory;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

/**
 * Ambient ocean audio is suppressed for players who are underwater or in a des_sea biome.
 * Limitation: stopSound only silences what the client is already playing in the AMBIENT category;
 * other layers (e.g. some vanilla water loops) may still be audible. Custom ambience checks isRunning() and stays quiet.
 */
public final class SilentWatersEvent implements DesEvent {
    private final DesSeaPlugin plugin;
    private BukkitTask task;
    private int ticksLeft;
    private Runnable onEnd;

    public SilentWatersEvent(DesSeaPlugin plugin) { this.plugin = plugin; }

    @Override public String id() { return "silent_waters"; }
    @Override public boolean running() { return task != null; }

    @Override
    public void start(Runnable onEnd) {
        if (task != null) return;
        this.onEnd = onEnd;
        ticksLeft = plugin.getConfig().getInt("events.silent_waters.duration-seconds", 120) * 20;
        task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 0L, 20L);
    }

    private void tick() {
        ticksLeft -= 20;
        if (ticksLeft <= 0) {
            Runnable cb = onEnd;
            stop();
            if (cb != null) cb.run();
            return;
        }
        for (Player p : plugin.getServer().getOnlinePlayers()) {
            if (p.isUnderWater() || Biomes.desBiome(p.getLocation()) != null) p.stopSound(SoundCategory.AMBIENT);
        }
    }

    @Override
    public void stop() {
        if (task != null) task.cancel();
        task = null;
        onEnd = null;
    }
}
