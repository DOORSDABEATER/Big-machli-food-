package com.des.sea.command;

import com.des.sea.DesSeaPlugin;
import com.des.sea.vehicle.VehicleType;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;

final class VehicleSub implements SubCommand {
    private final DesSeaPlugin plugin;

    VehicleSub(DesSeaPlugin plugin) { this.plugin = plugin; }

    @Override
    public void run(CommandSender s, String[] a) {
        if (!plugin.modules().isRunning("vehicles")) {
            s.sendMessage("The vehicles module is off. Set modules.vehicles: true in config.yml and /dessea reload.");
            return;
        }
        var vm = plugin.vehicles();
        String sub = a.length == 0 ? "list" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "list" -> {
                var list = vm.loadedVehicles();
                s.sendMessage("Vehicles in loaded chunks: " + list.size());
                list.forEach(v -> s.sendMessage("  " + vm.idOf(v) + " " + vm.typeOf(v) + " @ " + v.getWorld().getName() + " "
                        + v.getLocation().getBlockX() + " " + v.getLocation().getBlockY() + " " + v.getLocation().getBlockZ()));
            }
            case "give" -> {
                if (a.length < 3) { s.sendMessage("Usage: /dessea vehicle give <player> <type>"); return; }
                Player p = Bukkit.getPlayerExact(a[1]);
                VehicleType t = VehicleType.byId(a[2]);
                if (p == null) { s.sendMessage("Player '" + a[1] + "' is not online."); return; }
                if (t == null) { s.sendMessage("Unknown type '" + a[2] + "'. Use tab completion."); return; }
                p.getInventory().addItem(vm.createItem(t)).values().forEach(l -> p.getWorld().dropItemNaturally(p.getLocation(), l));
                plugin.audit(s.getName(), "vehicle give " + a[1] + " " + t.id);
                s.sendMessage("Gave " + t.display + " to " + p.getName() + ".");
            }
            case "remove" -> {
                if (a.length < 2) { s.sendMessage("Usage: /dessea vehicle remove <vehicle-id> confirm"); return; }
                if (a.length < 3 || !a[2].equalsIgnoreCase("confirm")) {
                    s.sendMessage("This deletes the vehicle. Run: /dessea vehicle remove " + a[1] + " confirm");
                    return;
                }
                boolean ok = vm.remove(a[1]);
                plugin.audit(s.getName(), "vehicle remove " + a[1]);
                s.sendMessage(ok ? "Removed " + a[1] + "." : "No loaded vehicle with id '" + a[1] + "' (its chunk may be unloaded).");
            }
            default -> s.sendMessage("Usage: /dessea vehicle <give|remove|list>");
        }
    }

    @Override
    public List<String> complete(CommandSender s, String[] a) {
        if (a.length == 1) return DiscoverySub.filter(List.of("give", "remove", "list"), a[0]);
        if (a.length == 2 && a[0].equals("give")) return DiscoverySub.filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), a[1]);
        if (a.length == 3 && a[0].equals("give")) return DiscoverySub.filter(Arrays.stream(VehicleType.values()).map(t -> t.id).toList(), a[2]);
        if (a.length == 2 && a[0].equals("remove") && plugin.vehicles() != null)
            return DiscoverySub.filter(plugin.vehicles().loadedVehicles().stream().map(v -> plugin.vehicles().idOf(v)).toList(), a[1]);
        if (a.length == 3 && a[0].equals("remove")) return DiscoverySub.filter(List.of("confirm"), a[2]);
        return List.of();
    }
}
