package com.des.sea.discovery;

import com.des.sea.DesSeaPlugin;
import com.des.sea.core.Biomes;
import com.des.sea.core.DesModule;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.*;

public final class DiscoveryManager implements DesModule {
    private final DesSeaPlugin plugin;
    private final File file;
    private final Map<UUID, Set<String>> data = new HashMap<>();
    private final Map<String, UUID> firsts = new HashMap<>();
    private BukkitTask scanTask, saveTask;
    private boolean dirty;

    public DiscoveryManager(DesSeaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "discoveries.yml");
    }

    @Override public String id() { return "journal"; }

    @Override
    public void enable() {
        load();
        scanTask = plugin.getServer().getScheduler().runTaskTimer(plugin, this::scanBiomes, 100L, 40L);
        saveTask = plugin.getServer().getScheduler().runTaskTimer(plugin, this::saveIfDirty, 6000L, 6000L);
    }

    @Override
    public void disable() {
        if (scanTask != null) scanTask.cancel();
        if (saveTask != null) saveTask.cancel();
        scanTask = saveTask = null;
        save();
    }

    private void scanBiomes() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            String biome = Biomes.desBiome(p.getLocation());
            if (biome != null) unlock(p.getUniqueId(), "biome." + biome);
            // Creature discovery: get within 12 blocks of a creature whose mob file applied a des_mob_<id> tag.
            for (org.bukkit.entity.Entity e : p.getNearbyEntities(12, 12, 12)) {
                for (String tag : e.getScoreboardTags()) {
                    if (tag.startsWith("des_mob_")) unlock(p.getUniqueId(), "creature." + tag.substring(8));
                }
            }
        }
    }

    public boolean has(UUID u, String entry) {
        return data.getOrDefault(u, Set.of()).contains(entry);
    }

    public Set<String> entries(UUID u) {
        return Collections.unmodifiableSet(data.getOrDefault(u, Set.of()));
    }

    /** Returns true only the first time this player unlocks the entry. Unknown entries are rejected. */
    public boolean unlock(UUID u, String entry) {
        DiscoveryEntry e = DiscoveryRegistry.get(entry);
        if (e == null) return false;
        if (!data.computeIfAbsent(u, k -> new LinkedHashSet<>()).add(entry)) return false;
        dirty = true;
        Player p = Bukkit.getPlayer(u);
        if (p != null && plugin.blueprints() != null && plugin.modules().isRunning("blueprints")) plugin.blueprints().onUnlock(p, entry);
        if (p != null) {
            p.showTitle(Title.title(Component.text("Discovery"), Component.text(e.name())));
        }
        if (!firsts.containsKey(entry) && e.category() == DiscoveryEntry.Category.BIOME) {
            firsts.put(entry, u);
            String who = p != null ? p.getName() : String.valueOf(u);
            Bukkit.broadcast(Component.text(who + " was the first to discover " + e.name() + "."));
        }
        return true;
    }

    public void reset(UUID u) {
        data.remove(u);
        dirty = true;
    }

    private void load() {
        data.clear();
        firsts.clear();
        if (!file.exists()) return;
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection pl = cfg.getConfigurationSection("players");
        if (pl != null) for (String k : pl.getKeys(false)) {
            try {
                data.put(UUID.fromString(k), new LinkedHashSet<>(pl.getStringList(k)));
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("Skipping bad UUID in discoveries.yml: " + k);
            }
        }
        ConfigurationSection fs = cfg.getConfigurationSection("firsts");
        if (fs != null) for (String k : fs.getKeys(false)) {
            String v = fs.getString(k);
            if (v != null) try { firsts.put(k.replace('|', '.'), UUID.fromString(v)); } catch (IllegalArgumentException ignored) {}
        }
    }

    private void saveIfDirty() { if (dirty) save(); }

    public void save() {
        YamlConfiguration cfg = new YamlConfiguration();
        data.forEach((u, set) -> cfg.set("players." + u, new ArrayList<>(set)));
        firsts.forEach((k, u) -> cfg.set("firsts." + k.replace('.', '|'), u.toString()));
        try {
            plugin.getDataFolder().mkdirs();
            cfg.save(file);
            dirty = false;
        } catch (IOException ex) {
            plugin.getLogger().severe("Could not save discoveries.yml: " + ex.getMessage());
        }
    }
}
