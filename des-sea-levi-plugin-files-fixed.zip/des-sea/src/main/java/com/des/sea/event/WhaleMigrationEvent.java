package com.des.sea.event;

import com.des.sea.DesSeaPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * A pod of whales passes through, driven by this event (velocity along a fixed heading), then they are removed.
 * Whales are spawned with the creature spawn command; MythicMobs must tag them des_mob_<id> (see mythic/Mobs).
 * Leftovers are tagged des_migrating so a crash can be cleaned up on the next start.
 */
public final class WhaleMigrationEvent implements DesEvent {
    private static final String TAG = "des_migrating";

    private final DesSeaPlugin plugin;
    private final Set<UUID> whales = new HashSet<>();
    private BukkitTask mover, claimer;
    private Vector heading;
    private Location origin;
    private String mobTag;
    private int ticksLeft;
    private Runnable onEnd;
    private boolean active;

    public WhaleMigrationEvent(DesSeaPlugin plugin) { this.plugin = plugin; }

    @Override public String id() { return "whale_migration"; }
    @Override public boolean running() { return active; }

    @Override
    public void onEnable() {
        for (World w : Bukkit.getWorlds()) for (Entity e : w.getEntities()) if (e.getScoreboardTags().contains(TAG)) e.remove();
    }

    @Override
    public void start(Runnable onEnd) {
        if (active) return;
        String tpl = plugin.getConfig().getString("spawns.spawn-command", "");
        String mob = plugin.getConfig().getString("events.whale_migration.mob", "des_prism_whale");
        if (tpl.isBlank()) { plugin.getLogger().info("whale_migration: spawns.spawn-command is empty; not started."); return; }
        List<String> worlds = plugin.getConfig().getStringList("world.allowed-worlds");
        List<Player> cands = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) if (p.isUnderWater() && worlds.contains(p.getWorld().getName())) cands.add(p);
        if (cands.isEmpty()) return;
        ThreadLocalRandom r = ThreadLocalRandom.current();
        Player p = cands.get(r.nextInt(cands.size()));
        double ang = r.nextDouble(Math.PI * 2), dist = plugin.getConfig().getDouble("events.whale_migration.start-distance", 110);
        origin = p.getLocation().add(Math.cos(ang) * dist, 0, Math.sin(ang) * dist);
        if (!origin.getBlock().isLiquid()) return;
        // heading passes the player at a 25-block offset so it is a fly-by, not a collision
        Vector side = new Vector(-Math.sin(ang), 0, Math.cos(ang)).multiply(r.nextBoolean() ? 25 : -25);
        heading = p.getLocation().toVector().add(side).subtract(origin.toVector()).setY(0).normalize();
        mobTag = "des_mob_" + mob.replaceFirst("^des_", "");
        int n = plugin.getConfig().getInt("events.whale_migration.count", 3);
        for (int i = 0; i < n; i++) {
            Location l = origin.clone().add(r.nextDouble(-8, 8), r.nextDouble(-3, 3), r.nextDouble(-8, 8));
            if (!l.getBlock().isLiquid()) l = origin;
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), tpl.replace("%mob%", mob).replace("%world%", l.getWorld().getName())
                    .replace("%x%", String.valueOf(l.getBlockX())).replace("%y%", String.valueOf(l.getBlockY())).replace("%z%", String.valueOf(l.getBlockZ())));
        }
        active = true;
        this.onEnd = onEnd;
        ticksLeft = plugin.getConfig().getInt("events.whale_migration.duration-seconds", 240) * 20;
        // claim the freshly spawned whales (the spawn command does not return entities)
        claimer = plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            for (Entity e : origin.getWorld().getNearbyEntities(origin, 30, 30, 30)) {
                if (e.getScoreboardTags().contains(mobTag) && !e.getScoreboardTags().contains(TAG)) { e.addScoreboardTag(TAG); whales.add(e.getUniqueId()); }
            }
            if (whales.isEmpty()) { plugin.getLogger().info("whale_migration: no whales were found after spawning; ending."); finish(); }
        }, 40L);
        mover = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 60L, 10L);
    }

    private void tick() {
        ticksLeft -= 10;
        if (ticksLeft <= 0) { finish(); return; }
        double speed = plugin.getConfig().getDouble("events.whale_migration.speed", 0.14);
        for (Iterator<UUID> it = whales.iterator(); it.hasNext(); ) {
            Entity e = Bukkit.getEntity(it.next());
            if (e == null || !e.isValid()) { it.remove(); continue; }
            e.setVelocity(heading.clone().multiply(speed));
        }
    }

    private void finish() {
        Runnable cb = onEnd;
        stop();
        if (cb != null) cb.run();
    }

    @Override
    public void stop() {
        if (mover != null) mover.cancel();
        if (claimer != null) claimer.cancel();
        mover = claimer = null;
        for (UUID u : whales) { Entity e = Bukkit.getEntity(u); if (e != null) e.remove(); }
        whales.clear();
        active = false;
        onEnd = null;
    }
}
