package com.des.sea.core;

/** A self-contained feature area (worldgen, creatures, vehicles...). Must clean up fully in disable(). */
public interface DesModule {
    String id();

    void enable();

    /** Cancel all tasks, remove temporary entities, save state. No leaks. */
    void disable();
}
