package com.des.sea.vent;

import com.des.sea.DesSeaPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;

/** Admin-marked magma vent positions (used by the Volcanic Awakening event). Persisted in vents.yml. */
public final class VentRegistry {
    public record Vent(String id, String world, int x, int y, int z) {
        public Location loc() { World w = Bukkit.getWorld(world); return w == null ? null : new Location(w, x + 0.5, y, z + 0.5); }
    }

    private final DesSeaPlugin plugin;
    private final File file;
    private final Map<String, Vent> vents = new LinkedHashMap<>();
    private boolean loaded;

    public VentRegistry(DesSeaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "vents.yml");
    }

    private void ensureLoaded() {
        if (loaded) return;
        loaded = true;
        if (!file.exists()) return;
        var c = YamlConfiguration.loadConfiguration(file);
        var sec = c.getConfigurationSection("vents");
        if (sec != null) for (String id : sec.getKeys(false))
            vents.put(id, new Vent(id, sec.getString(id + ".world", ""), sec.getInt(id + ".x"), sec.getInt(id + ".y"), sec.getInt(id + ".z")));
    }

    public Collection<Vent> all() { ensureLoaded(); return Collections.unmodifiableCollection(vents.values()); }

    public Vent add(Location l) {
        ensureLoaded();
        int n = 1;
        String id;
        do { id = "vent-" + String.format("%03d", n++); } while (vents.containsKey(id));
        Vent v = new Vent(id, l.getWorld().getName(), l.getBlockX(), l.getBlockY(), l.getBlockZ());
        vents.put(id, v);
        save();
        return v;
    }

    public boolean remove(String id) {
        ensureLoaded();
        boolean r = vents.remove(id) != null;
        if (r) save();
        return r;
    }

    private void save() {
        var c = new YamlConfiguration();
        for (Vent v : vents.values()) {
            c.set("vents." + v.id() + ".world", v.world());
            c.set("vents." + v.id() + ".x", v.x());
            c.set("vents." + v.id() + ".y", v.y());
            c.set("vents." + v.id() + ".z", v.z());
        }
        try {
            plugin.getDataFolder().mkdirs();
            c.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save vents.yml: " + e.getMessage());
        }
    }
}
