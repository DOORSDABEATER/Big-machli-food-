package com.des.sea.blueprint;

import com.des.sea.DesSeaPlugin;
import com.des.sea.core.DesModule;
import com.des.sea.vehicle.VehicleType;
import org.bukkit.Bukkit;
import org.bukkit.Keyed;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ShapelessRecipe;

import java.util.ArrayList;
import java.util.List;

/**
 * Vehicle recipes that only work once the matching blueprint is discovered (permanent, via the discovery data).
 * Which blueprint unlocks which vehicle, and the ingredients, come from config: the real materials are not decided yet,
 * so a vehicle with no ingredients configured simply has no recipe.
 */
public final class BlueprintManager implements DesModule, Listener {
    private final DesSeaPlugin plugin;
    private final List<NamespacedKey> registered = new ArrayList<>();

    public BlueprintManager(DesSeaPlugin plugin) { this.plugin = plugin; }

    @Override public String id() { return "blueprints"; }

    private NamespacedKey key(VehicleType t) { return new NamespacedKey(plugin, "vehicle_" + t.id); }

    @Override
    public void enable() {
        for (VehicleType t : VehicleType.values()) {
            List<String> ing = plugin.getConfig().getStringList("blueprints.recipes." + t.id);
            if (ing.isEmpty()) continue;
            if (ing.size() > 9) { plugin.getLogger().warning("Recipe for " + t.id + " has more than 9 ingredients; skipped."); continue; }
            ShapelessRecipe r = new ShapelessRecipe(key(t), plugin.vehicles().createItem(t));
            boolean ok = true;
            for (String s : ing) {
                Material m = Material.matchMaterial(s);
                if (m == null) { plugin.getLogger().warning("Unknown material '" + s + "' in recipe for " + t.id); ok = false; break; }
                r.addIngredient(m);
            }
            if (ok && Bukkit.addRecipe(r)) registered.add(key(t));
        }
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
        plugin.getLogger().info("Blueprint recipes registered: " + registered.size());
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll(this);
        for (NamespacedKey k : registered) Bukkit.removeRecipe(k);
        registered.clear();
    }

    /** Vehicle types a blueprint entry id (e.g. "blueprint.jet_engine") unlocks. */
    private List<VehicleType> unlocks(String entryId) {
        List<VehicleType> out = new ArrayList<>();
        String bp = entryId.substring("blueprint.".length());
        for (String v : plugin.getConfig().getStringList("blueprints.unlocks." + bp)) {
            VehicleType t = VehicleType.byId(v);
            if (t != null) out.add(t);
        }
        return out;
    }

    /** Called by the discovery system when a player newly unlocks an entry. */
    public void onUnlock(Player p, String entryId) {
        if (!entryId.startsWith("blueprint.")) return;
        for (VehicleType t : unlocks(entryId)) if (registered.contains(key(t))) p.discoverRecipe(key(t));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("blueprints.unlocks");
        if (s == null || !plugin.modules().isRunning("journal")) return;
        for (String bp : s.getKeys(false)) {
            if (plugin.discovery().has(p.getUniqueId(), "blueprint." + bp)) onUnlock(p, "blueprint." + bp);
        }
    }

    /** Without the blueprint the recipe cannot be crafted even if someone types the ingredients in. */
    @EventHandler
    public void onPrepare(PrepareItemCraftEvent e) {
        if (!(e.getRecipe() instanceof Keyed k) || !registered.contains(k.getKey())) return;
        if (e.getView().getPlayer() instanceof Player p && !p.hasDiscoveredRecipe(k.getKey())) e.getInventory().setResult(null);
    }
}
