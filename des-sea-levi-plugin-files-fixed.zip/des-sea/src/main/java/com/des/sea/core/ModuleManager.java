package com.des.sea.core;

import com.des.sea.DesSeaPlugin;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Level;

public final class ModuleManager {
    private final DesSeaPlugin plugin;
    private final Map<String, DesModule> modules = new LinkedHashMap<>();
    private final Map<String, Boolean> running = new LinkedHashMap<>();

    public ModuleManager(DesSeaPlugin plugin) {
        this.plugin = plugin;
    }

    public void register(DesModule module) {
        modules.put(module.id(), module);
    }

    public void enableConfigured() {
        for (DesModule m : modules.values()) {
            if (plugin.getConfig().getBoolean("modules." + m.id(), false)) {
                try {
                    m.enable();
                    running.put(m.id(), true);
                } catch (Throwable t) {
                    // One broken module must never take the server down
                    plugin.getLogger().log(Level.SEVERE, "Module failed to enable: " + m.id(), t);
                    running.put(m.id(), false);
                }
            }
        }
    }

    public void disableAll() {
        for (DesModule m : modules.values()) {
            if (Boolean.TRUE.equals(running.get(m.id()))) {
                try {
                    m.disable();
                } catch (Throwable t) {
                    plugin.getLogger().log(Level.SEVERE, "Module failed to disable: " + m.id(), t);
                }
            }
        }
        running.clear();
    }

    public boolean isRunning(String id) {
        return Boolean.TRUE.equals(running.get(id));
    }

    public Map<String, Boolean> status() {
        Map<String, Boolean> out = new LinkedHashMap<>();
        for (String id : modules.keySet()) out.put(id, Boolean.TRUE.equals(running.get(id)));
        return out;
    }
}
