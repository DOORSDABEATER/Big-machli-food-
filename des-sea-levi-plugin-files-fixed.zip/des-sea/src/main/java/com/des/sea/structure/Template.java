package com.des.sea.structure;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/** A captured structure: size, a block-data palette, and (x,y,z,paletteIndex) tuples relative to the min corner. Stored gzip-compressed text. */
public final class Template {
    public final int sx, sy, sz;
    public final List<String> palette;
    public final int[] blocks; // flat x,y,z,idx

    public Template(int sx, int sy, int sz, List<String> palette, int[] blocks) {
        this.sx = sx; this.sy = sy; this.sz = sz; this.palette = palette; this.blocks = blocks;
    }

    public int count() { return blocks.length / 4; }

    public static Template load(File f) throws IOException {
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream(f)), StandardCharsets.UTF_8))) {
            if (!"DESSEA-TEMPLATE 1".equals(r.readLine())) throw new IOException("Not a DeS template (bad header).");
            String[] sz = r.readLine().split(" ");
            int pc = Integer.parseInt(r.readLine().split(" ")[1]);
            List<String> pal = new ArrayList<>(pc);
            for (int i = 0; i < pc; i++) pal.add(r.readLine());
            r.readLine(); // "blocks"
            int[] arr = new int[4096];
            int n = 0;
            String line;
            while ((line = r.readLine()) != null) {
                String[] p = line.split(" ");
                if (n + 4 > arr.length) arr = Arrays.copyOf(arr, arr.length * 2);
                for (int k = 0; k < 4; k++) arr[n++] = Integer.parseInt(p[k]);
            }
            return new Template(Integer.parseInt(sz[1]), Integer.parseInt(sz[2]), Integer.parseInt(sz[3]), pal, Arrays.copyOf(arr, n));
        }
    }

    public void save(File f) throws IOException {
        f.getParentFile().mkdirs();
        try (BufferedWriter w = new BufferedWriter(new OutputStreamWriter(new GZIPOutputStream(new FileOutputStream(f)), StandardCharsets.UTF_8))) {
            w.write("DESSEA-TEMPLATE 1\n");
            w.write("size " + sx + " " + sy + " " + sz + "\n");
            w.write("palette " + palette.size() + "\n");
            for (String s : palette) w.write(s + "\n");
            w.write("blocks\n");
            for (int i = 0; i < blocks.length; i += 4) w.write(blocks[i] + " " + blocks[i + 1] + " " + blocks[i + 2] + " " + blocks[i + 3] + "\n");
        }
    }
}
