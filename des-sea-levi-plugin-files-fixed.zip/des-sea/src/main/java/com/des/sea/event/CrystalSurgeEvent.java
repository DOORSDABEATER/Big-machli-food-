package com.des.sea.event;

import com.des.sea.DesSeaPlugin;
import com.des.sea.core.Biomes;
import org.bukkit.Particle;
import org.bukkit.SoundCategory;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.concurrent.ThreadLocalRandom;

/** Particle/sound only, no entities, so cleanup is just cancelling one task. Visuals are placeholders for custom VFX. */
public final class CrystalSurgeEvent implements DesEvent {
    private final DesSeaPlugin plugin;
    private BukkitTask task;
    private int ticksLeft;
    private Runnable onEnd;

    public CrystalSurgeEvent(DesSeaPlugin plugin) { this.plugin = plugin; }

    @Override public String id() { return "crystal_surge"; }
    @Override public boolean running() { return task != null; }

    @Override
    public void start(Runnable onEnd) {
        if (task != null) return;
        this.onEnd = onEnd;
        ticksLeft = plugin.getConfig().getInt("events.crystal_surge.duration-seconds", 60) * 20;
        task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 0L, 10L);
    }

    private void tick() {
        ticksLeft -= 10;
        if (ticksLeft <= 0) {
            Runnable cb = onEnd;
            stop();
            if (cb != null) cb.run();
            return;
        }
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (Player p : plugin.getServer().getOnlinePlayers()) {
            if (!Biomes.in(p.getLocation(), "crystal_depths")) continue;
            for (int i = 0; i < 6; i++) { // hard cap per player per tick-run
                p.spawnParticle(Particle.END_ROD, p.getLocation().add(r.nextDouble(-10, 10), r.nextDouble(-2, 6), r.nextDouble(-10, 10)), 1, 0, 0.05, 0, 0.0);
            }
            if (ticksLeft % 40 == 0) p.playSound(p.getLocation(), "des_sea:event.crystal_surge.pulse", SoundCategory.AMBIENT, 0.7f, 1f);
        }
    }

    @Override
    public void stop() {
        if (task != null) task.cancel();
        task = null;
        onEnd = null;
    }
}
