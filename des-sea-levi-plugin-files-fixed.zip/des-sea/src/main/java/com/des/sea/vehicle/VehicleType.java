package com.des.sea.vehicle;

import java.util.Locale;

public enum VehicleType {
    MOTORBOAT("motorboat", "Standard Motorboat", false),
    JET_BOAT("jet_boat", "Jet Boat", false),
    RACING_JET_BOAT("racing_jet_boat", "Racing Jet Boat", false),
    MINI_SUB("mini_submarine", "Mini Submarine", true),
    DEEP_SUBMERSIBLE("deep_sea_submersible", "Deep-Sea Submersible", true),
    GHOST_VESSEL("ghost_vessel", "Ghost Vessel", false); // design decision: surface boat with a spectral wake

    public final String id;
    public final String display;
    public final boolean underwater;

    VehicleType(String id, String display, boolean underwater) {
        this.id = id;
        this.display = display;
        this.underwater = underwater;
    }

    public static VehicleType byId(String id) {
        if (id == null) return null;
        for (VehicleType t : values()) if (t.id.equals(id.toLowerCase(Locale.ROOT))) return t;
        return null;
    }
}
