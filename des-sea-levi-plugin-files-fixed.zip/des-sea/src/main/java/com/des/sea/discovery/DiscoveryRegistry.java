package com.des.sea.discovery;

import com.des.sea.discovery.DiscoveryEntry.Category;

import java.util.LinkedHashMap;
import java.util.Map;

/** Static entry definitions. Undiscovered entries show only the hint. More entries get added per phase. */
public final class DiscoveryRegistry {
    private static final Map<String, DiscoveryEntry> ENTRIES = new LinkedHashMap<>();

    private DiscoveryRegistry() {}

    private static void add(String id, Category c, String name, String hint) {
        ENTRIES.put(id, new DiscoveryEntry(id, c, name, hint));
    }

    static {
        add("biome.crystal_depths", Category.BIOME, "Crystal Depths", "A cold glow far below the shallows.");
        add("biome.black_trench", Category.BIOME, "The Black Trench", "Where the light gives up.");
        add("biome.verdant_reef", Category.BIOME, "Verdant Reef", "A living wall of colour.");
        add("biome.volcanic_expanse", Category.BIOME, "Volcanic Expanse", "The water here is never still.");
        add("biome.forgotten_waters", Category.BIOME, "The Forgotten Waters", "Sailors never came home.");
        add("biome.frozen_abyss", Category.BIOME, "Frozen Abyss", "Ice where no ice should be.");
        add("biome.drowned_kingdom", Category.BIOME, "The Drowned Kingdom", "Someone built this to last.");
        add("biome.luminous_wilds", Category.BIOME, "Luminous Wilds", "Something is glowing between the stalks.");
        for (String[] b : new String[][]{{"levi", "Levi, the Sovereign Beneath"}, {"krakthor", "Krak'thor, the World Devourer"},
                {"thalzar", "Thal'zar, the Drowned King"}, {"nyxara", "Nyxara, the Lightless Mother"},
                {"orovax", "Orovax, the Tidal Colossus"}}) {
            // Titles stay hidden until encountered; hints are deliberately vague.
            add("boss.encountered." + b[0], Category.BOSS_ENCOUNTERED, b[1], "Something answered.");
            add("boss.defeated." + b[0], Category.BOSS_DEFEATED, b[1], "Unknown.");
        }
        for (String[] b : new String[][]{{"drowned_admiral", "Drowned Admiral"}, {"the_lightless", "The Lightless"}, {"coral_colossus", "Coral Colossus"},
                {"vesper_the_pale", "Vesper, the Pale"}, {"abyssal_stalker_alpha", "Abyssal Stalker Alpha"}, {"reef_breaker", "Reef Breaker"},
                {"siren_matriarch", "Siren Matriarch"}, {"shipwreck_guardian", "Shipwreck Guardian"}, {"deepwater_devourer", "Deepwater Devourer"},
                {"ancient_shellback", "Ancient Shellback"}}) {
            add("boss.encountered." + b[0], Category.BOSS_ENCOUNTERED, b[1], "Something answered.");
            add("boss.defeated." + b[0], Category.BOSS_DEFEATED, b[1], "Unknown.");
        }
        String[][] creatures = {
            {"Moon Jelly"}, {"Glassfin"}, {"Reef Turtle"}, {"Deepwater Whale"}, {"Crystal Ray"}, {"Pearl Snail"}, {"Lanternfish"},
            {"Razorback Crab"}, {"Stormray"}, {"Ancient Shellback"}, {"Reefback Turtle"}, {"Deepwater Colossus"},
            {"Bloodfin Shark"}, {"Abyssal Eel"}, {"Dreadray"}, {"Reef Breaker"}, {"Voidfin Predator"}, {"Drowned Executioner"}, {"Abyssal Stalker"},
            {"The Watcher"}, {"Pale Serpent"}, {"Ghost Whale"}, {"Ancient Maw"}, {"Great Shellback"},
            {"Prism Whale"}, {"Magma Shellback"}, {"Frostfin Leviathan"}};
        for (String[] c : creatures) {
            String slug = c[0].toLowerCase().replace("the ", "").replace("'", "").replace(' ', '_');
            add("creature." + slug, Category.CREATURE, c[0], "Something moves out there.");
        }
        for (String[] bp : new String[][]{{"ancient_sailboat", "Ancient Sailboat Blueprint"}, {"jet_engine", "Jet Engine Blueprint"},
                {"mini_submarine", "Mini Submarine Blueprint"}, {"deep_sea_submersible", "Deep-Sea Submersible Blueprint"},
                {"ghost_vessel", "Ghost Vessel Blueprint"}}) {
            add("blueprint." + bp[0], Category.BLUEPRINT, bp[1], "A plan, waiting to be found.");
        }
    }

    public static void register(String id, Category c, String name, String hint) { add(id, c, name, hint); }
    public static void unregister(String id) { ENTRIES.remove(id); }

    public static DiscoveryEntry get(String id) { return ENTRIES.get(id); }
    public static boolean exists(String id) { return ENTRIES.containsKey(id); }
    public static Map<String, DiscoveryEntry> all() { return ENTRIES; }
}
