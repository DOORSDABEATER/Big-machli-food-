package com.des.sea.command;

import org.bukkit.command.CommandSender;

import java.util.List;

public interface SubCommand {
    /** args excludes the group name (e.g. for "/dessea event start x" args = ["start","x"]). */
    void run(CommandSender sender, String[] args);

    List<String> complete(CommandSender sender, String[] args);
}
