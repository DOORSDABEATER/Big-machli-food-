package com.des.sea.structure;

import com.des.sea.DesSeaPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.structure.StructureRotation;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.BooleanSupplier;

/**
 * Safe, tick-sliced structure placement with a rollback snapshot, plus template capture.
 * One job at a time. Nothing is changed unless EVERY target block is on the replaceable list.
 * Known limits: chests/inventories/entities are not captured or restored (replaceable list excludes containers,
 * so a placement over one is refused). UNTESTED.
 */
public final class StructurePlacer {
    private final DesSeaPlugin plugin;
    private final StructureRegistry registry;
    private final Map<String, Integer> rotations = new HashMap<>();
    private final Map<UUID, Location[]> selections = new HashMap<>();
    private boolean busy;
    private BukkitTask task;

    public StructurePlacer(DesSeaPlugin plugin, StructureRegistry registry) {
        this.plugin = plugin;
        this.registry = registry;
    }

    public boolean busy() { return busy; }
    public void setRotation(String type, int deg) { rotations.put(type, ((deg % 360) + 360) % 360); }
    public int rotation(String type) { return rotations.getOrDefault(type, 0); }

    public void select(Player p, int idx, Location l) {
        selections.computeIfAbsent(p.getUniqueId(), k -> new Location[2])[idx] = l.getBlock().getLocation();
    }

    public void shutdown() {
        if (task != null) task.cancel();
        task = null;
        busy = false;
    }

    private File templateFile(String name) { return new File(plugin.getDataFolder(), "templates/" + name + ".tpl.gz"); }
    private File snapFile(String id) { return new File(plugin.getDataFolder(), "rollbacks/" + id + ".snap.gz"); }
    public boolean hasTemplate(String name) { return templateFile(name).exists(); }

    private Set<Material> replaceable() {
        Set<Material> out = EnumSet.noneOf(Material.class);
        for (String s : plugin.getConfig().getStringList("structures.replaceable")) {
            Material m = Material.matchMaterial(s);
            if (m != null) out.add(m);
        }
        return out;
    }

    private void run(BooleanSupplier step, Runnable onFail) {
        task = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            try {
                if (step.getAsBoolean()) { task.cancel(); task = null; }
            } catch (Throwable t) {
                plugin.getLogger().severe("Structure job failed: " + t);
                task.cancel();
                task = null;
                onFail.run();
            }
        }, 1L, 1L);
    }

    private java.util.function.Consumer<Boolean> resultCb;

    private void done() { finish(false); }

    private void finish(boolean ok) {
        busy = false;
        var cb = resultCb;
        resultCb = null;
        if (cb != null) cb.accept(ok);
    }

    // ---------------- spawn ----------------

    /** Returns an error message, or null if the job started (progress/result is sent to 'who'). */
    public String spawn(CommandSender who, String type, Location center, int rot, String id) {
        return spawn(who, type, center, rot, id, null);
    }

    /** As above; 'result' (optional) is called on the main thread with true only if the structure was fully placed. */
    public String spawn(CommandSender who, String type, Location center, int rot, String id, java.util.function.Consumer<Boolean> result) {
        if (busy) return "Another structure job is running.";
        Template t;
        try {
            File f = templateFile(type);
            if (!f.exists()) return "No template '" + type + "' (expected " + f.getName() + " in plugins/DeSSea/templates).";
            t = Template.load(f);
        } catch (IOException | RuntimeException e) {
            return "Template could not be read: " + e.getMessage();
        }
        World w = center.getWorld();
        boolean swap = rot % 180 != 0;
        int dx = swap ? t.sz : t.sx, dz = swap ? t.sx : t.sz;
        int ox = center.getBlockX() - dx / 2, oy = center.getBlockY(), oz = center.getBlockZ() - dz / 2;
        if (oy < w.getMinHeight() || oy + t.sy > w.getMaxHeight()) return "Structure would leave the world height.";
        int radius = Math.min(plugin.getConfig().getInt("structures.max-footprint-radius", 160), Math.max(dx, dz) / 2 + 8);
        var res = registry.validate(w, type, center.getBlockX(), center.getBlockY(), center.getBlockZ(), radius);
        if (!res.ok()) return "Placement blocked: " + String.join(" ", res.problems());
        final String sid = id != null ? id : registry.nextId(type);

        BlockData[] pal = new BlockData[t.palette.size()];
        try {
            for (int i = 0; i < pal.length; i++) {
                BlockData d = Bukkit.createBlockData(t.palette.get(i));
                for (int k = 0; k < rot / 90; k++) d.rotate(StructureRotation.CLOCKWISE_90);
                pal[i] = d;
            }
        } catch (IllegalArgumentException e) {
            return "Template has a block state this server cannot parse: " + e.getMessage();
        }

        busy = true;
        resultCb = result;
        List<CompletableFuture<Chunk>> loads = new ArrayList<>();
        for (int cx = ox >> 4; cx <= (ox + dx - 1) >> 4; cx++)
            for (int cz = oz >> 4; cz <= (oz + dz - 1) >> 4; cz++) loads.add(w.getChunkAtAsync(cx, cz));
        who.sendMessage("Loading " + loads.size() + " chunks for " + sid + "...");
        CompletableFuture.allOf(loads.toArray(new CompletableFuture[0])).whenComplete((v, err) ->
                plugin.getServer().getScheduler().runTask(plugin, () -> {
                    if (err != null) { who.sendMessage("Chunk load failed: " + err.getMessage()); done(); return; }
                    scan(who, t, pal, w, ox, oy, oz, rot, type, sid, center);
                }));
        return null;
    }

    private int[] rotXZ(int x, int z, int rot, int sx, int sz) {
        return switch (rot) {
            case 90 -> new int[]{sz - 1 - z, x};
            case 180 -> new int[]{sx - 1 - x, sz - 1 - z};
            case 270 -> new int[]{z, sx - 1 - x};
            default -> new int[]{x, z};
        };
    }

    private void scan(CommandSender who, Template t, BlockData[] pal, World w, int ox, int oy, int oz, int rot, String type, String sid, Location center) {
        Set<Material> ok = replaceable();
        List<String> snap = new ArrayList<>();
        List<String> bad = new ArrayList<>();
        int[] idx = {0};
        int per = plugin.getConfig().getInt("structures.scan-per-tick", 20000);
        int n = t.count();
        Runnable fail = this::done;
        run(() -> {
            int end = Math.min(n, idx[0] + per);
            for (; idx[0] < end; idx[0]++) {
                int i = idx[0] * 4;
                int[] xz = rotXZ(t.blocks[i], t.blocks[i + 2], rot, t.sx, t.sz);
                Block b = w.getBlockAt(ox + xz[0], oy + t.blocks[i + 1], oz + xz[1]);
                if (!ok.contains(b.getType())) {
                    if (bad.size() < 5) bad.add(b.getType() + "@" + b.getX() + "," + b.getY() + "," + b.getZ());
                    else bad.add(null);
                    continue;
                }
                BlockData target = pal[t.blocks[i + 3]];
                if (!b.getBlockData().equals(target)) snap.add(b.getX() + " " + b.getY() + " " + b.getZ() + " " + b.getBlockData().getAsString());
            }
            if (idx[0] < n) return false;
            if (!bad.isEmpty()) {
                long total = bad.size();
                who.sendMessage("Refused: " + total + " target block(s) are not on structures.replaceable (nothing was changed). Examples: "
                        + bad.stream().filter(Objects::nonNull).toList());
                done();
                return true;
            }
            writeSnapshot(who, t, pal, w, ox, oy, oz, rot, type, sid, center, snap);
            return true;
        }, fail);
    }

    private void writeSnapshot(CommandSender who, Template t, BlockData[] pal, World w, int ox, int oy, int oz, int rot,
                               String type, String sid, Location center, List<String> snap) {
        who.sendMessage("Scan OK (" + snap.size() + " blocks will change). Saving rollback snapshot...");
        boolean[] state = new boolean[2]; // [0]=finished, [1]=failed
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                File f = snapFile(sid);
                f.getParentFile().mkdirs();
                try (var out = new java.util.zip.GZIPOutputStream(new java.io.FileOutputStream(f))) {
                    out.write(String.join("\n", snap).getBytes(StandardCharsets.UTF_8));
                }
            } catch (IOException e) {
                state[1] = true;
            }
            state[0] = true;
        });
        // wait (without blocking the main thread) for the snapshot to be safely on disk before touching the world
        run(() -> {
            if (!state[0]) return false;
            if (state[1]) { who.sendMessage("Could not write the rollback snapshot. Nothing was changed."); done(); return true; }
            apply(who, t, pal, w, ox, oy, oz, rot, type, sid, center);
            return true;
        }, this::done);
    }

    private void apply(CommandSender who, Template t, BlockData[] pal, World w, int ox, int oy, int oz, int rot, String type, String sid, Location center) {
        int[] idx = {0};
        int per = plugin.getConfig().getInt("structures.blocks-per-tick", 3000);
        int n = t.count();
        run(() -> {
            int end = Math.min(n, idx[0] + per);
            for (; idx[0] < end; idx[0]++) {
                int i = idx[0] * 4;
                int[] xz = rotXZ(t.blocks[i], t.blocks[i + 2], rot, t.sx, t.sz);
                w.getBlockAt(ox + xz[0], oy + t.blocks[i + 1], oz + xz[1]).setBlockData(pal[t.blocks[i + 3]], false);
            }
            if (idx[0] < n) return false;
            registry.register(sid, type, center, rot, who.getName());
            plugin.audit(who.getName(), "structure spawn " + sid);
            who.sendMessage("Placed " + sid + ".");
            finish(true);
            return true;
        }, () -> { who.sendMessage("Placement failed part-way. Use /dessea structure remove " + sid + " confirm to roll back."); registry.register(sid, type, center, rot, who.getName()); done(); });
    }

    // ---------------- rollback / remove ----------------

    /** Restores the snapshot (if any), deletes it, removes the registry record. then runs 'after' (may be null). */
    public String rollback(CommandSender who, String id, Runnable after) {
        if (busy) return "Another structure job is running.";
        var e = registry.get(id);
        if (e == null) return "No structure with id '" + id + "'.";
        World w = Bukkit.getWorld(e.world());
        if (w == null) return "World '" + e.world() + "' is not loaded.";
        File f = snapFile(id);
        if (!f.exists()) { registry.remove(id); who.sendMessage("No snapshot for " + id + ": only the registry record was removed, blocks are untouched."); if (after != null) after.run(); return null; }
        List<String> lines;
        try (var in = new java.util.zip.GZIPInputStream(new java.io.FileInputStream(f))) {
            lines = Arrays.asList(new String(in.readAllBytes(), StandardCharsets.UTF_8).split("\n"));
        } catch (IOException ex) {
            return "Could not read snapshot: " + ex.getMessage();
        }
        busy = true;
        Set<Long> chunks = new HashSet<>();
        for (String l : lines) {
            if (l.isBlank()) continue;
            String[] p = l.split(" ", 4);
            chunks.add((((long) (Integer.parseInt(p[0]) >> 4)) << 32) | ((Integer.parseInt(p[2]) >> 4) & 0xffffffffL));
        }
        List<CompletableFuture<Chunk>> loads = new ArrayList<>();
        for (long c : chunks) loads.add(w.getChunkAtAsync((int) (c >> 32), (int) c));
        CompletableFuture.allOf(loads.toArray(new CompletableFuture[0])).whenComplete((v, err) ->
                plugin.getServer().getScheduler().runTask(plugin, () -> {
                    if (err != null) { who.sendMessage("Chunk load failed: " + err.getMessage()); done(); return; }
                    int[] idx = {0};
                    int per = plugin.getConfig().getInt("structures.blocks-per-tick", 3000);
                    run(() -> {
                        int end = Math.min(lines.size(), idx[0] + per);
                        for (; idx[0] < end; idx[0]++) {
                            String l = lines.get(idx[0]);
                            if (l.isBlank()) continue;
                            String[] p = l.split(" ", 4);
                            w.getBlockAt(Integer.parseInt(p[0]), Integer.parseInt(p[1]), Integer.parseInt(p[2])).setBlockData(Bukkit.createBlockData(p[3]), false);
                        }
                        if (idx[0] < lines.size()) return false;
                        f.delete();
                        registry.remove(id);
                        plugin.audit(who.getName(), "structure rollback " + id);
                        who.sendMessage("Rolled back " + id + ".");
                        done();
                        if (after != null) after.run();
                        return true;
                    }, this::done);
                }));
        return null;
    }

    // ---------------- capture ----------------

    public String capture(Player p, String name) {
        if (busy) return "Another structure job is running.";
        Location[] sel = selections.get(p.getUniqueId());
        if (sel == null || sel[0] == null || sel[1] == null) return "Set both corners first with /dessea structure pos1 and pos2.";
        if (!sel[0].getWorld().equals(sel[1].getWorld())) return "Corners are in different worlds.";
        World w = sel[0].getWorld();
        int x0 = Math.min(sel[0].getBlockX(), sel[1].getBlockX()), x1 = Math.max(sel[0].getBlockX(), sel[1].getBlockX());
        int y0 = Math.min(sel[0].getBlockY(), sel[1].getBlockY()), y1 = Math.max(sel[0].getBlockY(), sel[1].getBlockY());
        int z0 = Math.min(sel[0].getBlockZ(), sel[1].getBlockZ()), z1 = Math.max(sel[0].getBlockZ(), sel[1].getBlockZ());
        long vol = (long) (x1 - x0 + 1) * (y1 - y0 + 1) * (z1 - z0 + 1);
        long max = plugin.getConfig().getLong("structures.max-capture-blocks", 500000);
        if (vol > max) return "Region has " + vol + " blocks; the limit is " + max + " (structures.max-capture-blocks).";
        if (!name.matches("[a-z0-9_\\-]+")) return "Template names may only use a-z, 0-9, _ and -.";
        boolean skipWater = plugin.getConfig().getBoolean("structures.capture-skip-water", true);

        busy = true;
        Map<String, Integer> palIdx = new LinkedHashMap<>();
        int[][] arr = {new int[4096]};
        int[] n = {0};
        long[] pos = {0};
        int sx = x1 - x0 + 1, sy = y1 - y0 + 1, sz = z1 - z0 + 1;
        int per = plugin.getConfig().getInt("structures.scan-per-tick", 20000);
        p.sendMessage("Capturing " + vol + " blocks...");
        run(() -> {
            long end = Math.min(vol, pos[0] + per);
            for (; pos[0] < end; pos[0]++) {
                long k = pos[0];
                int lx = (int) (k % sx), ly = (int) ((k / sx) % sy), lz = (int) (k / ((long) sx * sy));
                Block b = w.getBlockAt(x0 + lx, y0 + ly, z0 + lz);
                if (skipWater && b.getType() == Material.WATER && ((org.bukkit.block.data.Levelled) b.getBlockData()).getLevel() == 0) continue;
                int pi = palIdx.computeIfAbsent(b.getBlockData().getAsString(), s -> palIdx.size());
                if (n[0] + 4 > arr[0].length) arr[0] = Arrays.copyOf(arr[0], arr[0].length * 2);
                arr[0][n[0]++] = lx; arr[0][n[0]++] = ly; arr[0][n[0]++] = lz; arr[0][n[0]++] = pi;
            }
            if (pos[0] < vol) return false;
            Template t = new Template(sx, sy, sz, new ArrayList<>(palIdx.keySet()), Arrays.copyOf(arr[0], n[0]));
            plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
                try {
                    t.save(templateFile(name));
                    plugin.getServer().getScheduler().runTask(plugin, () -> { p.sendMessage("Saved template '" + name + "' (" + t.count() + " blocks)."); plugin.audit(p.getName(), "structure capture " + name); done(); });
                } catch (IOException e) {
                    plugin.getServer().getScheduler().runTask(plugin, () -> { p.sendMessage("Could not save template: " + e.getMessage()); done(); });
                }
            });
            return true;
        }, this::done);
        return null;
    }
}
