package com.des.sea.event;

import com.des.sea.DesSeaPlugin;
import com.des.sea.core.DesModule;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.*;

public final class EventManager implements DesModule {
    private final DesSeaPlugin plugin;
    private final File file;
    private final Map<String, DesEvent> events = new LinkedHashMap<>();
    private final Map<String, Long> lastEnd = new HashMap<>();
    private BukkitTask checkTask;

    public EventManager(DesSeaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "events.yml");
    }

    public void register(DesEvent e) { events.put(e.id(), e); }
    public Set<String> ids() { return events.keySet(); }
    public DesEvent get(String id) { return events.get(id); }

    @Override public String id() { return "events"; }

    @Override
    public void enable() {
        lastEnd.clear();
        if (file.exists()) {
            var cfg = YamlConfiguration.loadConfiguration(file);
            var sec = cfg.getConfigurationSection("last-end");
            if (sec != null) for (String k : sec.getKeys(false)) lastEnd.put(k, sec.getLong(k));
        }
        for (DesEvent e : events.values()) e.onEnable();
        long period = Math.max(1, plugin.getConfig().getLong("events.check-interval-minutes", 10)) * 1200L;
        checkTask = plugin.getServer().getScheduler().runTaskTimer(plugin, this::check, period, period);
    }

    @Override
    public void disable() {
        if (checkTask != null) checkTask.cancel();
        checkTask = null;
        for (DesEvent e : events.values()) if (e.running()) e.onShutdown();
        save();
    }

    private long active() { return events.values().stream().filter(DesEvent::running).count(); }

    private void check() {
        if (plugin.getServer().getOnlinePlayers().isEmpty()) return;
        if (active() >= plugin.getConfig().getInt("events.max-concurrent", 1)) return;
        List<DesEvent> pool = new ArrayList<>(events.values());
        Collections.shuffle(pool);
        for (DesEvent e : pool) {
            String base = "events." + e.id() + ".";
            if (!plugin.getConfig().getBoolean(base + "enabled", false) || e.running()) continue;
            long cooldownMs = plugin.getConfig().getLong(base + "cooldown-minutes", 180) * 60_000L;
            if (System.currentTimeMillis() - lastEnd.getOrDefault(e.id(), 0L) < cooldownMs) continue;
            if (Math.random() >= plugin.getConfig().getDouble(base + "chance", 0.05)) continue;
            start(e.id());
            return; // at most one event per check
        }
    }

    public boolean start(String id) {
        DesEvent e = events.get(id);
        if (e == null || e.running()) return false;
        e.start(() -> ended(id));
        if (!e.running()) { // the event declined to start (e.g. no suitable player), so no cooldown is spent
            plugin.getLogger().info("Event not started (conditions not met): " + id);
            return false;
        }
        plugin.getLogger().info("Event started: " + id);
        return true;
    }

    public boolean stop(String id) {
        DesEvent e = events.get(id);
        if (e == null || !e.running()) return false;
        e.stop();
        ended(id);
        return true;
    }

    private void ended(String id) {
        lastEnd.put(id, System.currentTimeMillis());
        save();
        plugin.getLogger().info("Event ended: " + id);
    }

    private void save() {
        var cfg = new YamlConfiguration();
        lastEnd.forEach((k, v) -> cfg.set("last-end." + k, v));
        try {
            plugin.getDataFolder().mkdirs();
            cfg.save(file);
        } catch (IOException ex) {
            plugin.getLogger().severe("Could not save events.yml: " + ex.getMessage());
        }
    }
}
