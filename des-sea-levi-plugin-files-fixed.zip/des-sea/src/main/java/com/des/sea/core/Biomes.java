package com.des.sea.core;

import org.bukkit.Location;

public final class Biomes {
    private Biomes() {}

    /** Returns the path of a des_sea biome at the location (e.g. "crystal_depths") or null. */
    public static String desBiome(Location l) {
        var key = l.getWorld().getBiome(l).getKey();
        return key.getNamespace().equals("des_sea") ? key.getKey() : null;
    }

    public static boolean in(Location l, String path) {
        return path.equals(desBiome(l));
    }
}
