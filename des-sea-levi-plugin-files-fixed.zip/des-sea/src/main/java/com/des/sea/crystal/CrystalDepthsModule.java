package com.des.sea.crystal;

import com.des.sea.DesSeaPlugin;
import com.des.sea.core.DesModule;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.SoundCategory;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.concurrent.ThreadLocalRandom;

/** Phase 2 prototype: biome ambience. Terrain/blocks come from the datapack + resource pack, not from here. */
public final class CrystalDepthsModule implements DesModule {
    private static final String BIOME_KEY = "des_sea:crystal_depths";
    private static final int PARTICLES_PER_PLAYER = 4; // hard cap per tick-run
    private final DesSeaPlugin plugin;
    private BukkitTask task;

    public CrystalDepthsModule(DesSeaPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public String id() {
        return "crystal_depths";
    }

    @Override
    public void enable() {
        task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 40L, 40L);
    }

    @Override
    public void disable() {
        if (task != null) {
            task.cancel();
            task = null;
        }
    }

    private void tick() {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (Player p : plugin.getServer().getOnlinePlayers()) {
            Location l = p.getLocation();
            if (!l.getWorld().getBiome(l).getKey().toString().equals(BIOME_KEY)) continue;
            for (int i = 0; i < PARTICLES_PER_PLAYER; i++) {
                Location at = l.clone().add(r.nextDouble(-8, 8), r.nextDouble(-3, 5), r.nextDouble(-8, 8));
                // Placeholder look: model-based/custom particle effects replace this later.
                p.spawnParticle(Particle.END_ROD, at, 1, 0, 0, 0, 0.0);
            }
            var silent = plugin.events() == null ? null : plugin.events().get("silent_waters");
            if (r.nextInt(12) == 0 && (silent == null || !silent.running())) {
                p.playSound(l, "des_sea:ambient.crystal_depths.mood", SoundCategory.AMBIENT, 0.6f, 1f);
            }
        }
    }
}
