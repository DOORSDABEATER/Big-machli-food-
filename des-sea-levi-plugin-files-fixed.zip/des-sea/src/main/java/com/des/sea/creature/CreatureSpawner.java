package com.des.sea.creature;

import com.des.sea.DesSeaPlugin;
import com.des.sea.core.Biomes;
import com.des.sea.core.DesModule;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Biome-based, chunk-safe creature spawning. Spawns go through a configurable MythicMobs console command,
 * and counting relies on the MythicMobs mob applying scoreboard tags (see mythic/Mobs/*.yml).
 * Behaviour/AI is defined in the MythicMobs mob files, not here.
 */
public final class CreatureSpawner implements DesModule {
    public static final String TAG = "des_creature";

    private record Entry(String mob, int weight, int min, int max, double minY, double maxY, boolean rare, double rareChance) {}

    private final DesSeaPlugin plugin;
    private BukkitTask task;
    private long lastRare;

    public CreatureSpawner(DesSeaPlugin plugin) { this.plugin = plugin; }

    @Override public String id() { return "creatures"; }

    @Override
    public void enable() {
        long iv = Math.max(20, plugin.getConfig().getLong("spawns.interval-ticks", 100));
        task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, iv, iv);
    }

    @Override
    public void disable() {
        if (task != null) task.cancel();
        task = null;
    }

    private void tick() {
        var cfg = plugin.getConfig();
        if (Bukkit.getTPS()[0] < cfg.getDouble("spawns.min-tps", 18)) return; // never add load to a struggling server
        String cmdTemplate = cfg.getString("spawns.spawn-command", "");
        if (cmdTemplate.isBlank()) return;
        int cap = cfg.getInt("spawns.cap-per-player", 8);
        double chance = cfg.getDouble("spawns.attempt-chance", 0.6);
        var bt = plugin.events() == null ? null : plugin.events().get("blood_tide");
        if (bt != null && bt.running()) chance = Math.min(1.0, chance * 1.5);
        ThreadLocalRandom r = ThreadLocalRandom.current();

        for (Player p : Bukkit.getOnlinePlayers()) {
            String biome = Biomes.desBiome(p.getLocation());
            if (biome == null || r.nextDouble() > chance) continue;
            List<Entry> table = table(biome);
            if (table.isEmpty()) continue;
            int near = 0;
            for (Entity e : p.getNearbyEntities(48, 48, 48)) if (e.getScoreboardTags().contains(TAG)) near++;
            if (near >= cap) continue;

            Entry pick = choose(table, r);
            if (pick == null) continue;
            if (pick.rare()) { // rare encounters stay rare: global cooldown plus their own chance
                long cd = cfg.getLong("spawns.rare-cooldown-minutes", 90) * 60_000L;
                if (System.currentTimeMillis() - lastRare < cd || r.nextDouble() > pick.rareChance()) continue;
            }
            int group = Math.min(pick.min() + r.nextInt(pick.max() - pick.min() + 1), cap - near);
            Location base = findSpot(p, biome, pick, r);
            if (base == null) continue;
            if (pick.rare()) lastRare = System.currentTimeMillis();
            for (int i = 0; i < group; i++) {
                Location at = i == 0 ? base : jitter(base, biome, r);
                if (at != null) spawn(cmdTemplate, pick.mob(), at);
            }
        }
    }

    private void spawn(String tpl, String mob, Location l) {
        String cmd = tpl.replace("%mob%", mob).replace("%world%", l.getWorld().getName())
                .replace("%x%", String.valueOf(l.getBlockX())).replace("%y%", String.valueOf(l.getBlockY())).replace("%z%", String.valueOf(l.getBlockZ()));
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
    }

    private Location findSpot(Player p, String biome, Entry e, ThreadLocalRandom r) {
        for (int tries = 0; tries < 6; tries++) {
            double ang = r.nextDouble(Math.PI * 2), dist = 24 + r.nextDouble(16);
            Location l = p.getLocation().add(Math.cos(ang) * dist, r.nextDouble(-10, 10), Math.sin(ang) * dist);
            if (valid(l, biome, e.minY(), e.maxY(), p)) return l;
        }
        return null;
    }

    private Location jitter(Location base, String biome, ThreadLocalRandom r) {
        Location l = base.clone().add(r.nextDouble(-4, 4), r.nextDouble(-2, 2), r.nextDouble(-4, 4));
        return valid(l, biome, -1e9, 1e9, null) ? l : null;
    }

    /** Only already-loaded chunks, in water, in the right biome, not in view of another player's face. */
    private boolean valid(Location l, String biome, double minY, double maxY, Player self) {
        World w = l.getWorld();
        if (l.getY() < minY || l.getY() > maxY) return false;
        if (l.getBlockY() < w.getMinHeight() + 2 || l.getBlockY() > w.getMaxHeight() - 2) return false;
        if (!w.isChunkLoaded(l.getBlockX() >> 4, l.getBlockZ() >> 4)) return false;
        if (!l.getBlock().isLiquid() || !l.clone().add(0, 1, 0).getBlock().isLiquid()) return false;
        if (!biome.equals(Biomes.desBiome(l))) return false;
        for (Player o : w.getPlayers()) if (o != self && o.getLocation().distanceSquared(l) < 20 * 20) return false;
        return true;
    }

    private List<Entry> table(String biome) {
        List<Entry> out = new ArrayList<>();
        for (Map<?, ?> m : plugin.getConfig().getMapList("spawns.tables." + biome)) {
            try {
                out.add(new Entry(String.valueOf(m.get("mob")), num(m.get("weight"), 10).intValue(), num(m.get("min"), 1).intValue(),
                        Math.max(num(m.get("min"), 1).intValue(), num(m.get("max"), 1).intValue()),
                        num(m.get("min-y"), -1e9).doubleValue(), num(m.get("max-y"), 1e9).doubleValue(),
                        Boolean.TRUE.equals(m.get("rare")), num(m.get("rare-chance"), 0.1).doubleValue()));
            } catch (RuntimeException ex) {
                plugin.getLogger().warning("Bad spawn entry in biome " + biome + ": " + m);
            }
        }
        return out;
    }

    private static Number num(Object o, Number def) { return o instanceof Number n ? n : def; }

    private static Entry choose(List<Entry> t, ThreadLocalRandom r) {
        int total = t.stream().mapToInt(Entry::weight).sum();
        if (total <= 0) return null;
        int x = r.nextInt(total);
        for (Entry e : t) { x -= e.weight(); if (x < 0) return e; }
        return null;
    }
}
