package com.des.sea.block;

import com.des.sea.DesSeaPlugin;
import com.des.sea.core.DesModule;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.type.Light;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.block.*;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

/**
 * Placement, breaking and protection for custom blocks. Items are vanilla block items (so claim plugins see a normal placement)
 * that carry a pack model and a tag; on placement the block is switched to the custom state. Physics, coral death and note
 * playing are suppressed for custom blocks. Glow uses invisible LIGHT blocks beside the block, removed when it is broken.
 * LIMITS: break speed and drops use the carrier's vanilla hardness; sea glass is opaque; light level is fixed per block.
 */
public final class CustomBlockManager implements DesModule, Listener {
    private final DesSeaPlugin plugin;
    private final BlockRegistry registry;
    private final NamespacedKey key;

    public CustomBlockManager(DesSeaPlugin plugin, BlockRegistry registry) {
        this.plugin = plugin;
        this.registry = registry;
        this.key = new NamespacedKey(plugin, "block");
    }

    @Override public String id() { return "blocks"; }
    @Override public void enable() { plugin.getServer().getPluginManager().registerEvents(this, plugin); }
    @Override public void disable() { HandlerList.unregisterAll(this); }

    public BlockRegistry registry() { return registry; }

    public ItemStack createItem(String id, int amount) {
        BlockRegistry.Def d = registry.get(id);
        if (d == null) return null;
        ItemStack it = new ItemStack(d.material(), Math.max(1, Math.min(64, amount)));
        ItemMeta m = it.getItemMeta();
        m.setItemModel(NamespacedKey.fromString("des_sea:block/" + id));
        m.displayName(Component.text(d.name(), NamedTextColor.WHITE).decoration(TextDecoration.ITALIC, false));
        m.getPersistentDataContainer().set(key, PersistentDataType.STRING, id);
        it.setItemMeta(m);
        return it;
    }

    /** Admin/worldgen placement without events. */
    public boolean set(Block b, String id) {
        var data = registry.data(id);
        if (data == null) return false;
        b.setBlockData(data, false);
        return true;
    }

    // ---------------- events ----------------

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        ItemStack it = e.getItemInHand();
        if (it == null || !it.hasItemMeta()) return;
        String id = it.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.STRING);
        BlockRegistry.Def d = id == null ? null : registry.get(id);
        if (d == null) return;
        Block b = e.getBlockPlaced();
        var data = d.data().clone();
        if (d.plant() && data instanceof org.bukkit.block.data.Waterlogged w) w.setWaterlogged(e.getBlockReplacedState().getType() == Material.WATER || w.isWaterlogged());
        b.setBlockData(data, false);
        if (d.light() > 0 && b.getRelative(BlockFace.UP).getType() == Material.WATER) lightAbove(b, d.light());
    }

    private void lightAbove(Block b, int level) {
        Block up = b.getRelative(BlockFace.UP);
        Light l = (Light) org.bukkit.Bukkit.createBlockData(Material.LIGHT);
        l.setLevel(Math.min(15, level));
        l.setWaterlogged(true);
        up.setBlockData(l, false);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Block b = e.getBlock();
        if (!registry.mayBeCustom(b.getType())) return;
        BlockRegistry.Def d = registry.lookup(b.getBlockData());
        if (d == null) return;
        e.setDropItems(false);
        if (e.getPlayer().getGameMode() != GameMode.CREATIVE) {
            ItemStack drop = createItem(d.id(), 1);
            if (drop != null) b.getWorld().dropItemNaturally(b.getLocation().add(0.5, 0.5, 0.5), drop);
        }
        if (d.light() > 0) removeLights(b);
    }

    /** Removes invisible LIGHT blocks touching a broken emissive block (restores water if they were waterlogged). */
    public void removeLights(Block b) {
        for (BlockFace f : new BlockFace[]{BlockFace.UP, BlockFace.DOWN, BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST}) {
            Block n = b.getRelative(f);
            if (n.getType() != Material.LIGHT) continue;
            boolean wet = n.getBlockData() instanceof Light l && l.isWaterlogged();
            n.setType(wet ? Material.WATER : Material.AIR, false);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPhysics(BlockPhysicsEvent e) {
        Material m = e.getBlock().getType();
        if (!registry.mayBeCustom(m)) return;
        if (registry.lookup(e.getBlock().getBlockData()) != null) e.setCancelled(true); // no popping off, no power updates
    }

    @EventHandler(ignoreCancelled = true)
    public void onFade(BlockFadeEvent e) {
        if (registry.mayBeCustom(e.getBlock().getType()) && registry.lookup(e.getBlock().getBlockData()) != null) e.setCancelled(true); // coral death
    }

    @EventHandler(ignoreCancelled = true)
    public void onNote(org.bukkit.event.block.NotePlayEvent e) {
        if (registry.lookup(e.getBlock().getBlockData()) != null) e.setCancelled(true);
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        Block b = e.getClickedBlock();
        if (b == null || b.getType() != Material.NOTE_BLOCK || e.getAction() != org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK) return;
        if (registry.lookup(b.getBlockData()) != null) e.setUseInteractedBlock(Event.Result.DENY); // no tuning, but placing against it still works
    }
}
