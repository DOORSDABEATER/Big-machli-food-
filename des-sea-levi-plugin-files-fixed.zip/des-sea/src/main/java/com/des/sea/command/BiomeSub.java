package com.des.sea.command;

import com.des.sea.DesSeaPlugin;
import com.des.sea.terrain.TerrainPopulator;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Locale;

final class BiomeSub implements SubCommand {
    private final DesSeaPlugin plugin;

    BiomeSub(DesSeaPlugin plugin) { this.plugin = plugin; }

    @Override
    public void run(CommandSender s, String[] a) {
        var tp = plugin.terrain();
        String sub = a.length == 0 ? "list" : a[0].toLowerCase(Locale.ROOT);
        boolean on = plugin.modules().isRunning("terrain");
        switch (sub) {
            case "list" -> {
                List<String> en = plugin.getConfig().getStringList("terrain.biomes");
                s.sendMessage("Terrain module: " + (on ? "running" : "OFF") + ". Biomes (enabled marked *):");
                for (String b : TerrainPopulator.BIOMES) s.sendMessage("  " + (en.contains(b) ? "* " : "  ") + b);
            }
            case "info" -> {
                if (a.length < 2 || !TerrainPopulator.BIOMES.contains(a[1])) { s.sendMessage("Usage: /dessea biome info <name>"); return; }
                s.sendMessage(a[1] + ": " + (plugin.getConfig().getStringList("terrain.biomes").contains(a[1]) ? "enabled" : "not enabled")
                        + ". Region cells: " + plugin.getConfig().getInt("terrain.cell-chunks", 12) * 16 + " blocks wide, density " + plugin.getConfig().getDouble("terrain.density", 0.3) + ".");
                s.sendMessage("Terrain only generates in NEW ocean chunks of allowed worlds. Datapack biome id: des_sea:" + a[1]);
            }
            case "locate" -> {
                if (!(s instanceof Player p) || a.length < 2) { s.sendMessage("Usage (player only): /dessea biome locate <name>"); return; }
                int[] r = tp.locate(p.getWorld(), a[1], p.getLocation().getBlockX(), p.getLocation().getBlockZ(), 6000);
                s.sendMessage(r == null ? "No region of '" + a[1] + "' within 6000 blocks (is it in terrain.biomes?)."
                        : "Nearest region centre: x=" + r[0] + " z=" + r[1] + " (terrain only exists where chunks were newly generated in ocean).");
            }
            case "set" -> {
                if (!(s instanceof Player p) || a.length < 2) { s.sendMessage("Usage (player only): /dessea biome set <name> confirm"); return; }
                if (!on) { s.sendMessage("Enable modules.terrain first."); return; }
                if (a.length < 3 || !a[2].equalsIgnoreCase("confirm")) { s.sendMessage("This changes ONLY the biome of your current chunk (not terrain). Run: /dessea biome set " + a[1] + " confirm"); return; }
                String err = tp.setBiomeOnly(p.getLocation().getChunk(), a[1]);
                plugin.audit(s.getName(), "biome set " + a[1]);
                s.sendMessage(err == null ? "Biome set for this chunk." : "Refused: " + err);
            }
            case "regenerate" -> {
                if (!(s instanceof Player p) || a.length < 2) { s.sendMessage("Usage (player only): /dessea biome regenerate <name> confirm"); return; }
                if (!on) { s.sendMessage("Enable modules.terrain first."); return; }
                if (a.length < 3 || !a[2].equalsIgnoreCase("confirm")) {
                    s.sendMessage("Re-applies terrain ONLY to chunks this plugin generated as '" + a[1] + "' within 3 chunks of you, skipping any that players have explored. Run: /dessea biome regenerate " + a[1] + " confirm");
                    return;
                }
                int[] r = tp.regenerate(p.getLocation(), a[1], 3);
                plugin.audit(s.getName(), "biome regenerate " + a[1]);
                s.sendMessage("Regenerated " + r[0] + " chunk(s); skipped " + r[1] + " (not ours, or explored).");
            }
            case "reload" -> { plugin.reload(); s.sendMessage("Reloaded."); }
            default -> s.sendMessage("Usage: /dessea biome <list|info|locate|set|regenerate|reload>");
        }
    }

    @Override
    public List<String> complete(CommandSender s, String[] a) {
        if (a.length == 1) return DiscoverySub.filter(List.of("list", "info", "locate", "set", "regenerate", "reload"), a[0]);
        if (a.length == 2 && !a[0].equals("list") && !a[0].equals("reload")) return DiscoverySub.filter(TerrainPopulator.BIOMES, a[1]);
        if (a.length == 3 && (a[0].equals("set") || a[0].equals("regenerate"))) return DiscoverySub.filter(List.of("confirm"), a[2]);
        return List.of();
    }
}
