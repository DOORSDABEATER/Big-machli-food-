package com.des.sea.event;

import com.des.sea.DesSeaPlugin;
import com.des.sea.vent.VentRegistry;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Admin-marked vents erupt: rising heat columns, periodic pulses that burn and launch anyone above a vent, and a chance
 * to release a rare creature. No block changes. Needs vents (/dessea vent add) within range of a diver.
 */
public final class VolcanicAwakeningEvent implements DesEvent {
    private final DesSeaPlugin plugin;
    private final List<VentRegistry.Vent> chosen = new ArrayList<>();
    private BukkitTask task;
    private int ticksLeft, elapsed, spawned;
    private Runnable onEnd;

    public VolcanicAwakeningEvent(DesSeaPlugin plugin) { this.plugin = plugin; }

    @Override public String id() { return "volcanic_awakening"; }
    @Override public boolean running() { return task != null; }

    @Override
    public void start(Runnable onEnd) {
        if (task != null) return;
        double range = plugin.getConfig().getDouble("events.volcanic_awakening.player-range", 100);
        for (VentRegistry.Vent v : plugin.vents().all()) {
            Location l = v.loc();
            if (l == null) continue;
            for (Player p : Bukkit.getOnlinePlayers()) if (p.getWorld().equals(l.getWorld()) && p.getLocation().distance(l) <= range) { chosen.add(v); break; }
            if (chosen.size() >= 12) break;
        }
        if (chosen.isEmpty()) return;
        this.onEnd = onEnd;
        elapsed = 0;
        spawned = 0;
        ticksLeft = plugin.getConfig().getInt("events.volcanic_awakening.duration-seconds", 150) * 20;
        task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 0L, 10L);
    }

    private void tick() {
        ticksLeft -= 10;
        elapsed++;
        if (ticksLeft <= 0) {
            Runnable cb = onEnd;
            stop();
            if (cb != null) cb.run();
            return;
        }
        ThreadLocalRandom r = ThreadLocalRandom.current();
        boolean pulse = elapsed % 6 == 0; // every 3 seconds
        double dmg = plugin.getConfig().getDouble("events.volcanic_awakening.damage", 3.0);
        String tpl = plugin.getConfig().getString("spawns.spawn-command", "");
        String mob = plugin.getConfig().getString("events.volcanic_awakening.creature", "");
        for (VentRegistry.Vent v : chosen) {
            Location l = v.loc();
            if (l == null || !l.getWorld().isChunkLoaded(l.getBlockX() >> 4, l.getBlockZ() >> 4)) continue;
            for (int i = 0; i < 4; i++) // capped
                l.getWorld().spawnParticle(Particle.DUST, l.clone().add(r.nextDouble(-0.6, 0.6), r.nextDouble(0, 8), r.nextDouble(-0.6, 0.6)), 1, 0, 0, 0, 0, new Particle.DustOptions(Color.fromRGB(249, 115, 22), 2f), true);
            l.getWorld().spawnParticle(Particle.LAVA, l.clone().add(0, 1, 0), 1, 0.4, 0.2, 0.4, 0, null, true);
            if (!pulse) continue;
            for (Player p : l.getWorld().getPlayers()) {
                Location pl = p.getLocation();
                if (Math.hypot(pl.getX() - l.getX(), pl.getZ() - l.getZ()) <= 4.5 && pl.getY() >= l.getY() && pl.getY() <= l.getY() + 14) {
                    p.damage(dmg);
                    p.setVelocity(p.getVelocity().add(new org.bukkit.util.Vector(0, 0.9, 0)));
                }
                if (pl.distance(l) <= 40) p.playSound(l, "des_sea:event.volcanic_awakening.eruption", SoundCategory.AMBIENT, 1.2f, 1f);
            }
            if (!tpl.isBlank() && !mob.isBlank() && spawned < 3 && r.nextDouble() < 0.25) {
                spawned++;
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), tpl.replace("%mob%", mob).replace("%world%", l.getWorld().getName())
                        .replace("%x%", String.valueOf(l.getBlockX())).replace("%y%", String.valueOf(l.getBlockY() + 3)).replace("%z%", String.valueOf(l.getBlockZ())));
            }
        }
    }

    @Override
    public void stop() {
        if (task != null) task.cancel();
        task = null;
        chosen.clear();
        onEnd = null;
    }
}
