package com.des.sea.command;

import com.des.sea.DesSeaPlugin;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Locale;

final class VentSub implements SubCommand {
    private final DesSeaPlugin plugin;

    VentSub(DesSeaPlugin plugin) { this.plugin = plugin; }

    @Override
    public void run(CommandSender s, String[] a) {
        var vr = plugin.vents();
        String sub = a.length == 0 ? "list" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "list" -> { s.sendMessage("Vents: " + vr.all().size()); vr.all().forEach(v -> s.sendMessage("  " + v.id() + " @ " + v.world() + " " + v.x() + " " + v.y() + " " + v.z())); }
            case "add" -> {
                if (!(s instanceof Player p)) { s.sendMessage("Players only: stand on the vent."); return; }
                var v = vr.add(p.getLocation());
                plugin.audit(s.getName(), "vent add " + v.id());
                s.sendMessage("Added " + v.id() + ".");
            }
            case "remove" -> {
                if (a.length < 2) { s.sendMessage("Usage: /dessea vent remove <id>"); return; }
                boolean ok = vr.remove(a[1]);
                plugin.audit(s.getName(), "vent remove " + a[1]);
                s.sendMessage(ok ? "Removed " + a[1] + "." : "No vent '" + a[1] + "'.");
            }
            default -> s.sendMessage("Usage: /dessea vent <list|add|remove>");
        }
    }

    @Override
    public List<String> complete(CommandSender s, String[] a) {
        if (a.length == 1) return DiscoverySub.filter(List.of("list", "add", "remove"), a[0]);
        if (a.length == 2 && a[0].equals("remove")) return DiscoverySub.filter(plugin.vents().all().stream().map(v -> v.id()).toList(), a[1]);
        return List.of();
    }
}
