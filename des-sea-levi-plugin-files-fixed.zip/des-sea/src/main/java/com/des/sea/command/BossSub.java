package com.des.sea.command;

import com.des.sea.DesSeaPlugin;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Levi has his own ritual module; every other boss declared under bosses.<id> uses the generic BossManager. */
final class BossSub implements SubCommand {
    private final DesSeaPlugin plugin;

    BossSub(DesSeaPlugin plugin) { this.plugin = plugin; }

    private List<String> allIds() {
        List<String> ids = new ArrayList<>();
        if (plugin.modules().isRunning("levi")) ids.add("levi");
        if (plugin.modules().isRunning("bosses")) ids.addAll(plugin.bosses().ids());
        return ids;
    }

    @Override
    public void run(CommandSender s, String[] a) {
        String sub = a.length == 0 ? "list" : a[0].toLowerCase(Locale.ROOT);
        if (sub.equals("list")) {
            List<String> ids = allIds();
            s.sendMessage(ids.isEmpty() ? "No boss modules are running. Enable modules.levi and/or modules.bosses in config.yml." : "Bosses: " + String.join(", ", ids));
            return;
        }
        if (a.length < 2) { s.sendMessage("Usage: /dessea boss <info|spawn|despawn|reset|altar> <boss>"); return; }
        String id = a[1].toLowerCase(Locale.ROOT);
        if (id.equals("levi")) { levi(s, sub, a); return; }
        if (!plugin.modules().isRunning("bosses")) { s.sendMessage("The bosses module is off. Set modules.bosses: true in config.yml."); return; }
        var bm = plugin.bosses();
        if (!bm.ids().contains(id)) { s.sendMessage("Unknown boss '" + id + "'."); return; }
        switch (sub) {
            case "info" -> s.sendMessage(bm.info(id));
            case "spawn" -> {
                String err = bm.start(id);
                plugin.audit(s.getName(), "boss spawn " + id);
                s.sendMessage(err == null ? "Started " + id + "." : "Cannot start: " + err);
            }
            case "despawn" -> { bm.retreat(id, "admin despawn"); plugin.audit(s.getName(), "boss despawn " + id); s.sendMessage(id + " retreated."); }
            case "reset" -> {
                if (a.length < 3 || !a[2].equalsIgnoreCase("confirm")) { s.sendMessage("This retreats " + id + " and clears its run state. Run: /dessea boss reset " + id + " confirm"); return; }
                bm.retreat(id, "admin reset");
                plugin.audit(s.getName(), "boss reset " + id);
                s.sendMessage(id + " reset.");
            }
            case "altar" -> {
                if (!(s instanceof Player p)) { s.sendMessage("Run this as a player, standing at the arena centre."); return; }
                bm.setArena(id, p.getLocation());
                plugin.audit(s.getName(), "boss arena " + id);
                s.sendMessage("Arena location saved.");
            }
            default -> s.sendMessage("Usage: /dessea boss <list|info|spawn|despawn|reset|altar> <boss>");
        }
    }

    private void levi(CommandSender s, String sub, String[] a) {
        if (!plugin.modules().isRunning("levi")) { s.sendMessage("The levi module is off. Set modules.levi: true in config.yml and /dessea reload."); return; }
        var lv = plugin.levi();
        switch (sub) {
            case "info" -> s.sendMessage(lv.info());
            case "spawn" -> {
                boolean ok = lv.forceAwaken();
                plugin.audit(s.getName(), "boss spawn levi");
                s.sendMessage(ok ? "Awakening started (ritual requirements skipped)." : "Cannot start: not DORMANT, or the altar is not set.");
            }
            case "despawn" -> { lv.adminRetreat("admin despawn"); plugin.audit(s.getName(), "boss despawn levi"); s.sendMessage("Levi retreated."); }
            case "reset" -> {
                if (a.length < 3 || !a[2].equalsIgnoreCase("confirm")) { s.sendMessage("This retreats Levi AND clears all ritual progress. Run: /dessea boss reset levi confirm"); return; }
                lv.adminReset();
                plugin.audit(s.getName(), "boss reset levi");
                s.sendMessage("Levi reset.");
            }
            case "altar" -> {
                if (!(s instanceof Player p)) { s.sendMessage("Run this as a player, standing where the altar is."); return; }
                lv.setAltar(p.getLocation());
                plugin.audit(s.getName(), "boss altar levi");
                s.sendMessage("Altar location saved.");
            }
            default -> s.sendMessage("Usage: /dessea boss <list|info|spawn|despawn|reset|altar> levi");
        }
    }

    @Override
    public List<String> complete(CommandSender s, String[] a) {
        if (a.length == 1) return DiscoverySub.filter(List.of("list", "info", "spawn", "despawn", "reset", "altar"), a[0]);
        if (a.length == 2) return DiscoverySub.filter(allIds(), a[1]);
        if (a.length == 3 && a[0].equals("reset")) return DiscoverySub.filter(List.of("confirm"), a[2]);
        return List.of();
    }
}
