package com.des.sea.command;

import com.des.sea.DesSeaPlugin;
import com.des.sea.discovery.DiscoveryEntry;
import com.des.sea.discovery.DiscoveryManager;
import com.des.sea.discovery.DiscoveryRegistry;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;

import java.util.List;
import java.util.Locale;

final class DiscoverySub implements SubCommand {
    private final DesSeaPlugin plugin;

    DiscoverySub(DesSeaPlugin plugin) { this.plugin = plugin; }

    @Override
    public void run(CommandSender s, String[] a) {
        DiscoveryManager dm = plugin.discovery();
        if (!plugin.modules().isRunning("journal")) {
            s.sendMessage("The journal module is off. Set modules.journal: true in config.yml and /dessea reload.");
            return;
        }
        if (a.length < 2) { s.sendMessage("Usage: /dessea discovery <inspect|reset|unlock> <player> [entry]"); return; }
        String sub = a[0].toLowerCase(Locale.ROOT);
        OfflinePlayer p = Bukkit.getOfflinePlayerIfCached(a[1]);
        if (p == null) { s.sendMessage("Unknown player '" + a[1] + "' (they must have joined before)."); return; }
        switch (sub) {
            case "inspect" -> {
                var set = dm.entries(p.getUniqueId());
                s.sendMessage(a[1] + " has " + set.size() + "/" + DiscoveryRegistry.all().size() + " entries:");
                set.forEach(id -> s.sendMessage("  " + id));
            }
            case "reset" -> {
                if (a.length < 3 || !a[2].equalsIgnoreCase("confirm")) {
                    s.sendMessage("This wipes all discoveries for " + a[1] + ". Run: /dessea discovery reset " + a[1] + " confirm");
                    return;
                }
                dm.reset(p.getUniqueId());
                plugin.audit(s.getName(), "discovery reset " + a[1]);
                s.sendMessage("Reset discoveries for " + a[1] + ".");
            }
            case "unlock" -> {
                if (a.length < 3) { s.sendMessage("Usage: /dessea discovery unlock <player> <entry>"); return; }
                DiscoveryEntry e = DiscoveryRegistry.get(a[2]);
                if (e == null) { s.sendMessage("Unknown entry '" + a[2] + "'. Use tab completion."); return; }
                boolean fresh = dm.unlock(p.getUniqueId(), a[2]);
                plugin.audit(s.getName(), "discovery unlock " + a[1] + " " + a[2]);
                s.sendMessage(fresh ? "Unlocked " + e.name() + " for " + a[1] + "." : a[1] + " already had that entry.");
            }
            default -> s.sendMessage("Usage: /dessea discovery <inspect|reset|unlock> <player> [entry]");
        }
    }

    @Override
    public List<String> complete(CommandSender s, String[] a) {
        if (a.length == 1) return filter(List.of("inspect", "reset", "unlock"), a[0]);
        if (a.length == 2) return filter(Bukkit.getOnlinePlayers().stream().map(p -> p.getName()).toList(), a[1]);
        if (a.length == 3 && a[0].equalsIgnoreCase("unlock")) return filter(List.copyOf(DiscoveryRegistry.all().keySet()), a[2]);
        if (a.length == 3 && a[0].equalsIgnoreCase("reset")) return filter(List.of("confirm"), a[2]);
        return List.of();
    }

    static List<String> filter(List<String> src, String prefix) {
        String p = prefix.toLowerCase(Locale.ROOT);
        return src.stream().filter(x -> x.toLowerCase(Locale.ROOT).startsWith(p)).toList();
    }
}
