package com.des.sea.terrain;

import com.des.sea.DesSeaPlugin;
import com.des.sea.block.BlockRegistry;
import com.des.sea.core.DesModule;
import org.bukkit.*;
import org.bukkit.block.Biome;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.persistence.PersistentDataType;

import java.util.*;

/**
 * Custom terrain for NEW ocean chunks only. After vanilla generates a chunk inside a custom-biome region, this swaps the
 * seabed for custom blocks, adds that biome's formations and vegetation, carves the Black Trench, and tags the chunk.
 * Existing (already generated) chunks are never touched unless an admin explicitly regenerates tagged chunks.
 * Everything stays inside the chunk (no neighbour writes), so there is no chunk-border corruption.
 * Regions are a deterministic function of world seed, so any chunk generated later lands in the right place.
 * UNTESTED: formation shapes and densities are first-pass designs.
 */
public final class TerrainPopulator implements DesModule, Listener {
    public static final List<String> BIOMES = List.of("crystal_depths", "black_trench", "verdant_reef", "volcanic_expanse",
            "forgotten_waters", "frozen_abyss", "drowned_kingdom", "luminous_wilds");

    private static final Set<Material> NATURAL = EnumSet.of(Material.SAND, Material.GRAVEL, Material.CLAY, Material.DIRT, Material.STONE,
            Material.ANDESITE, Material.DIORITE, Material.GRANITE, Material.DEEPSLATE, Material.TUFF, Material.SANDSTONE, Material.COBBLESTONE,
            Material.MUD, Material.PACKED_ICE, Material.ICE, Material.BLUE_ICE, Material.MAGMA_BLOCK, Material.BASALT, Material.SMOOTH_BASALT,
            Material.BLACKSTONE, Material.CALCITE, Material.DRIPSTONE_BLOCK, Material.COAL_ORE, Material.IRON_ORE, Material.COPPER_ORE, Material.GOLD_ORE);
    private static final Set<Material> WATERY = EnumSet.of(Material.WATER, Material.AIR, Material.CAVE_AIR, Material.SEAGRASS, Material.TALL_SEAGRASS,
            Material.KELP, Material.KELP_PLANT);

    private static final Map<String, String[]> PALETTE = Map.of(
            "crystal_depths", new String[]{"crystal_seabed", "crystal_stone"},
            "black_trench", new String[]{"abyssal_silt", "trenchstone"},
            "verdant_reef", new String[]{"reef_sand", "reef_rock"},
            "volcanic_expanse", new String[]{"ash_seabed", "volcanic_basalt"},
            "forgotten_waters", new String[]{"silted_sand", "sunken_iron"},
            "frozen_abyss", new String[]{"frost_ice", "glacial_stone"},
            "drowned_kingdom", new String[]{"ancient_tiles", "drowned_bricks"},
            "luminous_wilds", new String[]{"lumen_soil", "lumen_stone"});
    private static final Map<String, String[]> PLANTS = Map.of(
            "crystal_depths", new String[]{"crystal_bloom", "pearl_weed", "glow_anemone"},
            "black_trench", new String[]{"abyssal_fern", "trench_tendril", "lantern_bulb"},
            "verdant_reef", new String[]{"azure_coral_plant", "void_coral_plant", "blood_coral_plant", "reef_sprout"},
            "volcanic_expanse", new String[]{"magma_moss", "ash_reed"},
            "forgotten_waters", new String[]{"spectral_kelp", "ash_reed"},
            "frozen_abyss", new String[]{"frost_fern", "ice_lily"},
            "drowned_kingdom", new String[]{"pearl_weed", "spectral_kelp"},
            "luminous_wilds", new String[]{"luminous_kelp", "lumen_stalk", "glow_mushroom_small"});

    private static final Map<String, String[]> ORES = Map.of(
            "crystal_depths", new String[]{"tidal_quartz_ore"}, "black_trench", new String[]{"abyssal_iron_ore"},
            "verdant_reef", new String[]{"pearl_ore"}, "volcanic_expanse", new String[]{"abyssal_iron_ore"},
            "forgotten_waters", new String[]{"fossil_block"}, "frozen_abyss", new String[]{"tidal_quartz_ore"},
            "drowned_kingdom", new String[]{"fossil_block", "pearl_ore"}, "luminous_wilds", new String[]{"pearl_ore"});

    private final DesSeaPlugin plugin;
    private final BlockRegistry reg;
    private final NamespacedKey marker;
    private final Map<String, BlockData> cache = new HashMap<>();
    private boolean warnedBiome;

    public TerrainPopulator(DesSeaPlugin plugin, BlockRegistry reg) {
        this.plugin = plugin;
        this.reg = reg;
        this.marker = new NamespacedKey(plugin, "terrain");
    }

    @Override public String id() { return "terrain"; }
    @Override public void enable() { plugin.getServer().getPluginManager().registerEvents(this, plugin); }
    @Override public void disable() { HandlerList.unregisterAll(this); cache.clear(); }

    // ---------------------------------------------------------------- regions

    private List<String> enabled() {
        List<String> l = new ArrayList<>(plugin.getConfig().getStringList("terrain.biomes"));
        l.removeIf(b -> !BIOMES.contains(b));
        return l;
    }

    private int cellBlocks() { return Math.max(4, plugin.getConfig().getInt("terrain.cell-chunks", 12)) * 16; }

    private static long hash(long seed, long a, long b) {
        long h = seed + a * 0x9E3779B97F4A7C15L + b * 0xC2B2AE3D27D4EB4FL;
        h = (h ^ (h >>> 30)) * 0xBF58476D1CE4E5B9L;
        h = (h ^ (h >>> 27)) * 0x94D049BB133111EBL;
        return h ^ (h >>> 31);
    }

    /** The custom biome assigned to a region cell (or null). Pure function of seed, cell and config. */
    public String cellBiome(World w, int cellX, int cellZ) {
        List<String> en = enabled();
        if (en.isEmpty()) return null;
        long h = hash(w.getSeed(), cellX, cellZ);
        double roll = ((h >>> 11) & 0xFFFFFF) / (double) 0x1000000;
        if (roll > plugin.getConfig().getDouble("terrain.density", 0.3)) return null;
        return en.get((int) Long.remainderUnsigned(h >>> 5, en.size()));
    }

    public String regionBiome(World w, int cx, int cz) {
        int cc = cellBlocks() / 16;
        return cellBiome(w, Math.floorDiv(cx, cc), Math.floorDiv(cz, cc));
    }

    /** Nearest cell centre (in blocks) with the given biome, searching outwards; null if none within maxBlocks. */
    public int[] locate(World w, String biome, int fromX, int fromZ, int maxBlocks) {
        int cs = cellBlocks();
        int cx0 = Math.floorDiv(fromX, cs), cz0 = Math.floorDiv(fromZ, cs);
        int maxR = maxBlocks / cs + 1;
        int[] best = null;
        double bd = Double.MAX_VALUE;
        for (int r = 0; r <= maxR; r++) {
            for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) {
                if (Math.max(Math.abs(dx), Math.abs(dz)) != r) continue;
                if (!biome.equals(cellBiome(w, cx0 + dx, cz0 + dz))) continue;
                int x = (cx0 + dx) * cs + cs / 2, z = (cz0 + dz) * cs + cs / 2;
                double d = Math.hypot(x - fromX, z - fromZ);
                if (d < bd) { bd = d; best = new int[]{x, z}; }
            }
            if (best != null && r * cs > bd + cs) break;
        }
        return best;
    }

    private boolean worldAllowed(World w) {
        List<String> l = plugin.getConfig().getStringList("terrain.worlds");
        if (l.isEmpty()) l = plugin.getConfig().getStringList("world.allowed-worlds");
        return l.contains(w.getName());
    }

    private boolean inBounds(int wx, int wz) {
        var c = plugin.getConfig();
        if (!c.isConfigurationSection("terrain.bounds")) return true;
        return wx >= c.getInt("terrain.bounds.min-x", Integer.MIN_VALUE) && wx <= c.getInt("terrain.bounds.max-x", Integer.MAX_VALUE)
                && wz >= c.getInt("terrain.bounds.min-z", Integer.MIN_VALUE) && wz <= c.getInt("terrain.bounds.max-z", Integer.MAX_VALUE);
    }

    // ---------------------------------------------------------------- events

    @EventHandler
    public void onChunkLoad(ChunkLoadEvent e) {
        if (!e.isNewChunk()) return; // generated chunks are never touched here
        try {
            populate(e.getChunk(), null);
        } catch (Throwable t) {
            plugin.getLogger().warning("Terrain populate failed at chunk " + e.getChunk().getX() + "," + e.getChunk().getZ() + ": " + t);
        }
    }

    /** Re-applies terrain to chunks near a location that this plugin previously generated for 'biome'. Skips explored chunks. */
    public int[] regenerate(Location at, String biome, int radiusChunks) {
        int done = 0, skipped = 0;
        long maxInhabited = plugin.getConfig().getLong("structures.max-inhabited-ticks", 200);
        for (int dx = -radiusChunks; dx <= radiusChunks; dx++) for (int dz = -radiusChunks; dz <= radiusChunks; dz++) {
            int cx = (at.getBlockX() >> 4) + dx, cz = (at.getBlockZ() >> 4) + dz;
            if (!at.getWorld().isChunkGenerated(cx, cz)) continue;
            Chunk c = at.getWorld().getChunkAt(cx, cz);
            if (!biome.equals(c.getPersistentDataContainer().get(marker, PersistentDataType.STRING)) || c.getInhabitedTime() > maxInhabited) { skipped++; continue; }
            if (populate(c, biome)) done++;
        }
        return new int[]{done, skipped};
    }

    /** Sets only the biome of a chunk's water column (no terrain change). Refuses explored chunks. Returns null if ok, else a reason. */
    public String setBiomeOnly(Chunk c, String biome) {
        if (c.getInhabitedTime() > plugin.getConfig().getLong("structures.max-inhabited-ticks", 200)) return "This chunk looks explored by players.";
        if (!applyBiome(c, biome, c.getWorld().getMinHeight() + 4, c.getWorld().getSeaLevel())) return "Biome 'des_sea:" + biome + "' is not available (datapack not loaded?).";
        return null;
    }

    // ---------------------------------------------------------------- populate

    /** regenBiome != null means admin regeneration of a tagged chunk (skips trench carving, ignores the new-chunk rule). */
    private boolean populate(Chunk c, String regenBiome) {
        World w = c.getWorld();
        if (!worldAllowed(w) || !reg.all().iterator().hasNext()) return false;
        int cx = c.getX(), cz = c.getZ(), x0 = cx << 4, z0 = cz << 4;
        if (!inBounds(x0, z0)) return false;
        String biome = regenBiome != null ? regenBiome : regionBiome(w, cx, cz);
        if (biome == null || !enabled().contains(biome)) return false;

        int sea = w.getSeaLevel();
        int[][] fl = new int[16][16];
        int wet = 0;
        for (int x = 0; x < 16; x++) for (int z = 0; z < 16; z++) {
            fl[x][z] = w.getHighestBlockYAt(x0 + x, z0 + z, HeightMap.OCEAN_FLOOR);
            if (fl[x][z] <= sea - 4) wet++;
        }
        if (wet < 200) return false; // not an ocean chunk
        if (regenBiome == null) {
            int mid = fl[8][8];
            String bk = w.getBiome(x0 + 8, mid, z0 + 8).getKey().getKey();
            if (mid > sea - plugin.getConfig().getInt("terrain.min-depth", 10) || !bk.contains("ocean")) return false;
        }
        Random r = new Random(w.getSeed() ^ (cx * 341873128712L) ^ (cz * 132897987541L) ^ biome.hashCode());

        if (biome.equals("black_trench") && regenBiome == null) carveTrench(c, w, fl, x0, z0, r);
        surface(c, fl, biome);
        switch (biome) {
            case "crystal_depths" -> crystalDepths(c, fl, r);
            case "black_trench" -> blackTrench(c, fl, r);
            case "verdant_reef" -> verdantReef(c, fl, r);
            case "volcanic_expanse" -> volcanic(c, w, fl, r, x0, z0);
            case "forgotten_waters" -> forgottenWaters(c, fl, r);
            case "frozen_abyss" -> frozenAbyss(c, fl, r);
            case "drowned_kingdom" -> drownedKingdom(c, fl, r);
            case "luminous_wilds" -> luminousWilds(c, fl, r);
            default -> { }
        }
        ores(c, fl, biome, r);
        scatter(c, fl, biome, r);
        int minFloor = Integer.MAX_VALUE;
        for (int[] row : fl) for (int v : row) minFloor = Math.min(minFloor, v);
        applyBiome(c, biome, minFloor - 4, sea);
        c.getPersistentDataContainer().set(marker, PersistentDataType.STRING, biome);
        return true;
    }

    private boolean applyBiome(Chunk c, String biome, int fromY, int toY) {
        Biome b = Registry.BIOME.get(NamespacedKey.fromString("des_sea:" + biome));
        if (b == null) {
            if (!warnedBiome) { warnedBiome = true; plugin.getLogger().warning("Biome des_sea:" + biome + " not found (datapack not installed?). Terrain blocks are placed, biome is unchanged."); }
            return false;
        }
        World w = c.getWorld();
        for (int bx = 0; bx < 16; bx += 4) for (int bz = 0; bz < 16; bz += 4) for (int by = fromY; by <= toY; by += 4)
            w.setBiome((c.getX() << 4) + bx, by, (c.getZ() << 4) + bz, b);
        return true;
    }

    // ---------------------------------------------------------------- block helpers

    private BlockData d(String id) { return cache.computeIfAbsent(id, k -> { BlockData x = reg.data(k); if (x == null) throw new IllegalStateException("Unknown custom block " + k); return x; }); }
    private BlockData lightData(int level) { return cache.computeIfAbsent("light" + level, k -> Bukkit.createBlockData("minecraft:light[level=" + level + ",waterlogged=true]")); }
    private boolean natural(Material m) { return NATURAL.contains(m); }
    private boolean replaceable(Material m) { return WATERY.contains(m) || NATURAL.contains(m); }

    private void put(Chunk c, int lx, int y, int lz, String id) {
        if (lx < 0 || lx > 15 || lz < 0 || lz > 15 || y < c.getWorld().getMinHeight() || y >= c.getWorld().getMaxHeight()) return;
        Block b = c.getBlock(lx, y, lz);
        if (!replaceable(b.getType())) return;
        b.setBlockData(d(id), false);
    }

    private void glow(Chunk c, int lx, int y, int lz, int level) {
        if (lx < 0 || lx > 15 || lz < 0 || lz > 15) return;
        Block b = c.getBlock(lx, y, lz);
        if (b.getType() == Material.WATER) b.setBlockData(lightData(Math.min(15, level)), false);
    }

    private int lightOf(String id) { var dd = reg.get(id); return dd == null ? 0 : dd.light(); }

    // ---------------------------------------------------------------- surface

    private void surface(Chunk c, int[][] fl, String biome) {
        String[] p = PALETTE.get(biome);
        for (int x = 0; x < 16; x++) for (int z = 0; z < 16; z++) {
            int y = fl[x][z];
            Block top = c.getBlock(x, y, z);
            if (!natural(top.getType())) continue;
            top.setBlockData(d(p[0]), false);
            for (int k = 1; k <= 3; k++) {
                Block b = c.getBlock(x, y - k, z);
                if (natural(b.getType())) b.setBlockData(d(p[1]), false);
            }
        }
    }

    /** Small ore veins just under the seabed; they replace natural stone or this biome's own sub-surface block. */
    private void ores(Chunk c, int[][] fl, String biome, Random r) {
        String[] ores = ORES.get(biome);
        String sub = PALETTE.get(biome)[1];
        for (int v = 0, n = 6 + r.nextInt(5); v < n; v++) {
            String ore = ores[r.nextInt(ores.length)];
            int x = r.nextInt(16), z = r.nextInt(16), y = fl[x][z] - 2 - r.nextInt(8);
            for (int k = 0, m = 1 + r.nextInt(4); k < m; k++) {
                int ox = x + r.nextInt(3) - 1, oy = y + r.nextInt(3) - 1, oz = z + r.nextInt(3) - 1;
                if (ox < 0 || ox > 15 || oz < 0 || oz > 15) continue;
                Block b = c.getBlock(ox, oy, oz);
                var def = reg.lookup(b.getBlockData());
                if (natural(b.getType()) || (def != null && def.id().equals(sub))) b.setBlockData(d(ore), false);
            }
        }
    }

    private void scatter(Chunk c, int[][] fl, String biome, Random r) {
        String[] plants = PLANTS.get(biome);
        int n = 8 + r.nextInt(12);
        for (int i = 0; i < n; i++) {
            int x = r.nextInt(16), z = r.nextInt(16), y = fl[x][z] + 1;
            Block b = c.getBlock(x, y, z);
            if (b.getType() != Material.WATER || c.getBlock(x, y + 1, z).getType() != Material.WATER) continue;
            String id = plants[r.nextInt(plants.length)];
            b.setBlockData(d(id), false);
            int lv = lightOf(id);
            if (lv > 0) glow(c, x, y + 1, z, lv);
        }
    }

    private void plant(Chunk c, int lx, int y, int lz, String id) {
        if (lx < 0 || lx > 15 || lz < 0 || lz > 15) return;
        Block b = c.getBlock(lx, y, lz);
        if (b.getType() == Material.WATER) b.setBlockData(d(id), false);
    }

    // ---------------------------------------------------------------- Crystal Depths

    private void crystalDepths(Chunk c, int[][] fl, Random r) {
        int spires = 1 + r.nextInt(2);
        for (int i = 0; i < spires; i++) spire(c, fl, r, 4 + r.nextInt(8), 4 + r.nextInt(8), 10 + r.nextInt(16), 2 + r.nextInt(2), "deep_crystal", "resonance_crystal");
        int clusters = 1 + r.nextInt(3);
        for (int i = 0; i < clusters; i++) cluster(c, fl, r, 3 + r.nextInt(10), 3 + r.nextInt(10));
        for (int i = 0, n = r.nextInt(3); i < n; i++) { // suspended fragments
            int x = 2 + r.nextInt(12), z = 2 + r.nextInt(12), y = fl[x][z] + 8 + r.nextInt(14);
            put(c, x, y, z, "luminous_shards");
            glow(c, x, y + 1, z, 9);
        }
    }

    private void spire(Chunk c, int[][] fl, Random r, int x, int z, int h, int base, String body, String accent) {
        int y0 = fl[x][z];
        double lx = r.nextDouble(-0.25, 0.25), lz = r.nextDouble(-0.25, 0.25);
        for (int dy = 1; dy <= h; dy++) {
            double rad = base * (1.0 - dy / (double) (h + 1)) + 0.4;
            int ox = (int) Math.round(lx * dy), oz = (int) Math.round(lz * dy);
            int R = (int) Math.ceil(rad);
            for (int dx = -R; dx <= R; dx++) for (int dz = -R; dz <= R; dz++)
                if (dx * dx + dz * dz <= rad * rad) put(c, x + ox + dx, y0 + dy, z + oz + dz, (dy <= 2 && body.equals("deep_crystal")) ? "crystal_cliff_rock" : r.nextInt(7) == 0 ? accent : body);
            if (dy % 5 == 0) glow(c, x + ox + R + 1, y0 + dy, z + oz, lightOf(body));
        }
        int tx = x + (int) Math.round(lx * h), tz = z + (int) Math.round(lz * h);
        put(c, tx, y0 + h + 1, tz, "crystal_core");
        glow(c, tx, y0 + h + 2, tz, 15);
    }

    private void cluster(Chunk c, int[][] fl, Random r, int x, int z) {
        int y0 = fl[x][z];
        for (int k = 0; k < 5; k++) {
            double vx = r.nextDouble(-1, 1), vy = r.nextDouble(0.5, 1.3), vz = r.nextDouble(-1, 1);
            double len = Math.sqrt(vx * vx + vy * vy + vz * vz);
            int n = 3 + r.nextInt(6);
            for (int t = 1; t <= n; t++) put(c, x + (int) Math.round(vx / len * t), y0 + (int) Math.round(vy / len * t), z + (int) Math.round(vz / len * t), "luminous_shards");
        }
        glow(c, x, y0 + 2, z, 9);
    }

    // ---------------------------------------------------------------- Black Trench

    private double drop(World w, int wx, int wz) {
        int cs = cellBlocks();
        int cellX = Math.floorDiv(wx, cs), cellZ = Math.floorDiv(wz, cs);
        if (!"black_trench".equals(cellBiome(w, cellX, cellZ))) return 0;
        long h = hash(w.getSeed(), cellX, cellZ);
        double ang = ((h >>> 8) & 0xFFFF) / 65535.0 * Math.PI;
        double dx = wx - (cellX + 0.5) * cs, dz = wz - (cellZ + 0.5) * cs;
        double u = dx * Math.cos(ang) + dz * Math.sin(ang), v = -dx * Math.sin(ang) + dz * Math.cos(ang);
        double wave = 14 * Math.sin(u / 40.0 + (h & 0xFF));
        double half = 16 + 6 * Math.sin(u / 25.0);
        double t = 1 - Math.abs(v - wave) / half;
        double fade = 1 - Math.abs(u) / (cs / 2.0);
        if (t <= 0 || fade <= 0) return 0;
        return plugin.getConfig().getDouble("terrain.trench-depth", 28) * Math.min(1, t * 1.8) * Math.sqrt(fade);
    }

    private void carveTrench(Chunk c, World w, int[][] fl, int x0, int z0, Random r) {
        for (int x = 0; x < 16; x++) for (int z = 0; z < 16; z++) {
            int d0 = (int) Math.round(drop(w, x0 + x, z0 + z));
            int orig = fl[x][z];
            // exposed wall: neighbours that drop deeper than this column
            int dn = 0;
            for (int[] n : new int[][]{{1, 0}, {-1, 0}, {0, 1}, {0, -1}}) dn = Math.max(dn, (int) Math.round(drop(w, x0 + x + n[0], z0 + z + n[1])));
            if (dn > d0) {
                int topWall = orig - d0;
                for (int y = topWall; y > topWall - Math.min(40, dn - d0); y--) {
                    Block b = c.getBlock(x, y, z);
                    if (natural(b.getType())) b.setBlockData(d("trenchstone"), false);
                }
            }
            if (d0 <= 0) continue;
            int nf = Math.max(w.getMinHeight() + 6, orig - d0);
            for (int y = nf + 1; y <= orig; y++) c.getBlock(x, y, z).setType(Material.WATER, false);
            fl[x][z] = nf;
        }
    }

    private void blackTrench(Chunk c, int[][] fl, Random r) {
        for (int i = 0, n = 1 + r.nextInt(3); i < n; i++) spire(c, fl, r, 3 + r.nextInt(10), 3 + r.nextInt(10), 6 + r.nextInt(9), 1 + r.nextInt(2), "trenchstone", "trenchstone_bricks");
        for (int i = 0; i < 4; i++) { // glowing veins on the floor
            int x = r.nextInt(16), z = r.nextInt(16);
            Block b = c.getBlock(x, fl[x][z], z);
            if (natural(b.getType()) || reg.lookup(b.getBlockData()) != null) { b.setBlockData(d("trench_vein"), false); glow(c, x, fl[x][z] + 1, z, 7); }
        }
    }

    // ---------------------------------------------------------------- Verdant Reef

    private void verdantReef(Chunk c, int[][] fl, Random r) {
        String[] corals = {"azure_coral", "void_coral", "blood_coral"};
        for (int i = 0, n = 1 + r.nextInt(3); i < n; i++) coralTree(c, fl, r, 4 + r.nextInt(8), 4 + r.nextInt(8), 6 + r.nextInt(9), corals[r.nextInt(3)]);
        for (int i = 0, n = 1 + r.nextInt(2); i < n; i++) mound(c, fl, 3 + r.nextInt(10), 3 + r.nextInt(10), 3 + r.nextInt(3));
    }

    private void coralTree(Chunk c, int[][] fl, Random r, int x, int z, int h, String id) {
        int y0 = fl[x][z];
        for (int dy = 1; dy <= h; dy++) {
            put(c, x, y0 + dy, z, id);
            if (dy <= 3) { put(c, x + 1, y0 + dy, z, id); put(c, x, y0 + dy, z + 1, id); put(c, x + 1, y0 + dy, z + 1, id); }
        }
        int[][] dirs = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}, {1, 1}, {-1, -1}, {1, -1}, {-1, 1}};
        for (int b = 0, n = 3 + r.nextInt(3); b < n; b++) {
            int[] dd = dirs[r.nextInt(8)];
            int sy = (int) (h * (0.4 + 0.5 * r.nextDouble()));
            int len = 3 + r.nextInt(4), bx = x, by = y0 + sy, bz = z;
            for (int t = 1; t <= len; t++) { bx = x + dd[0] * t; bz = z + dd[1] * t; by = y0 + sy + t / 2; put(c, bx, by, bz, id); }
            for (int ex = -1; ex <= 1; ex++) for (int ey = -1; ey <= 1; ey++) for (int ez = -1; ez <= 1; ez++)
                if (Math.abs(ex) + Math.abs(ey) + Math.abs(ez) <= 2) put(c, bx + ex, by + ey, bz + ez, id);
        }
    }

    private void mound(Chunk c, int[][] fl, int x, int z, int rad) {
        int y0 = fl[x][z];
        for (int dx = -rad; dx <= rad; dx++) for (int dz = -rad; dz <= rad; dz++) {
            double dist = Math.hypot(dx, dz);
            if (dist > rad) continue;
            int hgt = (int) Math.round(rad * 0.7 * (1 - dist / rad));
            for (int dy = 1; dy <= hgt; dy++) put(c, x + dx, y0 + dy, z + dz, "reef_rock");
        }
    }

    // ---------------------------------------------------------------- Volcanic Expanse

    private void volcanic(Chunk c, World w, int[][] fl, Random r, int x0, int z0) {
        int x = 6 + r.nextInt(5), z = 6 + r.nextInt(5), R = 5 + r.nextInt(4), H = 5 + r.nextInt(5), y0 = fl[x][z];
        double[] fiss = {r.nextDouble(Math.PI * 2), r.nextDouble(Math.PI * 2), r.nextDouble(Math.PI * 2)};
        int centreTop = y0;
        for (int dx = -R; dx <= R; dx++) for (int dz = -R; dz <= R; dz++) {
            double dist = Math.hypot(dx, dz);
            if (dist > R) continue;
            int h = (int) Math.round(H * Math.pow(1 - dist / R, 1.1));
            if (dist < R * 0.3) h = Math.max(1, H - (int) Math.round(H * 0.55 * (1 - dist / (R * 0.3))));
            boolean fissure = false;
            double ang = Math.atan2(dz, dx);
            if (dist > R * 0.35) for (double f : fiss) if (Math.abs(Math.atan2(Math.sin(ang - f), Math.cos(ang - f))) < 0.12) fissure = true;
            for (int dy = 1; dy <= h; dy++) {
                boolean top = dy == h;
                put(c, x + dx, y0 + dy, z + dz, top && fissure ? "basalt_cracked" : "volcanic_basalt");
            }
            if (fissure) glow(c, x + dx, y0 + h + 1, z + dz, 10);
            if (dx == 0 && dz == 0) centreTop = y0 + h;
        }
        put(c, x, centreTop, z, "volcanic_core");
        glow(c, x, centreTop + 1, z, 14);
        Location vent = new Location(w, x0 + x + 0.5, centreTop + 1, z0 + z + 0.5);
        boolean dup = false;
        for (var v : plugin.vents().all()) { Location l = v.loc(); if (l != null && l.getWorld().equals(w) && l.distance(vent) < 6) dup = true; }
        if (!dup) plugin.vents().add(vent); // eruptions in the Volcanic Awakening event start here
        for (int i = 0, n = 3 + r.nextInt(4); i < n; i++) { // obsidian coral spikes around the base
            double a = r.nextDouble(Math.PI * 2);
            int sx = x + (int) Math.round(Math.cos(a) * (R + 2)), sz = z + (int) Math.round(Math.sin(a) * (R + 2));
            if (sx < 0 || sx > 15 || sz < 0 || sz > 15) continue;
            for (int dy = 1, hh = 2 + r.nextInt(3); dy <= hh; dy++) put(c, sx, fl[sx][sz] + dy, sz, "obsidian_coral");
        }
    }

    // ---------------------------------------------------------------- Forgotten Waters

    private void forgottenWaters(Chunk c, int[][] fl, Random r) {
        if (r.nextInt(2) == 0) wreck(c, fl, r);
        for (int i = 0, n = 2 + r.nextInt(3); i < n; i++) { // debris piles
            int x = 1 + r.nextInt(14), z = 1 + r.nextInt(14);
            for (int k = 0, m = 3 + r.nextInt(4); k < m; k++) put(c, x + r.nextInt(3) - 1, fl[x][z] + 1 + r.nextInt(2), z + r.nextInt(3) - 1, r.nextBoolean() ? "drowned_planks" : "drowned_wood");
        }
    }

    /** A small broken hull (14 long, fits inside one chunk). Larger ships come from captured templates. */
    private void wreck(Chunk c, int[][] fl, Random r) {
        boolean alongX = r.nextBoolean();
        int cx = 8, cz = 8, y0 = fl[8][8] + 1, half = 7, wmax = 3 + r.nextInt(2);
        for (int i = -half; i <= half; i++) {
            int w = (int) Math.round(wmax * (1 - 0.5 * Math.pow(i / (double) half, 2)));
            int hgt = 3 - (Math.abs(i) > 5 ? 1 : 0);
            for (int j = -w; j <= w; j++) {
                int x = alongX ? cx + i : cx + j, z = alongX ? cz + j : cz + i;
                put(c, x, y0, z, "drowned_planks"); // keel/floor
                if (Math.abs(j) == w) for (int h = 1; h <= hgt; h++) {
                    if (r.nextInt(5) == 0) continue; // broken planks
                    put(c, x, y0 + h, z, i % 2 == 0 ? "drowned_wood" : "drowned_planks");
                }
            }
        }
        for (int h = 1, mast = 4 + r.nextInt(3); h <= mast; h++) put(c, cx, y0 + h, cz, "drowned_wood");
    }

    // ---------------------------------------------------------------- Frozen Abyss

    private void frozenAbyss(Chunk c, int[][] fl, Random r) {
        for (int i = 0, n = 1 + r.nextInt(3); i < n; i++) {
            int x = 3 + r.nextInt(10), z = 3 + r.nextInt(10), h = 8 + r.nextInt(13), rad = 1 + r.nextInt(2), y0 = fl[x][z];
            for (int dy = 1; dy <= h; dy++) {
                double rr = rad * (1 - 0.6 * dy / (double) h) + 0.3;
                int R = (int) Math.ceil(rr);
                for (int dx = -R; dx <= R; dx++) for (int dz = -R; dz <= R; dz++)
                    if (dx * dx + dz * dz <= rr * rr) put(c, x + dx, y0 + dy, z + dz, dy <= 3 ? "glacial_stone" : (r.nextInt(12) == 0 ? "frost_crystal" : "frost_ice"));
            }
            glow(c, x + rad + 1, y0 + h / 2, z, 9);
        }
        for (int i = 0, n = 2 + r.nextInt(3); i < n; i++) { // frozen coral domes
            int x = 2 + r.nextInt(12), z = 2 + r.nextInt(12), y0 = fl[x][z];
            for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) for (int dy = 1; dy <= 2; dy++)
                if (dx * dx + dz * dz + dy * dy * 2 <= 6) put(c, x + dx, y0 + dy, z + dz, "frozen_coral");
        }
    }

    // ---------------------------------------------------------------- Drowned Kingdom (ruins; the city itself comes from templates)

    private void drownedKingdom(Chunk c, int[][] fl, Random r) {
        for (int i = 0, n = 2 + r.nextInt(3); i < n; i++) {
            int x = 2 + r.nextInt(12), z = 2 + r.nextInt(12), h = 5 + r.nextInt(6), y0 = fl[x][z];
            for (int dy = 1; dy <= h; dy++) put(c, x, y0 + dy, z, "tidebound_pillar");
            put(c, x, y0 + h + 1, z, "royal_gold_trim");
        }
        int x = 2 + r.nextInt(5), z = 2 + r.nextInt(12), len = 5 + r.nextInt(4), hh = 2 + r.nextInt(4);
        for (int i = 0; i < len; i++) for (int dy = 1; dy <= hh; dy++) if (r.nextInt(5) != 0) put(c, x + i, fl[Math.min(15, x + i)][z] + dy, z, "drowned_bricks");
    }

    // ---------------------------------------------------------------- Luminous Wilds

    private void luminousWilds(Chunk c, int[][] fl, Random r) {
        for (int i = 0, n = 2 + r.nextInt(4); i < n; i++) {
            int x = 1 + r.nextInt(14), z = 1 + r.nextInt(14), h = 8 + r.nextInt(19), y0 = fl[x][z];
            for (int dy = 1; dy <= h; dy++) {
                plant(c, x, y0 + dy, z, dy == h ? "giant_kelp_top" : "giant_kelp_stalk");
                if (dy % 4 == 0) glow(c, x + 1, y0 + dy, z, 8);
            }
        }
        for (int i = 0, n = 1 + r.nextInt(2); i < n; i++) { // glowing mushrooms
            int x = 4 + r.nextInt(8), z = 4 + r.nextInt(8), h = 3 + r.nextInt(4), cap = 2 + r.nextInt(2), y0 = fl[x][z];
            for (int dy = 1; dy <= h; dy++) put(c, x, y0 + dy, z, "lumen_stone");
            for (int dx = -cap; dx <= cap; dx++) for (int dz = -cap; dz <= cap; dz++) for (int dy = 0; dy <= cap; dy++)
                if (dx * dx + dz * dz + dy * dy <= cap * cap + 1 && !(dx == 0 && dz == 0 && dy == 0)) put(c, x + dx, y0 + h + dy, z + dz, "glow_cap");
            glow(c, x, y0 + h + cap + 1, z, 10);
        }
    }
}
