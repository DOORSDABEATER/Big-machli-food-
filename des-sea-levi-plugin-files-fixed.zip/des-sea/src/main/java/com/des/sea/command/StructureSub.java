package com.des.sea.command;

import com.des.sea.DesSeaPlugin;
import com.des.sea.structure.StructureRegistry;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Locale;

final class StructureSub implements SubCommand {
    private final DesSeaPlugin plugin;

    StructureSub(DesSeaPlugin plugin) { this.plugin = plugin; }

    @Override
    public void run(CommandSender s, String[] a) {
        if (!plugin.modules().isRunning("structures")) {
            s.sendMessage("The structures module is off. Set modules.structures: true in config.yml and /dessea reload.");
            return;
        }
        StructureRegistry sr = plugin.structures();
        String sub = a.length == 0 ? "list" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "list" -> {
                s.sendMessage("Types: " + String.join(", ", StructureRegistry.TYPES));
                s.sendMessage("Registered: " + sr.all().size());
                sr.all().forEach(e -> s.sendMessage("  " + e.id() + " @ " + e.world() + " " + e.x() + " " + e.y() + " " + e.z()));
            }
            case "info" -> {
                if (a.length < 2) { s.sendMessage("Usage: /dessea structure info <id>"); return; }
                var e = sr.get(a[1]);
                s.sendMessage(e == null ? "No structure with id '" + a[1] + "'."
                        : e.id() + ": type=" + e.type() + " pos=" + e.x() + "," + e.y() + "," + e.z() + " rot=" + e.rotation()
                        + " by=" + e.createdBy());
            }
            case "preview" -> {
                // Currently validation only: shows exactly what would block a placement.
                if (a.length < 2) { s.sendMessage("Usage: /dessea structure preview <type> [x y z]"); return; }
                Location at = target(s, a, 2);
                if (at == null) { s.sendMessage("Give coordinates or run this as a player."); return; }
                var r = sr.validate(at.getWorld(), a[1], at.getBlockX(), at.getBlockY(), at.getBlockZ());
                s.sendMessage(r.ok() ? "Placement would be allowed (template placement is not built yet)." : "Placement blocked:");
                r.problems().forEach(p -> s.sendMessage("  - " + p));
            }
            case "locate" -> {
                if (a.length < 2 || !(s instanceof Player p)) { s.sendMessage("Usage (player only): /dessea structure locate <type>"); return; }
                var n = sr.nearest(a[1], p.getLocation());
                s.sendMessage(n.map(e -> "Nearest " + e.id() + " at " + e.x() + " " + e.y() + " " + e.z()).orElse("None registered."));
            }
            case "remove" -> {
                if (a.length < 2) { s.sendMessage("Usage: /dessea structure remove <id> confirm"); return; }
                if (a.length < 3 || !a[2].equalsIgnoreCase("confirm")) {
                    s.sendMessage("This ROLLS BACK the structure's blocks from its snapshot (or only drops the record if none exists). Run: /dessea structure remove " + a[1] + " confirm");
                    return;
                }
                plugin.audit(s.getName(), "structure remove " + a[1]);
                String err = plugin.placer().rollback(s, a[1], null);
                if (err != null) s.sendMessage(err);
            }
            case "spawn" -> {
                if (a.length < 2) { s.sendMessage("Usage: /dessea structure spawn <type> [x y z]"); return; }
                Location at = target(s, a, 2);
                if (at == null) { s.sendMessage("Give coordinates or run this as a player."); return; }
                String err = plugin.placer().spawn(s, a[1], at, plugin.placer().rotation(a[1]), null);
                if (err != null) s.sendMessage(err);
            }
            case "rotate" -> {
                if (a.length < 3) { s.sendMessage("Usage: /dessea structure rotate <type> <0|90|180|270>"); return; }
                try {
                    int deg = Integer.parseInt(a[2]);
                    if (deg % 90 != 0) { s.sendMessage("Angle must be a multiple of 90."); return; }
                    plugin.placer().setRotation(a[1], deg);
                    s.sendMessage("Next spawn of '" + a[1] + "' will use rotation " + plugin.placer().rotation(a[1]) + ".");
                } catch (NumberFormatException ex) { s.sendMessage("Angle must be a number."); }
            }
            case "regenerate" -> {
                if (a.length < 2) { s.sendMessage("Usage: /dessea structure regenerate <id> confirm"); return; }
                var e = sr.get(a[1]);
                if (e == null) { s.sendMessage("No structure with id '" + a[1] + "'."); return; }
                if (a.length < 3 || !a[2].equalsIgnoreCase("confirm")) {
                    s.sendMessage("This rolls back " + a[1] + " and places it again from its template. Run: /dessea structure regenerate " + a[1] + " confirm");
                    return;
                }
                var w = plugin.getServer().getWorld(e.world());
                if (w == null) { s.sendMessage("World '" + e.world() + "' is not loaded."); return; }
                plugin.audit(s.getName(), "structure regenerate " + a[1]);
                Location at = new Location(w, e.x(), e.y(), e.z());
                String err = plugin.placer().rollback(s, a[1], () -> {
                    String err2 = plugin.placer().spawn(s, e.type(), at, e.rotation(), e.id());
                    if (err2 != null) s.sendMessage("Regenerate stopped after rollback: " + err2);
                });
                if (err != null) s.sendMessage(err);
            }
            case "pos1", "pos2" -> {
                if (!(s instanceof Player p)) { s.sendMessage("Players only."); return; }
                plugin.placer().select(p, sub.equals("pos1") ? 0 : 1, p.getLocation());
                s.sendMessage(sub + " set to your position.");
            }
            case "capture" -> {
                if (!(s instanceof Player p) || a.length < 2) { s.sendMessage("Usage (player only): /dessea structure capture <template-name>"); return; }
                String err = plugin.placer().capture(p, a[1]);
                if (err != null) s.sendMessage(err);
            }
            case "reload" -> { sr.reload(); s.sendMessage("Structure registry reloaded."); }
            default -> s.sendMessage("Usage: /dessea structure <list|info|preview|spawn|rotate|regenerate|locate|remove|capture|pos1|pos2|reload>");
        }
    }

    private Location target(CommandSender s, String[] a, int idx) {
        if (a.length >= idx + 3) {
            try {
                var w = s instanceof Player p ? p.getWorld() : plugin.getServer().getWorlds().get(0);
                return new Location(w, Integer.parseInt(a[idx]), Integer.parseInt(a[idx + 1]), Integer.parseInt(a[idx + 2]));
            } catch (NumberFormatException ex) { return null; }
        }
        return s instanceof Player p ? p.getLocation() : null;
    }

    @Override
    public List<String> complete(CommandSender s, String[] a) {
        if (a.length == 1) return DiscoverySub.filter(List.of("list", "info", "preview", "spawn", "rotate", "regenerate", "locate", "remove", "capture", "pos1", "pos2", "reload"), a[0]);
        if (a.length == 2 && List.of("preview", "locate", "spawn", "rotate").contains(a[0])) return DiscoverySub.filter(StructureRegistry.TYPES, a[1]);
        if (a.length == 2 && (a[0].equals("info") || a[0].equals("remove") || a[0].equals("regenerate")) && plugin.structures() != null)
            return DiscoverySub.filter(plugin.structures().all().stream().map(StructureRegistry.Entry::id).toList(), a[1]);
        if (a.length == 3 && (a[0].equals("remove") || a[0].equals("regenerate"))) return DiscoverySub.filter(List.of("confirm"), a[2]);
        if (a.length == 3 && a[0].equals("rotate")) return DiscoverySub.filter(List.of("0", "90", "180", "270"), a[2]);
        return List.of();
    }
}
