package com.des.sea.structure;

import com.des.sea.DesSeaPlugin;
import com.des.sea.core.DesModule;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * Tracks every placed structure with a persistent ID and validates placements.
 * This registry does NOT place blocks. Template placement is a later step and must call validate() first.
 */
public final class StructureRegistry implements DesModule {
    public record Entry(String id, String type, String world, int x, int y, int z, int rotation, long createdAt, String createdBy) {}
    public record Result(boolean ok, List<String> problems) {}

    public static final List<String> TYPES = List.of("sunken_kingdom", "tide_temple", "lost_archive", "drowned_palace",
            "ship_graveyard", "black_trench_observatory", "coral_cathedral", "crystal_hollow", "frozen_expedition",
            "volcanic_research_facility", "abyssal_prison", "ancient_merchant_port", "resonance_observatory", "lost_cargo", "ghost_ship");

    /** Integrations (claim plugins) implement this; any false vetoes the placement. */
    public interface ClaimCheck {
        boolean allows(World w, int minX, int minZ, int maxX, int maxZ);
        String name();
    }

    private final DesSeaPlugin plugin;
    private final File file;
    private final Map<String, Entry> entries = new LinkedHashMap<>();
    private final List<ClaimCheck> claimChecks = new ArrayList<>();

    public StructureRegistry(DesSeaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "structures.yml");
    }

    @Override public String id() { return "structures"; }
    @Override public void enable() { load(); }
    @Override public void disable() { save(); }

    public void addClaimCheck(ClaimCheck c) { claimChecks.add(c); }
    public Collection<Entry> all() { return Collections.unmodifiableCollection(entries.values()); }
    public Entry get(String id) { return entries.get(id); }

    public String nextId(String type) {
        int n = 1;
        String id;
        do { id = String.format("%s-%04d", type, n++); } while (entries.containsKey(id));
        return id;
    }

    public Entry register(String type, Location l, int rotation, String by) {
        return register(nextId(type), type, l, rotation, by);
    }

    public Entry register(String id, String type, Location l, int rotation, String by) {
        Entry e = new Entry(id, type, l.getWorld().getName(), l.getBlockX(), l.getBlockY(), l.getBlockZ(),
                rotation, System.currentTimeMillis(), by);
        entries.put(id, e);
        save();
        return e;
    }

    /** Removes only the registry record, never blocks. */
    public boolean remove(String id) {
        boolean r = entries.remove(id) != null;
        if (r) save();
        return r;
    }

    public Optional<Entry> nearest(String type, Location from) {
        return entries.values().stream()
                .filter(e -> e.type().equals(type) && e.world().equals(from.getWorld().getName()))
                .min(Comparator.comparingDouble(e -> Math.pow(e.x() - from.getX(), 2) + Math.pow(e.z() - from.getZ(), 2)));
    }

    public Result validate(World w, String type, int x, int y, int z) {
        return validate(w, type, x, y, z, Math.min(plugin.getConfig().getInt("structures.footprint-radius", 48), 96));
    }

    public Result validate(World w, String type, int x, int y, int z, int radius) {
        List<String> problems = new ArrayList<>();
        var cfg = plugin.getConfig();
        if (!TYPES.contains(type)) problems.add("Unknown structure type '" + type + "'.");
        List<String> allowed = cfg.getStringList("world.allowed-worlds");
        if (allowed.isEmpty()) problems.add("No worlds are allowed yet (world.allowed-worlds is empty).");
        else if (!allowed.contains(w.getName())) problems.add("World '" + w.getName() + "' is not in world.allowed-worlds.");
        if (y < w.getMinHeight() || y > w.getMaxHeight()) problems.add("Y is outside the world height.");

        int minDist = cfg.getInt("structures.min-distance", 300);
        for (Entry e : entries.values()) {
            if (e.type().equals(type) && e.world().equals(w.getName())
                    && Math.hypot(e.x() - x, e.z() - z) < minDist) {
                problems.add("Too close to existing " + e.id() + " (min distance " + minDist + ").");
            }
        }

        long maxInhabited = cfg.getLong("structures.max-inhabited-ticks", 200);
        int minX = x - radius, maxX = x + radius, minZ = z - radius, maxZ = z + radius;
        int busy = 0;
        for (int cx = minX >> 4; cx <= maxX >> 4; cx++) {
            for (int cz = minZ >> 4; cz <= maxZ >> 4; cz++) {
                // Never generate chunks here. Ungenerated chunks are safe: normal worldgen will handle them.
                if (!w.isChunkGenerated(cx, cz)) continue;
                if (w.getChunkAt(cx, cz).getInhabitedTime() > maxInhabited) busy++;
            }
        }
        if (busy > 0) problems.add(busy + " chunk(s) in the footprint look explored/inhabited by players.");

        for (ClaimCheck c : claimChecks) {
            if (!c.allows(w, minX, minZ, maxX, maxZ)) problems.add("Blocked by claims (" + c.name() + ").");
        }
        if (claimChecks.isEmpty() && cfg.getBoolean("structures.require-claim-check", true)) {
            problems.add("No claim-plugin check is installed, so claims cannot be verified. Placement stays blocked (set structures.require-claim-check: false ONLY on a world with no player claims).");
        }
        return new Result(problems.isEmpty(), problems);
    }

    private void load() {
        entries.clear();
        if (!file.exists()) return;
        ConfigurationSection sec = YamlConfiguration.loadConfiguration(file).getConfigurationSection("structures");
        if (sec == null) return;
        for (String id : sec.getKeys(false)) {
            ConfigurationSection s = sec.getConfigurationSection(id);
            if (s == null) continue;
            entries.put(id, new Entry(id, s.getString("type", "?"), s.getString("world", "?"), s.getInt("x"), s.getInt("y"),
                    s.getInt("z"), s.getInt("rotation"), s.getLong("created-at"), s.getString("created-by", "?")));
        }
    }

    public void save() {
        YamlConfiguration cfg = new YamlConfiguration();
        for (Entry e : entries.values()) {
            String p = "structures." + e.id() + ".";
            cfg.set(p + "type", e.type());
            cfg.set(p + "world", e.world());
            cfg.set(p + "x", e.x());
            cfg.set(p + "y", e.y());
            cfg.set(p + "z", e.z());
            cfg.set(p + "rotation", e.rotation());
            cfg.set(p + "created-at", e.createdAt());
            cfg.set(p + "created-by", e.createdBy());
        }
        try {
            plugin.getDataFolder().mkdirs();
            cfg.save(file);
        } catch (IOException ex) {
            plugin.getLogger().severe("Could not save structures.yml: " + ex.getMessage());
        }
    }

    public void reload() { load(); }
}
