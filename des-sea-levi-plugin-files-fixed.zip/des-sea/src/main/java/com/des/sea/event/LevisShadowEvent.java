package com.des.sea.event;

import com.des.sea.DesSeaPlugin;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * A colossal silhouette passes far below a diver. One display entity per chosen player (max 3),
 * non-persistent so a crash can never leave one behind, and always removed in stop().
 * The visual is the item model des_sea:event/levi_shadow (art not made yet).
 */
public final class LevisShadowEvent implements DesEvent {
    private final DesSeaPlugin plugin;
    private final List<ItemDisplay> shadows = new ArrayList<>();
    private final List<Vector> headings = new ArrayList<>();
    private BukkitTask task;
    private int ticksLeft;
    private Runnable onEnd;

    public LevisShadowEvent(DesSeaPlugin plugin) { this.plugin = plugin; }

    @Override public String id() { return "levis_shadow"; }
    @Override public boolean running() { return task != null; }

    @Override
    public void start(Runnable onEnd) {
        if (task != null) return;
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (Player p : plugin.getServer().getOnlinePlayers()) {
            if (shadows.size() >= 3) break;
            if (!p.isUnderWater() || p.getLocation().getY() > p.getWorld().getSeaLevel() - 12) continue; // only deep divers
            double ang = r.nextDouble(Math.PI * 2);
            Location at = p.getLocation().add(Math.cos(ang) * 70, -30, Math.sin(ang) * 70);
            if (!at.getBlock().isLiquid()) continue; // must be open water, never inside terrain
            Vector heading = new Vector(-Math.sin(ang + Math.PI / 2), 0, Math.cos(ang + Math.PI / 2)); // passes tangentially
            ItemDisplay d = p.getWorld().spawn(at, ItemDisplay.class, x -> {
                ItemStack it = new ItemStack(Material.PAPER);
                ItemMeta m = it.getItemMeta();
                m.setItemModel(NamespacedKey.fromString("des_sea:event/levi_shadow"));
                it.setItemMeta(m);
                x.setItemStack(it);
                x.setPersistent(false);
                x.setBillboard(Display.Billboard.FIXED);
                x.setViewRange(2.0f);
                x.setTeleportDuration(20);
                x.setTransformation(new Transformation(new Vector3f(), new AxisAngle4f(), new Vector3f(30, 30, 30), new AxisAngle4f()));
            });
            shadows.add(d);
            headings.add(heading);
        }
        if (shadows.isEmpty()) return; // nobody suitable: do not start, so no cooldown is spent
        this.onEnd = onEnd;
        ticksLeft = plugin.getConfig().getInt("events.levis_shadow.duration-seconds", 30) * 20;
        task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
    }

    private void tick() {
        ticksLeft -= 20;
        if (ticksLeft <= 0) {
            Runnable cb = onEnd;
            stop();
            if (cb != null) cb.run();
            return;
        }
        for (int i = 0; i < shadows.size(); i++) {
            ItemDisplay d = shadows.get(i);
            if (d.isValid()) d.teleport(d.getLocation().add(headings.get(i).clone().multiply(3)));
        }
    }

    @Override
    public void stop() {
        if (task != null) task.cancel();
        task = null;
        onEnd = null;
        for (ItemDisplay d : shadows) if (d.isValid()) d.remove();
        shadows.clear();
        headings.clear();
    }
}
