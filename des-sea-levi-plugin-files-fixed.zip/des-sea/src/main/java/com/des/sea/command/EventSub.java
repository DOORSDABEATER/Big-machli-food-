package com.des.sea.command;

import com.des.sea.DesSeaPlugin;
import org.bukkit.command.CommandSender;

import java.util.List;
import java.util.Locale;

final class EventSub implements SubCommand {
    private final DesSeaPlugin plugin;

    EventSub(DesSeaPlugin plugin) { this.plugin = plugin; }

    @Override
    public void run(CommandSender s, String[] a) {
        if (!plugin.modules().isRunning("events")) {
            s.sendMessage("The events module is off. Set modules.events: true in config.yml and /dessea reload.");
            return;
        }
        var em = plugin.events();
        String sub = a.length == 0 ? "list" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "list" -> s.sendMessage("Events: " + String.join(", ", em.ids()));
            case "status" -> em.ids().forEach(id -> s.sendMessage(id + ": " + (em.get(id).running() ? "RUNNING" : "idle")));
            case "start" -> {
                if (a.length < 2) { s.sendMessage("Usage: /dessea event start <name>"); return; }
                boolean ok = em.start(a[1]);
                plugin.audit(s.getName(), "event start " + a[1]);
                s.sendMessage(ok ? "Started " + a[1] + "." : "Cannot start '" + a[1] + "' (unknown or already running).");
            }
            case "stop" -> {
                if (a.length < 2) { s.sendMessage("Usage: /dessea event stop <name>"); return; }
                boolean ok = em.stop(a[1]);
                plugin.audit(s.getName(), "event stop " + a[1]);
                s.sendMessage(ok ? "Stopped " + a[1] + "." : "Cannot stop '" + a[1] + "' (unknown or not running).");
            }
            default -> s.sendMessage("Usage: /dessea event <list|start|stop|status>");
        }
    }

    @Override
    public List<String> complete(CommandSender s, String[] a) {
        if (a.length == 1) return DiscoverySub.filter(List.of("list", "start", "stop", "status"), a[0]);
        if (a.length == 2 && plugin.events() != null && (a[0].equals("start") || a[0].equals("stop")))
            return DiscoverySub.filter(List.copyOf(plugin.events().ids()), a[1]);
        return List.of();
    }
}
