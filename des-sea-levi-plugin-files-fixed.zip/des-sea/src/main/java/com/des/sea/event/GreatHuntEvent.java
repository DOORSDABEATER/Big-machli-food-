package com.des.sea.event;

import com.des.sea.DesSeaPlugin;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * A rare predator appears near a diver. It is a real boss run through the boss lifecycle and engine, so it has rewards,
 * retreat handling and a boss bar. Needs modules.bosses + modules.boss_engine and the boss's spawn command configured.
 */
public final class GreatHuntEvent implements DesEvent {
    private final DesSeaPlugin plugin;
    private BukkitTask watch;
    private String boss;
    private long endsAt;
    private Runnable onEnd;
    private boolean active;

    public GreatHuntEvent(DesSeaPlugin plugin) { this.plugin = plugin; }

    @Override public String id() { return "great_hunt"; }
    @Override public boolean running() { return active; }

    @Override
    public void start(Runnable onEnd) {
        if (active || !plugin.modules().isRunning("bosses")) return;
        List<String> pool = new ArrayList<>(plugin.getConfig().getStringList("events.great_hunt.bosses"));
        Collections.shuffle(pool);
        List<String> worlds = plugin.getConfig().getStringList("world.allowed-worlds");
        List<Player> cands = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) if (p.isUnderWater() && worlds.contains(p.getWorld().getName())) cands.add(p);
        if (cands.isEmpty()) return;
        ThreadLocalRandom r = ThreadLocalRandom.current();
        Player p = cands.get(r.nextInt(cands.size()));
        double ang = r.nextDouble(Math.PI * 2), d = 40 + r.nextDouble(30);
        Location at = p.getLocation().add(Math.cos(ang) * d, 0, Math.sin(ang) * d);
        if (!at.getBlock().isLiquid()) return;
        for (String id : pool) {
            if (!plugin.bosses().ids().contains(id) || plugin.bosses().isActive(id)) continue;
            plugin.bosses().setArena(id, at);
            String err = plugin.bosses().start(id);
            if (err != null) { plugin.getLogger().info("great_hunt: " + id + " could not start: " + err); continue; }
            boss = id;
            active = true;
            this.onEnd = onEnd;
            endsAt = System.currentTimeMillis() + (long) (plugin.getConfig().getDouble("events.great_hunt.duration-minutes", 20) * 60_000L);
            String msg = plugin.getConfig().getString("events.great_hunt.announce", "");
            if (!msg.isBlank()) Bukkit.broadcast(Component.text(msg));
            watch = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 100L, 40L);
            return;
        }
    }

    private void tick() {
        if (!plugin.bosses().isActive(boss)) { finish(); return; }          // defeated, or it retreated after a wipe
        if (System.currentTimeMillis() >= endsAt) { plugin.bosses().retreat(boss, "hunt timeout"); finish(); }
    }

    private void finish() {
        Runnable cb = onEnd;
        stop();
        if (cb != null) cb.run();
    }

    @Override
    public void stop() {
        if (watch != null) watch.cancel();
        watch = null;
        if (active && boss != null && plugin.bosses() != null && plugin.modules().isRunning("bosses") && plugin.bosses().isActive(boss)) plugin.bosses().retreat(boss, "event stopped");
        active = false;
        onEnd = null;
        boss = null;
    }
}
