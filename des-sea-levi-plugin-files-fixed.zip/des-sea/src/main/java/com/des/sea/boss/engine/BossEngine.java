package com.des.sea.boss.engine;

import com.des.sea.DesSeaPlugin;
import com.des.sea.core.DesModule;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.io.File;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Supplier;

/**
 * Data-driven boss fight engine (phases, telegraphed attacks, shield/window/shelter mechanics, virtual health pool, boss bar).
 * Boss definitions live in plugins/DeSSea/bosses/*.yml (written by tools/gen_bosses.py). The entity, model and animations come
 * from MythicMobs/ModelEngine; this engine drives movement (teleport), attacks, health and mechanics. It never edits blocks.
 * UNTESTED: every number is a first pass and the Paper calls (teleport flags, Interaction events, attributes) are unverified.
 */
public final class BossEngine implements DesModule, Listener {
    public static final String PART_TAG = "des_part";
    private static final List<String> DEFAULT_IDS = List.of("levi", "krakthor", "thalzar", "nyxara", "orovax", "drowned_admiral",
            "the_lightless", "coral_colossus", "vesper_the_pale", "abyssal_stalker_alpha", "reef_breaker", "siren_matriarch",
            "shipwreck_guardian", "deepwater_devourer", "ancient_shellback");

    private final DesSeaPlugin plugin;
    private final Map<String, YamlConfiguration> defs = new HashMap<>();
    private final Map<UUID, Fight> fights = new HashMap<>();
    private final ThreadLocalRandom rnd = ThreadLocalRandom.current();
    private BukkitTask loop;
    private boolean running;

    public BossEngine(DesSeaPlugin plugin) { this.plugin = plugin; }

    @Override public String id() { return "boss_engine"; }

    // ------------------------------------------------------------------ lifecycle

    @Override
    public void enable() {
        File dir = new File(plugin.getDataFolder(), "bosses");
        dir.mkdirs();
        for (String id : DEFAULT_IDS) {
            if (!new File(dir, id + ".yml").exists()) {
                try { plugin.saveResource("bosses/" + id + ".yml", false); } catch (IllegalArgumentException ex) { plugin.getLogger().warning("Missing bundled boss file " + id); }
            }
        }
        defs.clear();
        File[] files = dir.listFiles((d, n) -> n.endsWith(".yml"));
        if (files != null) for (File f : files) {
            YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
            defs.put(y.getString("id", f.getName().replace(".yml", "")), y);
        }
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
        loop = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tickAll, 2L, 2L);
        running = true;
        plugin.getLogger().info("Boss engine loaded " + defs.size() + " boss definitions.");
    }

    @Override
    public void disable() {
        running = false;
        HandlerList.unregisterAll(this);
        if (loop != null) loop.cancel();
        loop = null;
        for (Fight f : new ArrayList<>(fights.values())) end(f);
        fights.clear();
    }

    public boolean has(String id) { return defs.containsKey(id); }
    public boolean isFighting(Entity e) { return fights.containsKey(e.getUniqueId()); }
    public Set<String> ids() { return defs.keySet(); }

    public List<Location> activeBossLocations() {
        List<Location> out = new ArrayList<>();
        for (Fight f : fights.values()) if (f.boss.isValid()) out.add(f.boss.getLocation());
        return out;
    }

    /** Starts driving 'e' as boss 'id'. Returns false if the engine is off, the boss undefined, or the entity not living. */
    public boolean attach(Entity e, String id, Location arena, double scale, Supplier<Collection<UUID>> participants) {
        if (!running) { plugin.getLogger().warning("boss_engine module is off: " + id + " will not fight. Enable modules.boss_engine."); return false; }
        YamlConfiguration def = defs.get(id);
        if (def == null || !(e instanceof LivingEntity le) || fights.containsKey(e.getUniqueId())) return false;
        Fight f = new Fight(id, def, le, arena.clone(), participants);
        f.maxHp = def.getDouble("base-health", 3000) * Math.max(1.0, scale);
        f.hp = f.maxHp;
        f.scale = Math.max(1.0, scale);
        le.setAI(false);
        le.setGravity(false);
        le.setCollidable(false);
        le.setRemoveWhenFarAway(false);
        le.setPersistent(true);
        f.cooldown = 100;
        f.model = def.getString("model", "");
        if (!f.model.isEmpty() && plugin.getConfig().getBoolean("models.attach-by-plugin", true)) plugin.models().attach(le, f.model, def.getDouble("model-scale", 1.0));
        f.emerge = def.getInt("emerge-ticks", 0);
        if (f.emerge > 0) playAnim(f, "emerge");
        fights.put(le.getUniqueId(), f);
        String intro = def.getString("intro", "");
        snd(f, "intro", arena, 4f, 1f);
        announce(f, intro);
        plugin.getLogger().info("Boss engine attached: " + id + " hp=" + f.maxHp);
        return true;
    }

    // ------------------------------------------------------------------ fight state

    private static final class Fight {
        final String id;
        final YamlConfiguration def;
        final LivingEntity boss;
        final Location arena;
        final Supplier<Collection<UUID>> participants;
        final List<ConfigurationSection> phases = new ArrayList<>();
        final List<Entity> parts = new ArrayList<>();
        final List<Interaction> shelters = new ArrayList<>();
        final Map<UUID, Long> shelterUntil = new HashMap<>();
        final Map<UUID, ItemDisplay> shelterModel = new HashMap<>();
        final Map<UUID, Boolean> shelterOn = new HashMap<>();
        final Set<UUID> barShown = new HashSet<>();
        final Color color;
        final Particle accent;
        final String name;
        BossBar bar;
        double hp, maxHp, scale = 1, damageTaken, dmgMult = 1;
        long tick;
        int phase = -1, cooldown, transition, windowLeft, nodesAlive, emerge;
        long lastHurt;
        boolean moving;
        String model = "";
        double windowMult = 1, orbit;
        boolean shielded, enraged, dying;
        Atk active;
        String lastAtk;
        ConfigurationSection nodeCfg, shelterCfg;

        Fight(String id, YamlConfiguration def, LivingEntity boss, Location arena, Supplier<Collection<UUID>> participants) {
            this.id = id; this.def = def; this.boss = boss; this.arena = arena; this.participants = participants;
            this.name = def.getString("name", id);
            this.color = Color.fromRGB(Integer.parseInt(def.getString("color", "#22d3ee").substring(1), 16));
            Particle p;
            try { p = Particle.valueOf(def.getString("accent", "END_ROD")); } catch (IllegalArgumentException ex) { p = Particle.END_ROD; }
            this.accent = p;
            for (Map<?, ?> m : def.getMapList("phases")) phases.add(sec(m));
        }
    }

    private static ConfigurationSection sec(Map<?, ?> m) {
        Map<String, Object> copy = new LinkedHashMap<>();
        m.forEach((k, v) -> copy.put(String.valueOf(k), v));
        return new YamlConfiguration().createSection("m", copy);
    }

    // ------------------------------------------------------------------ main loop

    private void tickAll() {
        for (Fight f : new ArrayList<>(fights.values())) {
            try { tick(f); } catch (Throwable t) {
                plugin.getLogger().warning("Boss engine error (" + f.id + "), ending fight: " + t);
                end(f);
            }
        }
    }

    private void tick(Fight f) {
        if (!f.boss.isValid() || f.boss.isDead()) { end(f); return; }
        f.tick += 2;
        List<Player> ps = players(f);
        updateBar(f, ps);

        if (f.emerge > 0) { f.emerge -= 2; face(f, ps, f.boss.getLocation()); return; } // rising from the abyss: untouchable, no attacks
        int idx = phaseFor(f);
        if (idx > f.phase) enterPhase(f, idx);
        updateShelters(f);

        if (f.transition > 0) { f.transition -= 2; face(f, ps, f.boss.getLocation()); return; }
        if (f.windowLeft > 0) { f.windowLeft -= 2; if (f.windowLeft <= 0) windowEnd(f); }
        if (!f.enraged && f.tick / 20 >= f.def.getInt("enrage-seconds", 900)) {
            f.enraged = true; f.dmgMult = 1.5;
            snd(f, "enrage", f.boss.getLocation(), 4f, 0.8f);
            announce(f, "Enough.");
            playAnim(f, "enrage");
        }

        boolean lock = f.active != null && f.active.locks();
        if (!lock) move(f, ps);
        else face(f, ps, f.boss.getLocation());

        if (f.active != null) {
            if (f.active.tick()) {
                f.active.end();
                f.active = null;
                ConfigurationSection ph = f.phases.get(f.phase);
                f.cooldown = (int) (ph.getInt("interval", 70) * (f.enraged ? 0.7 : 1.0));
                playAnim(f, f.moving ? "swim" : "idle");
            }
        } else if (!ps.isEmpty()) {
            f.cooldown -= 2;
            if (f.cooldown <= 0) startAttack(f);
        }
    }

    private int phaseFor(Fight f) {
        double frac = f.hp / f.maxHp;
        for (int i = 0; i < f.phases.size(); i++) if (frac > f.phases.get(i).getDouble("until", 0)) return i;
        return f.phases.size() - 1;
    }

    private void enterPhase(Fight f, int i) {
        if (f.active != null) { f.active.end(); f.active = null; }
        clearParts(f);
        f.shielded = false; f.windowMult = 1; f.windowLeft = 0; f.nodeCfg = null; f.shelterCfg = null;
        f.phase = i;
        ConfigurationSection ph = f.phases.get(i);
        f.transition = ph.getInt("transition", i == 0 ? 40 : 60);
        f.cooldown = 40;
        playAnim(f, i == 0 ? "intro" : "phase_change_" + i);
        snd(f, "phase" + (i + 1), f.boss.getLocation(), 4f, 1f);
        announce(f, ph.getString("announce", ""));
        for (Map<?, ?> m : ph.getMapList("mechanics")) {
            ConfigurationSection mc = sec(m);
            if ("nodes".equals(mc.getString("type"))) { f.nodeCfg = mc; spawnNodes(f, mc); if (mc.getBoolean("shield", true)) f.shielded = true; }
            else if ("shelters".equals(mc.getString("type"))) { f.shelterCfg = mc; spawnShelters(f, mc); }
        }
    }

    // ------------------------------------------------------------------ movement

    private void move(Fight f, List<Player> ps) {
        double speed = f.def.getDouble("speed", 0.5);
        ConfigurationSection ph = f.phases.get(f.phase);
        String mode = ph.getString("movement", "static");
        Location cur = f.boss.getLocation();
        Location goal = null;
        switch (mode) {
            case "orbit" -> {
                double r = ph.getDouble("orbit-radius", 35);
                f.orbit += speed * 2 / Math.max(10, r);
                goal = f.arena.clone().add(Math.cos(f.orbit) * r, 6, Math.sin(f.orbit) * r);
            }
            case "chase" -> {
                Player n = nearest(ps, cur);
                if (n != null && n.getLocation().distance(cur) > 5) goal = n.getLocation().clone();
            }
            case "hover" -> goal = f.arena.clone().add(Math.cos(f.tick / 70.0) * 8, 6, Math.sin(f.tick / 70.0) * 8);
            default -> { }
        }
        if (goal == null || speed <= 0) { face(f, ps, cur); setMoving(f, false); return; }
        Vector d = goal.toVector().subtract(cur.toVector());
        double len = d.length();
        Location to = len < 0.01 ? cur : cur.clone().add(d.normalize().multiply(Math.min(len, speed * 2)));
        setMoving(f, len > 0.5);
        face(f, ps, to);
    }

    private void setMoving(Fight f, boolean moving) {
        if (f.moving == moving) return;
        f.moving = moving;
        if (f.active == null) playAnim(f, moving ? "swim" : "idle");
    }

    private void playAnim(Fight f, String anim) {
        if (f.model.isEmpty() || anim == null || anim.isBlank()) return;
        plugin.models().play(f.boss, f.model, anim);
    }

    private void face(Fight f, List<Player> ps, Location to) {
        Player n = nearest(ps, to);
        if (n != null) to.setDirection(n.getLocation().toVector().subtract(to.toVector()));
        teleportBoss(f, to);
    }

    private void teleportBoss(Fight f, Location to) {
        f.boss.teleport(to, PlayerTeleportEvent.TeleportCause.PLUGIN, io.papermc.paper.entity.TeleportFlag.EntityState.RETAIN_PASSENGERS);
    }

    private Player nearest(List<Player> ps, Location from) {
        Player best = null;
        double bd = Double.MAX_VALUE;
        for (Player p : ps) { double d = p.getLocation().distanceSquared(from); if (d < bd) { bd = d; best = p; } }
        return best;
    }

    /** Anyone alive in survival/adventure inside the arena can be hit (bystanders included). */
    private List<Player> players(Fight f) {
        List<Player> out = new ArrayList<>();
        double r = f.def.getDouble("arena-radius", 80);
        for (Player p : f.arena.getWorld().getPlayers()) {
            if (p.isDead() || (p.getGameMode() != GameMode.SURVIVAL && p.getGameMode() != GameMode.ADVENTURE)) continue;
            if (p.getLocation().distanceSquared(f.arena) <= r * r) out.add(p);
        }
        return out;
    }

    // ------------------------------------------------------------------ attacks

    private void startAttack(Fight f) {
        ConfigurationSection ph = f.phases.get(f.phase);
        List<Map<?, ?>> list = ph.getMapList("attacks");
        if (list.isEmpty()) return;
        List<String> names = new ArrayList<>();
        List<Integer> weights = new ArrayList<>();
        for (Map<?, ?> m : list) {
            String n = String.valueOf(m.get("use"));
            if (list.size() > 1 && n.equals(f.lastAtk)) continue; // never the same attack twice in a row
            names.add(n);
            weights.add(m.get("weight") instanceof Number w ? w.intValue() : 1);
        }
        int total = weights.stream().mapToInt(Integer::intValue).sum();
        int x = rnd.nextInt(Math.max(1, total));
        String pick = names.get(0);
        for (int i = 0; i < names.size(); i++) { x -= weights.get(i); if (x < 0) { pick = names.get(i); break; } }
        ConfigurationSection a = f.def.getConfigurationSection("attacks." + pick);
        if (a == null) { plugin.getLogger().warning("Boss " + f.id + " references undefined attack " + pick); f.cooldown = 100; return; }
        Atk atk = make(f, pick, a);
        if (atk == null) { plugin.getLogger().warning("Unknown attack type '" + a.getString("type") + "' in " + f.id); f.cooldown = 100; return; }
        f.active = atk;
        f.lastAtk = pick;
        playAnim(f, a.getString("anim", pick));
    }

    private Atk make(Fight f, String name, ConfigurationSection a) {
        return switch (a.getString("type", "")) {
            case "slam" -> new Slam(f, name, a);
            case "shockwave" -> new Shock(f, name, a);
            case "charge" -> new Charge(f, name, a);
            case "cone" -> new Cone(f, name, a);
            case "pull" -> new Pull(f, name, a);
            case "current" -> new Current(f, name, a);
            case "beam" -> new Beam(f, name, a);
            case "rupture" -> new Rupture(f, name, a);
            case "grab" -> new Grab(f, name, a);
            case "darkness" -> new Darkness(f, name, a);
            case "summon" -> new Summon(f, name, a);
            case "roar" -> new Roar(f, name, a);
            default -> null;
        };
    }

    private abstract class Atk {
        final Fight f; final String name; final ConfigurationSection a; int t = 0;
        Atk(Fight f, String name, ConfigurationSection a) { this.f = f; this.name = name; this.a = a; }
        abstract boolean tick();
        void end() { }
        boolean locks() { return true; }
        int tele() { return a.getInt("telegraph", 30); }
        Player randomTarget() { List<Player> ps = players(f); return ps.isEmpty() ? null : ps.get(rnd.nextInt(ps.size())); }
    }

    private class Slam extends Atk {
        Location c; final double r = a.getDouble("radius", 8);
        Slam(Fight f, String n, ConfigurationSection a) { super(f, n, a); }
        boolean tick() {
            if (t == 0) {
                Player tg = randomTarget();
                c = (a.getString("center", "target").equals("self") || tg == null) ? f.boss.getLocation().clone() : tg.getLocation().clone();
                snd(f, name + ".windup", c, 3f, 1f);
            }
            if (t % 4 == 0) { ring(f, c, r, 28); ring(f, c, r * Math.min(1.0, (t + 4.0) / tele()), 18); }
            t += 2;
            if (t < tele()) return false;
            for (Player p : players(f)) if (p.getLocation().distance(c) <= r) strike(f, p, a, away(c, p.getLocation(), a.getDouble("knockback", 1.0)), -1);
            snd(f, name + ".strike", c, 4f, 1f);
            burst(f, c, r);
            return true;
        }
    }

    private class Shock extends Atk {
        Location c; double r; int ring, state, wait; final Set<UUID> hit = new HashSet<>();
        final int rings = a.getInt("rings", 1);
        Shock(Fight f, String n, ConfigurationSection a) { super(f, n, a); }
        boolean tick() {
            if (t == 0) { c = f.boss.getLocation().clone(); snd(f, name + ".windup", c, 3f, 1f); }
            double maxR = a.getDouble("max-radius", 40), th = a.getDouble("thickness", 3), h = a.getDouble("height", 3);
            if (state == 0) { // telegraph: pulsing small ring
                if (t % 6 == 0) ring(f, c, 4 + t * 0.12, 16);
                t += 2;
                if (t >= tele()) { state = 1; r = 0; hit.clear(); snd(f, name + ".strike", c, 4f, 1f); }
                return false;
            }
            if (state == 2) { // gap between rings, warning ring at the boss
                ring(f, c, 5, 12);
                wait -= 2;
                if (wait <= 0) { state = 1; r = 0; hit.clear(); snd(f, name + ".strike", c, 4f, 1f); }
                return false;
            }
            r += a.getDouble("speed", 0.8) * 2;
            ring(f, c, r, Math.min(44, (int) (r * 2.2) + 10));
            for (Player p : players(f)) {
                Location pl = p.getLocation();
                double dxz = Math.hypot(pl.getX() - c.getX(), pl.getZ() - c.getZ());
                if (Math.abs(dxz - r) <= th / 2 + 0.8 && Math.abs(pl.getY() - c.getY()) <= h && hit.add(p.getUniqueId()))
                    strike(f, p, a, away(c, pl, 1.0), -1);
            }
            if (r >= maxR) {
                if (++ring >= rings) return true;
                state = 2;
                wait = a.getInt("ring-gap", 20);
            }
            return false;
        }
    }

    private class Charge extends Atk {
        Vector dir; double traveled; final Set<UUID> hit = new HashSet<>();
        Charge(Fight f, String n, ConfigurationSection a) { super(f, n, a); }
        boolean tick() {
            Location bl = f.boss.getLocation();
            double dist = a.getDouble("distance", 30);
            if (t == 0) {
                Player tg = randomTarget();
                dir = (tg == null ? bl.getDirection() : tg.getLocation().toVector().subtract(bl.toVector())).clone().normalize();
                snd(f, name + ".windup", bl, 3f, 1f);
            }
            if (t < tele()) {
                if (t % 4 == 0) for (double d = 2; d < Math.min(dist, 48); d += 3) dustAt(f, bl.clone().add(dir.clone().multiply(d)), 3, a.getDouble("width", 3) / 3);
                t += 2;
                if (t >= tele()) snd(f, name + ".strike", bl, 4f, 1f);
                return false;
            }
            double step = a.getDouble("speed", 1.2) * 2;
            Location n = bl.clone().add(dir.clone().multiply(step));
            n.setDirection(dir);
            teleportBoss(f, n);
            traveled += step;
            accentAt(f, n, 8, 1.5);
            for (Player p : players(f))
                if (p.getLocation().distance(n) <= a.getDouble("width", 3) && hit.add(p.getUniqueId())) strike(f, p, a, dir.clone().multiply(1.4).setY(0.3), -1);
            return traveled >= dist;
        }
    }

    private class Cone extends Atk {
        Vector dir;
        Cone(Fight f, String n, ConfigurationSection a) { super(f, n, a); }
        boolean tick() {
            Location bl = f.boss.getLocation();
            double range = a.getDouble("range", 15), ang = Math.toRadians(a.getDouble("angle", 100));
            if (t == 0) {
                Player tg = randomTarget();
                dir = (tg == null ? bl.getDirection() : tg.getLocation().toVector().subtract(bl.toVector())).clone().normalize();
                snd(f, name + ".windup", bl, 3f, 1f);
            }
            if (t % 4 == 0) for (double side : new double[]{-ang / 2, 0, ang / 2}) {
                Vector v = rotY(dir, side);
                for (double d = 2; d < range; d += 2.5) dustAt(f, bl.clone().add(v.clone().multiply(d)), 2, 0.2);
            }
            t += 2;
            if (t < tele()) return false;
            for (Player p : players(f)) {
                Vector to = p.getLocation().toVector().subtract(bl.toVector());
                if (to.length() <= range && to.length() > 0.1 && dir.angle(to) <= ang / 2) strike(f, p, a, to.clone().normalize().multiply(1.1).setY(0.2), -1);
            }
            snd(f, name + ".strike", bl, 4f, 1f);
            accentAt(f, bl.clone().add(dir.clone().multiply(range / 2)), 30, range / 3);
            return true;
        }
    }

    private class Pull extends Atk {
        Pull(Fight f, String n, ConfigurationSection a) { super(f, n, a); }
        boolean locks() { return false; }
        boolean tick() {
            Location c = f.boss.getLocation();
            double r = a.getDouble("radius", 30), inner = a.getDouble("inner", 5), str = a.getDouble("strength", 0.08);
            if (t == 0) snd(f, name + ".windup", c, 3f, 1f);
            t += 2;
            ring(f, c, r * (1.0 - (t % 40) / 40.0), 16);
            for (Player p : players(f)) {
                double d = p.getLocation().distance(c);
                if (d > r || d < 0.5) continue;
                Vector pull = c.toVector().subtract(p.getLocation().toVector()).normalize().multiply(str);
                p.setVelocity(p.getVelocity().add(pull));
                if (d < inner && t % 10 == 0) strike(f, p, a, new Vector(), a.getDouble("damage", 6) * 0.5);
            }
            if (t < a.getInt("duration", 60)) return false;
            if (a.getBoolean("finisher")) {
                snd(f, name + ".strike", c, 4f, 1f);
                burst(f, c, inner);
                for (Player p : players(f)) if (p.getLocation().distance(c) <= inner) strike(f, p, a, new Vector(), a.getBoolean("lethal") ? -1 : a.getDouble("damage", 6) * 3);
            }
            return true;
        }
    }

    private class Current extends Atk {
        Vector dir;
        Current(Fight f, String n, ConfigurationSection a) { super(f, n, a); }
        boolean locks() { return false; }
        boolean tick() {
            if (t == 0) {
                double ang = rnd.nextDouble(Math.PI * 2);
                dir = new Vector(Math.cos(ang), 0, Math.sin(ang));
                snd(f, name + ".windup", f.boss.getLocation(), 3f, 1f);
            }
            t += 2;
            double r = a.getDouble("radius", 40), str = a.getDouble("strength", 0.1), dmg = a.getDouble("damage", 0);
            for (Player p : players(f)) {
                if (p.getLocation().distance(f.boss.getLocation()) > r) continue;
                p.setVelocity(p.getVelocity().add(dir.clone().multiply(str)));
                if (t % 8 == 0) dustAt(f, p.getLocation().add(0, 1, 0), 2, 0.5);
                if (dmg > 0 && t % 20 == 0) strike(f, p, a, new Vector(), dmg);
            }
            return t >= a.getInt("duration", 80);
        }
    }

    private class Beam extends Atk {
        double start; final Map<UUID, Integer> last = new HashMap<>();
        Beam(Fight f, String n, ConfigurationSection a) { super(f, n, a); }
        boolean locks() { return false; }
        boolean tick() {
            Location o = f.boss.getLocation().add(0, 1, 0);
            double sweep = a.getDouble("sweep", 90), range = a.getDouble("range", 50), w = a.getDouble("width", 3);
            int dur = a.getInt("duration", 60);
            if (t == 0) {
                Player tg = randomTarget();
                Vector to = tg == null ? o.getDirection() : tg.getLocation().toVector().subtract(o.toVector());
                start = Math.atan2(-to.getX(), to.getZ()) - Math.toRadians(sweep) / 2; // yaw-style angle
                snd(f, name + ".windup", o, 3f, 1f);
            }
            double prog = Math.max(0, (t - tele())) / (double) dur;
            double ang = start + Math.toRadians(sweep) * Math.min(1.0, prog);
            Vector dir = new Vector(-Math.sin(ang), 0, Math.cos(ang));
            for (double d = 3; d < range; d += 4) { Location pt = o.clone().add(dir.clone().multiply(d)); if (t < tele()) dustAt(f, pt, 1, 0.1); else { dustAt(f, pt, 3, w / 3); accentAt(f, pt, 1, 0.3); } }
            if (t >= tele()) {
                for (Player p : players(f)) {
                    Vector v = p.getLocation().toVector().subtract(o.toVector());
                    double proj = v.dot(dir);
                    if (proj < 0 || proj > range) continue;
                    if (v.clone().subtract(dir.clone().multiply(proj)).length() <= w && (int) f.tick - last.getOrDefault(p.getUniqueId(), -999) >= a.getInt("interval", 6) * 2) {
                        last.put(p.getUniqueId(), (int) f.tick);
                        strike(f, p, a, new Vector(), -1);
                    }
                }
                if (t == tele()) snd(f, name + ".strike", o, 4f, 1f);
            }
            t += 2;
            return t >= tele() + dur;
        }
    }

    private class Rupture extends Atk {
        final List<Vector> dirs = new ArrayList<>(); Location c;
        Rupture(Fight f, String n, ConfigurationSection a) { super(f, n, a); }
        boolean tick() {
            double len = a.getDouble("length", 40), w = a.getDouble("width", 3);
            if (t == 0) {
                c = f.boss.getLocation().clone();
                int n = a.getInt("lines", 6);
                double base = rnd.nextDouble(Math.PI * 2);
                for (int i = 0; i < n; i++) { double ang = base + i * Math.PI * 2 / n + rnd.nextDouble(-0.15, 0.15); dirs.add(new Vector(Math.cos(ang), 0, Math.sin(ang))); }
                snd(f, name + ".windup", c, 3f, 1f);
            }
            if (t % 4 == 0) for (Vector d : dirs) for (double x = 3; x < len; x += 3) dustAt(f, c.clone().add(d.clone().multiply(x)), 1, 0.15);
            t += 2;
            if (t < tele()) return false;
            for (Player p : players(f)) {
                Vector v = p.getLocation().toVector().subtract(c.toVector()).setY(0);
                for (Vector d : dirs) {
                    double proj = v.dot(d);
                    if (proj > 0 && proj < len && v.clone().subtract(d.clone().multiply(proj)).length() <= w && Math.abs(p.getLocation().getY() - c.getY()) <= 8) {
                        strike(f, p, a, new Vector(0, 0.8, 0), -1);
                        break;
                    }
                }
            }
            for (Vector d : dirs) for (double x = 3; x < len; x += 4) accentAt(f, c.clone().add(d.clone().multiply(x)), 4, w / 2);
            snd(f, name + ".strike", c, 4f, 1f);
            return true;
        }
    }

    private class Grab extends Atk {
        final List<Player> victims = new ArrayList<>(); double startDmg; int held;
        Grab(Fight f, String n, ConfigurationSection a) { super(f, n, a); }
        boolean locks() { return false; }
        boolean tick() {
            if (t == 0) {
                List<Player> ps = new ArrayList<>(players(f));
                Collections.shuffle(ps);
                for (int i = 0; i < Math.min(a.getInt("count", 1), ps.size()); i++) victims.add(ps.get(i));
                snd(f, name + ".windup", f.boss.getLocation(), 3f, 1f);
            }
            t += 2;
            if (t < tele()) { for (Player p : victims) accentAt(f, p.getLocation().add(0, 1, 0), 3, 0.6); return false; }
            if (t == tele()) { startDmg = f.damageTaken; snd(f, name + ".strike", f.boss.getLocation(), 4f, 1f); }
            held += 2;
            boolean freed = f.damageTaken - startDmg >= a.getDouble("break", 100);
            for (Player p : victims) {
                if (!p.isOnline() || p.isDead()) continue;
                if (freed) { p.sendActionBar(Component.text("You tear free!")); continue; }
                p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 6, 3, true, false));
                Vector to = a.getBoolean("pull", true) ? f.boss.getLocation().toVector().subtract(p.getLocation().toVector()) : new Vector();
                p.setVelocity(to.lengthSquared() > 1 ? to.normalize().multiply(0.35) : new Vector());
                if (held % 20 == 0) strike(f, p, a, new Vector(), a.getDouble("dps", 3));
                if (held % 6 == 0) dustAt(f, p.getLocation().add(0, 1, 0), 3, 0.4);
            }
            if (freed) return true;
            if (held < a.getInt("hold", 100)) return false;
            for (Player p : victims) if (p.isOnline() && !p.isDead()) strike(f, p, a, new Vector(), a.getDouble("crush", 15));
            return true;
        }
    }

    private class Darkness extends Atk {
        Darkness(Fight f, String n, ConfigurationSection a) { super(f, n, a); }
        boolean locks() { return false; }
        boolean tick() {
            if (t == 0) snd(f, name + ".windup", f.boss.getLocation(), 3f, 1f);
            t += 2;
            if (t < tele()) { dustAt(f, f.boss.getLocation(), 6, 3); return false; }
            int dur = a.getInt("duration", 160);
            for (Player p : players(f)) if (p.getLocation().distance(f.boss.getLocation()) <= a.getDouble("radius", 30))
                p.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, dur, 0, true, false));
            snd(f, name + ".strike", f.boss.getLocation(), 4f, 1f);
            return true;
        }
    }

    private class Summon extends Atk {
        Summon(Fight f, String n, ConfigurationSection a) { super(f, n, a); }
        boolean locks() { return false; }
        boolean tick() {
            if (t == 0) snd(f, name + ".windup", f.boss.getLocation(), 3f, 1f);
            t += 2;
            if (t < tele()) { accentAt(f, f.boss.getLocation(), 6, 2); return false; }
            String tpl = plugin.getConfig().getString("engine.add-command", "");
            if (tpl.isBlank()) { plugin.getLogger().warning("engine.add-command is empty; " + f.id + " cannot summon adds."); return true; }
            double r = a.getDouble("radius", 15);
            for (int i = 0; i < a.getInt("count", 3); i++) {
                Location l = f.boss.getLocation().add(rnd.nextDouble(-r, r), rnd.nextDouble(-3, 3), rnd.nextDouble(-r, r));
                if (!l.getBlock().isLiquid()) l = f.boss.getLocation();
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), tpl.replace("%mob%", a.getString("mob", "")).replace("%world%", l.getWorld().getName())
                        .replace("%x%", String.valueOf(l.getBlockX())).replace("%y%", String.valueOf(l.getBlockY())).replace("%z%", String.valueOf(l.getBlockZ())));
            }
            snd(f, name + ".strike", f.boss.getLocation(), 4f, 1f);
            return true;
        }
    }

    private class Roar extends Atk {
        Roar(Fight f, String n, ConfigurationSection a) { super(f, n, a); }
        boolean tick() {
            Location c = f.boss.getLocation();
            if (t == 0) snd(f, name + ".windup", c, 3f, 1f);
            if (t % 4 == 0) ring(f, c, a.getDouble("radius", 20) * Math.min(1.0, (t + 4.0) / tele()), 20);
            t += 2;
            if (t < tele()) return false;
            double r = a.getDouble("radius", 20);
            for (Player p : players(f)) if (p.getLocation().distance(c) <= r) {
                strike(f, p, a, away(c, p.getLocation(), a.getDouble("knockback", 1.2)), -1);
            }
            snd(f, name + ".strike", c, 4f, 1f);
            burst(f, c, r);
            return true;
        }
    }

    // ------------------------------------------------------------------ damage to players

    private Vector away(Location from, Location to, double strength) {
        Vector v = to.toVector().subtract(from.toVector());
        if (v.lengthSquared() < 0.01) v = new Vector(0, 1, 0);
        return v.normalize().multiply(strength).setY(0.3);
    }

    private Vector rotY(Vector v, double ang) {
        double c = Math.cos(ang), s = Math.sin(ang);
        return new Vector(v.getX() * c - v.getZ() * s, v.getY(), v.getX() * s + v.getZ() * c);
    }

    private boolean sheltered(Fight f, Player p) {
        if (f.shelterCfg == null) return false;
        double pr = f.shelterCfg.getDouble("protect-radius", 4.5);
        for (Interaction s : f.shelters) {
            if (!s.isValid() || f.shelterUntil.getOrDefault(s.getUniqueId(), 0L) <= f.tick) continue;
            if (s.getLocation().distance(p.getLocation()) <= pr) return true;
        }
        return false;
    }

    /** dmgOverride < 0 means: use the attack's own damage (and its lethal/sheltered rules). */
    private void strike(Fight f, Player p, ConfigurationSection a, Vector kb, double dmgOverride) {
        double dmg;
        if (dmgOverride >= 0) dmg = dmgOverride;
        else if (a.getBoolean("lethal")) dmg = sheltered(f, p) ? a.getDouble("sheltered-damage", 4) : 1000;
        else dmg = a.getDouble("damage", 8);
        if (dmg < 1000) dmg *= f.dmgMult;
        if (dmg > 0) p.damage(dmg, f.boss);
        if (kb != null && kb.lengthSquared() > 0) p.setVelocity(p.getVelocity().add(kb));
        int slow = a.getInt("slow", 0);
        if (slow > 0) p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, slow, 2, true, false));
    }

    // ------------------------------------------------------------------ boss health, shield, window

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBossDamage(EntityDamageEvent e) {
        Fight f = fights.get(e.getEntity().getUniqueId());
        if (f == null) return;
        Entity src = null;
        if (e instanceof EntityDamageByEntityEvent be) {
            src = be.getDamager();
            if (src instanceof Projectile pr && pr.getShooter() instanceof Entity s) src = s;
        }
        if (!(src instanceof Player p)) { e.setCancelled(true); return; } // environment, adds and other mobs cannot hurt the boss
        if (f.shielded || f.transition > 0 || f.emerge > 0 || f.dying) {
            e.setCancelled(true);
            if (f.shielded) p.sendActionBar(Component.text("Something shields it. Find the source."));
            return;
        }
        double dmg = e.getFinalDamage() * f.windowMult;
        e.setDamage(0); // the real health pool is virtual
        f.damageTaken += dmg;
        f.hp = Math.max(0, f.hp - dmg);
        if (f.tick - f.lastHurt > 30 && f.active == null) { f.lastHurt = f.tick; playAnim(f, "hurt"); }
        if (f.hp <= 0) {
            f.dying = true;
            plugin.getServer().getScheduler().runTask(plugin, () -> { if (f.boss.isValid()) f.boss.setHealth(0); });
        } else {
            var attr = f.boss.getAttribute(Attribute.MAX_HEALTH);
            if (attr != null) f.boss.setHealth(Math.max(0.5, attr.getValue() * f.hp / f.maxHp));
        }
    }

    @EventHandler
    public void onDeath(EntityDeathEvent e) {
        Entity en = e.getEntity();
        Fight f = fights.get(en.getUniqueId());
        if (f != null) {
            playAnim(f, "death");
            snd(f, "defeat", en.getLocation(), 5f, 1f);
            announce(f, f.def.getString("defeat", ""));
            burst(f, en.getLocation(), 12);
            end(f);
            return;
        }
        for (String t : en.getScoreboardTags()) {
            if (!t.startsWith(PART_TAG + "_") || t.startsWith(PART_TAG + "_shelter")) continue;
            try {
                Fight pf = fights.get(UUID.fromString(t.substring(PART_TAG.length() + 1)));
                if (pf != null) { e.getDrops().clear(); e.setDroppedExp(0); partDied(pf, en); }
            } catch (IllegalArgumentException ignored) { }
        }
    }

    private void partDied(Fight f, Entity part) {
        for (Entity p : new ArrayList<>(part.getPassengers())) p.remove();
        if (--f.nodesAlive > 0) return;
        ConfigurationSection m = f.nodeCfg;
        if (m == null) return;
        f.shielded = false;
        String msg = m.getString("clear-message", "");
        if (!msg.isBlank()) for (Player p : players(f)) p.sendMessage(Component.text(msg));
        snd(f, "window", f.boss.getLocation(), 3f, 1f);
        int window = m.getInt("window", 0);
        if (window > 0) { f.windowLeft = window; f.windowMult = m.getDouble("window-mult", 1.0); playAnim(f, f.def.getString("window-anim", "")); }
    }

    private void windowEnd(Fight f) {
        f.windowMult = 1;
        playAnim(f, f.def.getString("window-end-anim", ""));
        if (f.nodeCfg != null && f.nodeCfg.getBoolean("respawn")) {
            spawnNodes(f, f.nodeCfg);
            f.shielded = f.nodeCfg.getBoolean("shield", true);
        }
    }

    // ------------------------------------------------------------------ parts: nodes and shelters

    private ItemDisplay modelDisplay(Fight f, Location l, String model) {
        return l.getWorld().spawn(l, ItemDisplay.class, d -> {
            ItemStack it = new ItemStack(Material.PAPER);
            ItemMeta m = it.getItemMeta();
            m.setItemModel(NamespacedKey.fromString("des_sea:boss/" + f.id + "_" + model));
            it.setItemMeta(m);
            d.setItemStack(it);
            d.setPersistent(false);
        });
    }

    private void spawnNodes(Fight f, ConfigurationSection m) {
        int count = m.getInt("count", 3);
        double r = m.getDouble("radius", 20), hp = m.getDouble("health", 100) * f.scale;
        Location center = "boss".equals(m.getString("around")) ? f.boss.getLocation() : f.arena;
        double off = rnd.nextDouble(Math.PI * 2);
        f.nodesAlive = 0;
        for (int i = 0; i < count; i++) {
            double ang = off + i * Math.PI * 2 / count;
            Location l = center.clone().add(Math.cos(ang) * r, m.getDouble("y-offset", 0), Math.sin(ang) * r);
            Shulker s = l.getWorld().spawn(l, Shulker.class, e -> {
                e.setAI(false); e.setInvisible(true); e.setSilent(true); e.setGlowing(true); e.setPersistent(false); e.setGravity(false);
                var attr = e.getAttribute(Attribute.MAX_HEALTH);
                if (attr != null) attr.setBaseValue(hp);
                e.setHealth(hp);
                e.addScoreboardTag(PART_TAG);
                e.addScoreboardTag(PART_TAG + "_" + f.boss.getUniqueId());
            });
            s.addPassenger(modelDisplay(f, l, "node"));
            f.parts.add(s);
            f.nodesAlive++;
        }
    }

    private void spawnShelters(Fight f, ConfigurationSection m) {
        int count = m.getInt("count", 4);
        double r = m.getDouble("radius", 20);
        double off = rnd.nextDouble(Math.PI * 2);
        for (int i = 0; i < count; i++) {
            double ang = off + i * Math.PI * 2 / count;
            Location l = f.arena.clone().add(Math.cos(ang) * r, m.getDouble("y-offset", 0), Math.sin(ang) * r);
            Interaction in = l.getWorld().spawn(l, Interaction.class, e -> {
                e.setInteractionWidth(2.4f); e.setInteractionHeight(3f); e.setResponsive(true); e.setPersistent(false);
                e.addScoreboardTag(PART_TAG + "_shelter");
                e.addScoreboardTag(PART_TAG + "_shelter_" + f.boss.getUniqueId());
            });
            ItemDisplay d = modelDisplay(f, l, "shelter");
            f.parts.add(in);
            f.parts.add(d);
            f.shelters.add(in);
            f.shelterModel.put(in.getUniqueId(), d);
            f.shelterOn.put(in.getUniqueId(), false);
        }
    }

    private void updateShelters(Fight f) {
        for (Interaction s : f.shelters) {
            if (!s.isValid()) continue;
            boolean on = f.shelterUntil.getOrDefault(s.getUniqueId(), 0L) > f.tick;
            if (f.shelterOn.getOrDefault(s.getUniqueId(), false) != on) {
                f.shelterOn.put(s.getUniqueId(), on);
                ItemDisplay d = f.shelterModel.get(s.getUniqueId());
                if (d != null && d.isValid()) {
                    ItemStack it = d.getItemStack();
                    ItemMeta m = it.getItemMeta();
                    m.setItemModel(NamespacedKey.fromString("des_sea:boss/" + f.id + (on ? "_shelter_active" : "_shelter")));
                    it.setItemMeta(m);
                    d.setItemStack(it);
                }
            }
            if (on && f.tick % 8 == 0) accentAt(f, s.getLocation().add(0, 1, 0), 3, 1.2);
        }
    }

    @EventHandler
    public void onShelterUse(PlayerInteractEntityEvent e) {
        if (!(e.getRightClicked() instanceof Interaction in)) return;
        for (String t : in.getScoreboardTags()) {
            if (!t.startsWith(PART_TAG + "_shelter_")) continue;
            try {
                Fight f = fights.get(UUID.fromString(t.substring((PART_TAG + "_shelter_").length())));
                if (f == null || f.shelterCfg == null) return;
                e.setCancelled(true);
                f.shelterUntil.put(in.getUniqueId(), f.tick + f.shelterCfg.getInt("duration", 150));
                snd(f, "shelter", in.getLocation(), 2f, 1.2f);
            } catch (IllegalArgumentException ignored) { }
        }
    }

    private void clearParts(Fight f) {
        for (Entity p : f.parts) { for (Entity pass : new ArrayList<>(p.getPassengers())) pass.remove(); p.remove(); }
        f.parts.clear(); f.shelters.clear(); f.shelterUntil.clear(); f.shelterModel.clear(); f.shelterOn.clear();
        f.nodesAlive = 0;
    }

    // ------------------------------------------------------------------ ending

    private void end(Fight f) {
        fights.remove(f.boss.getUniqueId());
        if (f.active != null) { f.active.end(); f.active = null; }
        clearParts(f);
        if (f.bar != null) for (UUID u : f.barShown) { Player p = Bukkit.getPlayer(u); if (p != null) p.hideBossBar(f.bar); }
        f.barShown.clear();
        // adds spawned by this boss (MythicMobs mobs must carry the tag des_add_<boss id>)
        for (Entity e : f.arena.getWorld().getNearbyEntities(f.arena, 200, 200, 200)) if (e.getScoreboardTags().contains("des_add_" + f.id)) e.remove();
    }

    // ------------------------------------------------------------------ boss bar, voice, vfx, sound

    private void updateBar(Fight f, List<Player> ps) {
        if (f.bar == null) {
            BossBar.Color c;
            try { c = BossBar.Color.valueOf(f.def.getString("bar-color", "BLUE")); } catch (IllegalArgumentException ex) { c = BossBar.Color.BLUE; }
            f.bar = BossBar.bossBar(Component.text(f.name), 1f, c, BossBar.Overlay.NOTCHED_10);
        }
        String phaseName = f.phase >= 0 ? f.phases.get(f.phase).getString("name", "") : "";
        f.bar.name(Component.text(f.name + (phaseName.isBlank() ? "" : " - " + phaseName) + (f.shielded ? "  [SHIELDED]" : f.windowLeft > 0 ? "  [EXPOSED]" : "")));
        f.bar.progress((float) Math.max(0, Math.min(1, f.hp / f.maxHp)));
        Set<UUID> now = new HashSet<>();
        for (Player p : ps) { now.add(p.getUniqueId()); if (f.barShown.add(p.getUniqueId())) p.showBossBar(f.bar); }
        for (Iterator<UUID> it = f.barShown.iterator(); it.hasNext(); ) {
            UUID u = it.next();
            if (!now.contains(u)) { Player p = Bukkit.getPlayer(u); if (p != null) p.hideBossBar(f.bar); it.remove(); }
        }
    }

    private void announce(Fight f, String line) {
        if (line == null || line.isBlank()) return;
        Component msg = Component.text("<" + f.name + "> " + line, TextColor.color(f.color.asRGB()));
        for (Player p : players(f)) p.sendMessage(msg);
    }

    private void snd(Fight f, String key, Location at, float vol, float pitch) {
        for (Player p : players(f)) p.playSound(at, "des_sea:boss." + f.id + "." + key, SoundCategory.HOSTILE, vol, pitch);
    }

    private void dustAt(Fight f, Location l, int n, double sp) {
        l.getWorld().spawnParticle(Particle.DUST, l, n, sp, sp, sp, 0, new Particle.DustOptions(f.color, 2.2f), true);
    }

    private void accentAt(Fight f, Location l, int n, double sp) {
        l.getWorld().spawnParticle(f.accent, l, n, sp, sp, sp, 0.02, null, true);
    }

    private void ring(Fight f, Location c, double r, int points) {
        for (int i = 0; i < points; i++) {
            double ang = i * Math.PI * 2 / points;
            dustAt(f, c.clone().add(Math.cos(ang) * r, 0.2, Math.sin(ang) * r), 1, 0.05);
        }
    }

    private void burst(Fight f, Location c, double r) {
        accentAt(f, c, 24, Math.min(r / 2, 6));
        dustAt(f, c, 16, Math.min(r / 2, 6));
    }
}
