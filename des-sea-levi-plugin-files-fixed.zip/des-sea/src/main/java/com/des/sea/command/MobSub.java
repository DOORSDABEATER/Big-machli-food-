package com.des.sea.command;

import com.des.sea.DesSeaPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

import java.util.*;

final class MobSub implements SubCommand {
    private final DesSeaPlugin plugin;

    MobSub(DesSeaPlugin plugin) { this.plugin = plugin; }

    private Set<String> known() {
        Set<String> out = new TreeSet<>();
        var tables = plugin.getConfig().getConfigurationSection("spawns.tables");
        if (tables != null) for (String biome : tables.getKeys(false))
            for (Map<?, ?> m : plugin.getConfig().getMapList("spawns.tables." + biome)) out.add(String.valueOf(m.get("mob")));
        return out;
    }

    @Override
    public void run(CommandSender s, String[] a) {
        String sub = a.length == 0 ? "list" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "list" -> s.sendMessage("Creatures in spawn tables: " + String.join(", ", known()));
            case "spawn" -> {
                if (!(s instanceof Player p) || a.length < 2) { s.sendMessage("Usage (player only): /dessea mob spawn <name> [amount]"); return; }
                String tpl = plugin.getConfig().getString("spawns.spawn-command", "");
                if (tpl.isBlank()) { s.sendMessage("spawns.spawn-command is empty in config.yml."); return; }
                if (!known().contains(a[1])) { s.sendMessage("Unknown creature '" + a[1] + "'. Use tab completion."); return; }
                int n = 1;
                if (a.length > 2) try { n = Math.max(1, Math.min(20, Integer.parseInt(a[2]))); } catch (NumberFormatException ex) { s.sendMessage("Amount must be a number."); return; }
                Location l = p.getLocation();
                for (int i = 0; i < n; i++) Bukkit.dispatchCommand(Bukkit.getConsoleSender(), tpl.replace("%mob%", a[1]).replace("%world%", l.getWorld().getName())
                        .replace("%x%", String.valueOf(l.getBlockX())).replace("%y%", String.valueOf(l.getBlockY())).replace("%z%", String.valueOf(l.getBlockZ())));
                plugin.audit(s.getName(), "mob spawn " + a[1] + " x" + n);
                s.sendMessage("Spawned " + n + " x " + a[1] + ".");
            }
            case "remove" -> {
                if (!(s instanceof Player p) || a.length < 2) { s.sendMessage("Usage (player only): /dessea mob remove <name> confirm"); return; }
                if (a.length < 3 || !a[2].equalsIgnoreCase("confirm")) { s.sendMessage("Removes loaded '" + a[1] + "' creatures within 128 blocks. Run: /dessea mob remove " + a[1] + " confirm"); return; }
                String tag = "des_mob_" + a[1].replaceFirst("^des_", "");
                int n = 0;
                for (Entity e : p.getNearbyEntities(128, 128, 128)) if (e.getScoreboardTags().contains(tag)) { e.remove(); n++; }
                plugin.audit(s.getName(), "mob remove " + a[1] + " (" + n + ")");
                s.sendMessage("Removed " + n + ".");
            }
            default -> s.sendMessage("Usage: /dessea mob <list|spawn|remove>");
        }
    }

    @Override
    public List<String> complete(CommandSender s, String[] a) {
        if (a.length == 1) return DiscoverySub.filter(List.of("list", "spawn", "remove"), a[0]);
        if (a.length == 2 && !a[0].equals("list")) return DiscoverySub.filter(List.copyOf(known()), a[1]);
        if (a.length == 3 && a[0].equals("remove")) return DiscoverySub.filter(List.of("confirm"), a[2]);
        return List.of();
    }
}
