package com.des.sea.discovery;

import com.des.sea.DesSeaPlugin;
import com.des.sea.core.DesModule;
import com.des.sea.discovery.DiscoveryEntry.Category;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * "DE S - OCEAN DISCOVERIES": a read-only chest GUI. Undiscovered entries show only their vague hint.
 * Icons are item models in the resource pack (des_sea:ui/...); the pack art is not made yet.
 */
public final class JournalGui implements DesModule, Listener, CommandExecutor {
    private static final int PER_PAGE = 45;

    private static final class Holder implements InventoryHolder {
        final Category category;
        final int page;
        Inventory inv;

        Holder(Category category, int page) { this.category = category; this.page = page; }

        @Override public Inventory getInventory() { return inv; }
    }

    private final DesSeaPlugin plugin;

    public JournalGui(DesSeaPlugin plugin) { this.plugin = plugin; }

    @Override public String id() { return "journal_gui"; }

    @Override
    public void enable() {
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
        var cmd = plugin.getCommand("journal");
        if (cmd != null) cmd.setExecutor(this);
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll(this);
        var cmd = plugin.getCommand("journal");
        if (cmd != null) cmd.setExecutor(null);
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getOpenInventory().getTopInventory().getHolder() instanceof Holder) p.closeInventory();
        }
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!(s instanceof Player p)) { s.sendMessage("Players only."); return true; }
        open(p, Category.BIOME, 0);
        return true;
    }

    private List<DiscoveryEntry> entries(Category c) {
        List<DiscoveryEntry> out = new ArrayList<>();
        for (DiscoveryEntry e : DiscoveryRegistry.all().values()) if (e.category() == c) out.add(e);
        return out;
    }

    private List<Category> tabs() {
        List<Category> out = new ArrayList<>();
        for (Category c : Category.values()) if (!entries(c).isEmpty()) out.add(c);
        return out;
    }

    private ItemStack icon(String model, Component name, List<Component> lore) {
        ItemStack it = new ItemStack(Material.PAPER);
        ItemMeta m = it.getItemMeta();
        m.setItemModel(NamespacedKey.fromString(model));
        m.displayName(name.decoration(TextDecoration.ITALIC, false));
        m.lore(lore);
        it.setItemMeta(m);
        return it;
    }

    private static String pretty(Category c) {
        String s = c.name().toLowerCase(Locale.ROOT).replace('_', ' ');
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    public void open(Player p, Category cat, int page) {
        if (!plugin.modules().isRunning("journal")) { p.sendMessage("The ocean journal is not available right now."); return; }
        var dm = plugin.discovery();
        Holder h = new Holder(cat, page);
        Inventory inv = Bukkit.createInventory(h, 54, Component.text("DE S — OCEAN DISCOVERIES"));
        h.inv = inv;

        List<DiscoveryEntry> list = entries(cat);
        int pages = Math.max(1, (list.size() + PER_PAGE - 1) / PER_PAGE);
        int pg = Math.max(0, Math.min(page, pages - 1));
        for (int i = 0; i < PER_PAGE; i++) {
            int idx = pg * PER_PAGE + i;
            if (idx >= list.size()) break;
            DiscoveryEntry e = list.get(idx);
            boolean known = dm.has(p.getUniqueId(), e.id());
            inv.setItem(i, known
                    ? icon("des_sea:ui/entry_" + cat.name().toLowerCase(Locale.ROOT), Component.text(e.name(), NamedTextColor.AQUA),
                            List.of(Component.text("Discovered", NamedTextColor.GREEN)))
                    : icon("des_sea:ui/entry_unknown", Component.text("???", NamedTextColor.DARK_GRAY),
                            List.of(Component.text(e.hint(), NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, true))));
        }
        // bottom row: tabs, then page arrows
        List<Category> tabs = tabs();
        for (int i = 0; i < Math.min(tabs.size(), 7); i++) {
            Category t = tabs.get(i);
            long have = entries(t).stream().filter(e -> dm.has(p.getUniqueId(), e.id())).count();
            inv.setItem(45 + i, icon("des_sea:ui/tab_" + t.name().toLowerCase(Locale.ROOT),
                    Component.text(pretty(t) + (t == cat ? " (open)" : ""), NamedTextColor.WHITE),
                    List.of(Component.text(have + "/" + entries(t).size(), NamedTextColor.GRAY))));
        }
        if (pg > 0) inv.setItem(52, icon("des_sea:ui/prev", Component.text("Previous page"), List.of()));
        if (pg < pages - 1) inv.setItem(53, icon("des_sea:ui/next", Component.text("Next page"), List.of()));
        p.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder h)) return;
        e.setCancelled(true); // read-only, including shift-clicks from the player's inventory
        if (!(e.getWhoClicked() instanceof Player p) || e.getClickedInventory() != e.getView().getTopInventory()) return;
        int slot = e.getSlot();
        if (slot >= 45 && slot < 52) {
            List<Category> tabs = tabs();
            int i = slot - 45;
            if (i < tabs.size()) open(p, tabs.get(i), 0);
        } else if (slot == 52 && e.getCurrentItem() != null) open(p, h.category, h.page - 1);
        else if (slot == 53 && e.getCurrentItem() != null) open(p, h.category, h.page + 1);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }
}
