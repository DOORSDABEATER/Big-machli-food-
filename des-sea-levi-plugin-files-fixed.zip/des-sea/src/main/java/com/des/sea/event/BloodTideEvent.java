package com.des.sea.event;

import com.des.sea.DesSeaPlugin;
import com.des.sea.core.Biomes;
import net.kyori.adventure.text.Component;
import org.bukkit.Color;
import org.bukkit.Particle;
import org.bukkit.SoundCategory;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Predators become unusually aggressive. This event is mostly a FLAG: the behaviour system reads running() to widen
 * predator range, speed and let them bite players; the creature spawner reads it to spawn more often. The event itself
 * adds red water haze and a low pulse for divers inside des_sea biomes.
 */
public final class BloodTideEvent implements DesEvent {
    private final DesSeaPlugin plugin;
    private BukkitTask task;
    private int ticksLeft, elapsed;
    private Runnable onEnd;

    public BloodTideEvent(DesSeaPlugin plugin) { this.plugin = plugin; }

    @Override public String id() { return "blood_tide"; }
    @Override public boolean running() { return task != null; }

    @Override
    public void start(Runnable onEnd) {
        if (task != null) return;
        this.onEnd = onEnd;
        elapsed = 0;
        ticksLeft = plugin.getConfig().getInt("events.blood_tide.duration-seconds", 180) * 20;
        task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 0L, 20L);
    }

    private void tick() {
        ticksLeft -= 20;
        elapsed++;
        if (ticksLeft <= 0) {
            Runnable cb = onEnd;
            stop();
            if (cb != null) cb.run();
            return;
        }
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (Player p : plugin.getServer().getOnlinePlayers()) {
            if (!p.isUnderWater() || Biomes.desBiome(p.getLocation()) == null) continue;
            for (int i = 0; i < 6; i++) // capped
                p.spawnParticle(Particle.DUST, p.getLocation().add(r.nextDouble(-5, 5), r.nextDouble(-2, 3), r.nextDouble(-5, 5)), 1, 0, 0, 0, 0, new Particle.DustOptions(Color.fromRGB(140, 10, 20), 1.8f));
            if (elapsed % 4 == 0) p.playSound(p.getLocation(), "des_sea:event.blood_tide.pulse", SoundCategory.AMBIENT, 0.7f, 0.8f);
            if (elapsed == 1) p.sendActionBar(Component.text("The water tastes of iron."));
        }
    }

    @Override
    public void stop() {
        if (task != null) task.cancel();
        task = null;
        onEnd = null;
    }
}
