package com.des.sea.vehicle;

import com.des.sea.DesSeaPlugin;
import com.des.sea.core.DesModule;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.RayTraceResult;

import java.util.*;

/**
 * Plugin-side vehicle physics. A vehicle is an invisible armor stand (the "carrier") that riders sit on,
 * with an ItemDisplay passenger showing the pack model (des_sea:vehicle/<id>). ModelEngine models can replace the display later.
 * Parked vehicles are just persistent entities tagged with PDC; only vehicles with a rider are ticked.
 * Everything here is UNTESTED: movement feel, smoothness and the Paper API calls need a real server.
 */
public final class VehicleManager implements DesModule, Listener {
    private static final class Active {
        final ArmorStand stand;
        final VehicleType type;
        ItemDisplay display;
        double speed, yaw, boost;
        int tick;

        Active(ArmorStand stand, VehicleType type) {
            this.stand = stand;
            this.type = type;
            this.yaw = stand.getLocation().getYaw();
        }
    }

    private final DesSeaPlugin plugin;
    private final NamespacedKey keyId, keyType, keyOwner, keyItem, keyDisplay;
    private final Map<UUID, Active> active = new HashMap<>();
    private BukkitTask task;

    public VehicleManager(DesSeaPlugin plugin) {
        this.plugin = plugin;
        keyId = new NamespacedKey(plugin, "vehicle_id");
        keyType = new NamespacedKey(plugin, "vehicle_type");
        keyOwner = new NamespacedKey(plugin, "vehicle_owner");
        keyItem = new NamespacedKey(plugin, "vehicle_item");
        keyDisplay = new NamespacedKey(plugin, "vehicle_display");
    }

    @Override public String id() { return "vehicles"; }

    @Override
    public void enable() {
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
        task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tickAll, 1L, 1L);
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll(this);
        if (task != null) task.cancel();
        task = null;
        active.clear(); // parked vehicles persist in the world; nothing else to clean
    }

    // ---------- stats ----------

    private double stat(VehicleType t, String k, double def) { return plugin.getConfig().getDouble("vehicles." + t.id + "." + k, def); }

    // ---------- items / spawning ----------

    public ItemStack createItem(VehicleType t) {
        ItemStack it = new ItemStack(Material.PAPER);
        ItemMeta m = it.getItemMeta();
        m.setItemModel(NamespacedKey.fromString("des_sea:item/vehicle_" + t.id));
        m.displayName(Component.text(t.display).decoration(TextDecoration.ITALIC, false));
        m.getPersistentDataContainer().set(keyItem, PersistentDataType.STRING, t.id);
        it.setItemMeta(m);
        return it;
    }

    private ItemStack modelItem(VehicleType t) {
        ItemStack it = new ItemStack(Material.PAPER);
        ItemMeta m = it.getItemMeta();
        m.setItemModel(NamespacedKey.fromString("des_sea:vehicle/" + t.id));
        it.setItemMeta(m);
        return it;
    }

    public ArmorStand spawn(Location l, VehicleType t, UUID owner) {
        String vid = UUID.randomUUID().toString().substring(0, 8);
        ArmorStand st = l.getWorld().spawn(l, ArmorStand.class, s -> {
            s.setInvisible(true);
            s.setGravity(false);
            s.setInvulnerable(true);
            s.setSilent(true);
            s.setPersistent(true);
            s.setBasePlate(false);
            s.setArms(false);
            s.setCollidable(false);
            var pdc = s.getPersistentDataContainer();
            pdc.set(keyId, PersistentDataType.STRING, vid);
            pdc.set(keyType, PersistentDataType.STRING, t.id);
            if (owner != null) pdc.set(keyOwner, PersistentDataType.STRING, owner.toString());
        });
        ensureDisplay(st, t);
        return st;
    }

    private ItemDisplay findDisplay(ArmorStand st) {
        for (Entity e : st.getPassengers()) if (e instanceof ItemDisplay d) return d;
        return null;
    }

    private ItemDisplay ensureDisplay(ArmorStand st, VehicleType t) {
        ItemDisplay d = findDisplay(st);
        if (d != null) return d;
        String vid = st.getPersistentDataContainer().get(keyId, PersistentDataType.STRING);
        d = st.getWorld().spawn(st.getLocation(), ItemDisplay.class, x -> {
            x.setItemStack(modelItem(t));
            x.setPersistent(true);
            x.getPersistentDataContainer().set(keyDisplay, PersistentDataType.STRING, vid == null ? "?" : vid);
        });
        st.addPassenger(d);
        return d;
    }

    public List<ArmorStand> loadedVehicles() {
        List<ArmorStand> out = new ArrayList<>();
        for (World w : Bukkit.getWorlds()) {
            for (ArmorStand s : w.getEntitiesByClass(ArmorStand.class)) {
                if (s.getPersistentDataContainer().has(keyType, PersistentDataType.STRING)) out.add(s);
            }
        }
        return out;
    }

    public String idOf(ArmorStand s) { return s.getPersistentDataContainer().get(keyId, PersistentDataType.STRING); }
    public String typeOf(ArmorStand s) { return s.getPersistentDataContainer().get(keyType, PersistentDataType.STRING); }

    public boolean remove(String vid) {
        for (ArmorStand s : loadedVehicles()) {
            if (vid.equals(idOf(s))) { destroy(s); return true; }
        }
        return false;
    }

    private void destroy(ArmorStand s) {
        active.remove(s.getUniqueId());
        for (Entity e : new ArrayList<>(s.getPassengers())) if (e instanceof ItemDisplay) e.remove(); else s.removePassenger(e);
        s.remove();
    }

    // ---------- player interaction ----------

    @EventHandler
    public void onUseItem(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack it = e.getItem();
        if (it == null || !it.hasItemMeta()) return;
        VehicleType t = VehicleType.byId(it.getItemMeta().getPersistentDataContainer().get(keyItem, PersistentDataType.STRING));
        if (t == null) return;
        e.setCancelled(true);
        Player p = e.getPlayer();
        RayTraceResult rt = p.rayTraceBlocks(6, FluidCollisionMode.ALWAYS);
        Block hit = rt == null ? null : rt.getHitBlock();
        if (hit == null || !hit.isLiquid()) { p.sendActionBar(Component.text("Needs open water.")); return; }
        Location at = new Location(p.getWorld(), hit.getX() + 0.5, hit.getY() + (t.underwater ? 0.0 : 0.85), hit.getZ() + 0.5, p.getLocation().getYaw(), 0f);
        it.setAmount(it.getAmount() - 1); // consume first, then spawn: no duplication path
        spawn(at, t, p.getUniqueId());
    }

    @EventHandler
    public void onEnter(PlayerInteractAtEntityEvent e) {
        if (!(e.getRightClicked() instanceof ArmorStand st)) return;
        VehicleType t = VehicleType.byId(typeOf(st));
        if (t == null) return;
        e.setCancelled(true);
        if (e.getHand() != EquipmentSlot.HAND) return;
        Player p = e.getPlayer();
        if (p.isSneaking()) { pickup(p, st, t); return; }
        long riders = st.getPassengers().stream().filter(x -> x instanceof Player).count();
        if (riders >= (int) stat(t, "seats", 1)) return;
        ensureDisplay(st, t);
        st.addPassenger(p);
        Active a = active.computeIfAbsent(st.getUniqueId(), k -> new Active(st, t));
        a.display = findDisplay(st);
    }

    private void pickup(Player p, ArmorStand st, VehicleType t) {
        String owner = st.getPersistentDataContainer().get(keyOwner, PersistentDataType.STRING);
        boolean mine = owner != null && owner.equals(p.getUniqueId().toString());
        if (!mine && !p.hasPermission("des.sea.admin")) { p.sendActionBar(Component.text("Not your vehicle.")); return; }
        if (st.getPassengers().stream().anyMatch(x -> x instanceof Player)) return;
        destroy(st); // remove the entity first, then hand back the item
        p.getInventory().addItem(createItem(t)).values().forEach(left -> p.getWorld().dropItemNaturally(p.getLocation(), left));
    }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        Entity en = e.getEntity();
        if (en instanceof ArmorStand s && typeOf(s) != null) e.setCancelled(true);
        if (en instanceof ItemDisplay d && d.getPersistentDataContainer().has(keyDisplay, PersistentDataType.STRING)) e.setCancelled(true);
    }

    @EventHandler
    public void onManipulate(PlayerArmorStandManipulateEvent e) {
        if (typeOf(e.getRightClicked()) != null) e.setCancelled(true);
    }

    // ---------- movement ----------

    private void tickAll() {
        if (active.isEmpty()) return;
        for (Map.Entry<UUID, Active> en : new ArrayList<>(active.entrySet())) {
            Active a = en.getValue();
            if (!a.stand.isValid()) { active.remove(en.getKey()); continue; }
            Player rider = null;
            for (Entity p : a.stand.getPassengers()) if (p instanceof Player pl) { rider = pl; break; }
            if (rider == null) { active.remove(en.getKey()); continue; } // parked
            try {
                move(a, rider);
            } catch (Throwable t) {
                plugin.getLogger().warning("Vehicle tick failed, parking it: " + t);
                active.remove(en.getKey());
            }
        }
    }

    private void move(Active a, Player rider) {
        VehicleType t = a.type;
        Input in = rider.getCurrentInput(); // needs a Paper version with the Input API (see notes)
        double max = stat(t, "max-speed", 0.3), accel = stat(t, "accel", 0.015), turn = stat(t, "turn", 3.0);
        double boostMult = stat(t, "boost", 1.0), boostMax = stat(t, "boost-ticks", 0);

        // steering
        if (in.isRight()) a.yaw += turn;
        if (in.isLeft()) a.yaw -= turn;

        // boost (surface boats): hold jump
        boolean boosting = !t.underwater && in.isJump() && a.boost > 0 && boostMult > 1.0 && a.speed > 0.05;
        if (boosting) a.boost--; else a.boost = Math.min(boostMax, a.boost + 0.5);
        double cap = max * (boosting ? boostMult : 1.0);

        // throttle
        if (in.isForward()) a.speed = Math.min(a.speed + accel * (boosting ? 1.5 : 1.0), cap);
        else if (in.isBackward()) a.speed = Math.max(a.speed - accel * 1.5, -max * 0.4);
        else a.speed *= 0.965;
        if (a.speed > cap) a.speed *= 0.98;
        if (Math.abs(a.speed) < 0.005) a.speed = 0;

        Location cur = a.stand.getLocation();
        double yawRad = Math.toRadians(a.yaw);
        double hx = -Math.sin(yawRad), hz = Math.cos(yawRad);
        double vy = 0, hf = 1;
        if (t.underwater) {
            double pitch = Math.max(-40, Math.min(40, rider.getLocation().getPitch()));
            vy = -Math.sin(Math.toRadians(pitch)) * a.speed;
            hf = Math.cos(Math.toRadians(pitch));
            if (in.isJump()) vy += 0.06;
            if (in.isSprint()) vy -= 0.06;
        }
        double nx = cur.getX() + hx * a.speed * hf, nz = cur.getZ() + hz * a.speed * hf, ny = cur.getY() + vy;
        World w = cur.getWorld();

        if (t.underwater) {
            double limit = w.getSeaLevel() - stat(t, "max-depth", 40);
            if (ny < limit) { ny = limit; rider.sendActionBar(Component.text("Pressure limit reached.")); }
            if (ny > w.getSeaLevel() - 0.5) ny = w.getSeaLevel() - 0.5; // stay submerged
            if (blocked(w, nx, ny, nz, true)) { a.speed = 0; nx = cur.getX(); nz = cur.getZ(); ny = cur.getY(); }
        } else {
            int by = (int) Math.floor(cur.getY());
            Block b = w.getBlockAt((int) Math.floor(nx), by, (int) Math.floor(nz));
            if (!b.isLiquid()) b = w.getBlockAt(b.getX(), by - 1, b.getZ());
            if (!b.isLiquid()) { a.speed = 0; nx = cur.getX(); nz = cur.getZ(); ny = cur.getY(); }
            else {
                int top = b.getY(), n = 0;
                while (n++ < 8 && w.getBlockAt(b.getX(), top + 1, b.getZ()).isLiquid()) top++;
                ny = top + 0.85; // ride on the water surface
                if (blocked(w, nx, ny, nz, false)) { a.speed = 0; nx = cur.getX(); nz = cur.getZ(); ny = cur.getY(); }
            }
        }

        Location to = new Location(w, nx, ny, nz, (float) a.yaw, 0f);
        a.stand.teleport(to, PlayerTeleportEvent.TeleportCause.PLUGIN, io.papermc.paper.entity.TeleportFlag.EntityState.RETAIN_PASSENGERS);
        if (a.display != null && a.display.isValid()) a.display.setRotation((float) a.yaw, 0f);

        // feedback, capped: one sound per 8 ticks, a few particles only when fast
        if (++a.tick % 8 == 0 && Math.abs(a.speed) > 0.02) {
            w.playSound(to, "des_sea:vehicle." + t.id + ".engine", SoundCategory.NEUTRAL, 0.8f, (float) (0.7 + 0.8 * Math.abs(a.speed) / max));
        }
        if (!t.underwater && a.speed > 0.15) w.spawnParticle(Particle.SPLASH, to, 3, 0.3, 0.1, 0.3, 0.0);
        // Ghost Vessel (design decision: a surface boat that leaves a spectral wake)
        if (t == VehicleType.GHOST_VESSEL && Math.abs(a.speed) > 0.05) {
            Location behind = to.clone().subtract(hx * 1.5, 0, hz * 1.5);
            w.spawnParticle(Particle.SOUL_FIRE_FLAME, behind, 4, 0.4, 0.2, 0.4, 0.01);
            w.spawnParticle(Particle.SOUL, behind, 1, 0.3, 0.1, 0.3, 0.0);
        }
    }

    /** Solid-block collision check around a roughly 1.4-wide, 2-high hull. */
    private boolean blocked(World w, double x, double y, double z, boolean sub) {
        double r = 0.7;
        double[][] offs = {{0, 0}, {r, 0}, {-r, 0}, {0, r}, {0, -r}};
        int dys = sub ? 2 : 1;
        for (double[] o : offs) {
            for (int dy = 0; dy < dys; dy++) {
                if (!w.getBlockAt((int) Math.floor(x + o[0]), (int) Math.floor(y) + dy, (int) Math.floor(z + o[1])).isPassable()) return true;
            }
        }
        if (sub && !w.getBlockAt((int) Math.floor(x), (int) Math.floor(y), (int) Math.floor(z)).isLiquid()) return true;
        return false;
    }
}
