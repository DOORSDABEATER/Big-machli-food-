package com.des.sea.event;

import com.des.sea.DesSeaPlugin;
import com.des.sea.core.Biomes;
import net.kyori.adventure.text.Component;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.entity.Player;
import org.bukkit.loot.LootTable;
import org.bukkit.loot.Lootable;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * An event that temporarily places one or more template structures near players (Lost Cargo, Ghost Fleet), then rolls them back.
 * Needs a captured template named by events.<id>.template. Placement goes through the safe StructurePlacer (checks, snapshot, rollback).
 * Leftovers survive restarts: ids are persisted and cleaned up on the next start. Loot comes from a loot table you provide
 * (chests in the template are filled if empty and unlooted); the template itself cannot carry inventory contents.
 */
public final class TempStructureEvent implements DesEvent {
    private final DesSeaPlugin plugin;
    private final String eventId;
    private final File file;
    private final List<String> placed = new ArrayList<>();
    private final Deque<String> cleanup = new ArrayDeque<>();
    private BukkitTask watch, cleaner;
    private boolean active;
    private int toPlace;
    private long expiresAt;
    private Runnable onEnd;

    public TempStructureEvent(DesSeaPlugin plugin, String eventId) {
        this.plugin = plugin;
        this.eventId = eventId;
        this.file = new File(plugin.getDataFolder(), "temp-" + eventId + ".yml");
    }

    @Override public String id() { return eventId; }
    @Override public boolean running() { return active; }

    private String cfgS(String k, String d) { return plugin.getConfig().getString("events." + eventId + "." + k, d); }
    private double cfgD(String k, double d) { return plugin.getConfig().getDouble("events." + eventId + "." + k, d); }

    @Override
    public void onEnable() {
        if (!file.exists()) return;
        var c = YamlConfiguration.loadConfiguration(file);
        cleanup.addAll(c.getStringList("ids"));
        if (!cleanup.isEmpty()) {
            plugin.getLogger().info(eventId + ": cleaning up " + cleanup.size() + " structure(s) left from a previous run.");
            startCleaner();
        }
    }

    @Override
    public void start(Runnable onEnd) {
        if (active) return;
        String template = cfgS("template", "");
        if (template.isBlank() || !plugin.placer().hasTemplate(template)) {
            plugin.getLogger().info(eventId + ": no template '" + template + "' captured yet; event not started.");
            return;
        }
        List<Player> candidates = candidates();
        if (candidates.isEmpty()) return;
        active = true;
        this.onEnd = onEnd;
        toPlace = Math.max(1, (int) cfgD("count", 1));
        expiresAt = System.currentTimeMillis() + (long) (cfgD("duration-minutes", 30) * 60_000L);
        watch = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            if (active && toPlace <= 0 && System.currentTimeMillis() >= expiresAt) finishNaturally();
        }, 600L, 600L);
        placeNext(candidates, template);
    }

    private List<Player> candidates() {
        String biome = cfgS("require-biome", "");
        List<String> worlds = plugin.getConfig().getStringList("world.allowed-worlds");
        List<Player> out = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!worlds.contains(p.getWorld().getName())) continue;
            if (!biome.isBlank() && !Biomes.in(p.getLocation(), biome)) continue;
            out.add(p);
        }
        return out;
    }

    private void placeNext(List<Player> cands, String template) {
        if (!active) return;
        if (toPlace <= 0) return;
        pickSpot(cands, 12, spot -> {
            if (!active) return;
            if (spot == null) { plugin.getLogger().info(eventId + ": no valid spot found."); toPlace = 0; checkEmptyStart(); return; }
            int rot = ThreadLocalRandom.current().nextInt(4) * 90;
            String err = plugin.placer().spawn(Bukkit.getConsoleSender(), template, spot, rot, null, ok -> {
                if (!active) return;
                toPlace--;
                if (ok) {
                    var e = plugin.structures().nearest(template, spot);
                    e.ifPresent(en -> { placed.add(en.id()); persist(); applyLoot(spot); });
                    String msg = cfgS("announce", "");
                    if (!msg.isBlank()) Bukkit.broadcast(Component.text(msg));
                }
                if (toPlace > 0) placeNext(cands, template); else checkEmptyStart();
            });
            if (err != null) { plugin.getLogger().info(eventId + ": " + err); toPlace = 0; checkEmptyStart(); }
        });
    }

    /** If nothing could be placed at all, end quietly. */
    private void checkEmptyStart() {
        if (placed.isEmpty() && active) finishNaturally();
    }

    private void pickSpot(List<Player> cands, int attempts, java.util.function.Consumer<Location> cb) {
        if (attempts <= 0 || cands.isEmpty()) { cb.accept(null); return; }
        ThreadLocalRandom r = ThreadLocalRandom.current();
        Player p = cands.get(r.nextInt(cands.size()));
        if (!p.isOnline()) { pickSpot(cands, attempts - 1, cb); return; }
        double min = cfgD("min-distance", 80), max = Math.max(min + 1, cfgD("max-distance", 150));
        double ang = r.nextDouble(Math.PI * 2), dist = min + r.nextDouble(max - min);
        World w = p.getWorld();
        int x = (int) (p.getLocation().getX() + Math.cos(ang) * dist), z = (int) (p.getLocation().getZ() + Math.sin(ang) * dist);
        String biome = cfgS("require-biome", "");
        w.getChunkAtAsync(x >> 4, z >> 4).whenComplete((chunk, err) -> plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (err != null || !active) { cb.accept(null); return; }
            int y = w.getHighestBlockYAt(x, z, HeightMap.OCEAN_FLOOR) + 1 + (int) cfgD("y-offset", 0);
            Location l = new Location(w, x, y, z);
            Block above = w.getBlockAt(x, y + 1, z);
            boolean water = above.getType() == Material.WATER;
            boolean biomeOk = biome.isBlank() || Biomes.in(l, biome);
            if (water && biomeOk) cb.accept(l); else pickSpot(cands, attempts - 1, cb);
        }));
    }

    /** Fills empty, unlooted chests/barrels near the spot with the configured loot table. Does nothing if none configured. */
    private void applyLoot(Location spot) {
        String key = cfgS("loot-table", "");
        if (key.isBlank()) return;
        NamespacedKey nk = NamespacedKey.fromString(key);
        LootTable table = nk == null ? null : Bukkit.getLootTable(nk);
        if (table == null) { plugin.getLogger().warning(eventId + ": loot table '" + key + "' does not exist (provide it in a datapack)."); return; }
        int rad = (int) cfgD("loot-radius", 24);
        for (int cx = (spot.getBlockX() - rad) >> 4; cx <= (spot.getBlockX() + rad) >> 4; cx++) {
            for (int cz = (spot.getBlockZ() - rad) >> 4; cz <= (spot.getBlockZ() + rad) >> 4; cz++) {
                if (!spot.getWorld().isChunkLoaded(cx, cz)) continue;
                for (BlockState st : spot.getWorld().getChunkAt(cx, cz).getTileEntities()) {
                    if (!(st instanceof Lootable l) || !(st instanceof org.bukkit.block.Container c)) continue;
                    if (Math.abs(st.getX() - spot.getBlockX()) > rad || Math.abs(st.getZ() - spot.getBlockZ()) > rad || Math.abs(st.getY() - spot.getBlockY()) > rad) continue;
                    if (l.hasLootTable() || !c.getSnapshotInventory().isEmpty()) continue; // never touch a chest that already has contents
                    l.setLootTable(table);
                    st.update();
                }
            }
        }
    }

    private void finishNaturally() {
        Runnable cb = onEnd;
        stop();
        if (cb != null) cb.run();
    }

    @Override
    public void stop() {
        if (watch != null) watch.cancel();
        watch = null;
        active = false;
        onEnd = null;
        toPlace = 0;
        cleanup.addAll(placed);
        placed.clear();
        persist();
        startCleaner();
    }

    /** Shutdown must not try to roll back (the server is going down): ids stay persisted and are cleaned on next start. */
    @Override
    public void onShutdown() {
        if (watch != null) watch.cancel();
        if (cleaner != null) cleaner.cancel();
        watch = cleaner = null;
        active = false;
        cleanup.addAll(placed);
        placed.clear();
        persist();
    }

    private void startCleaner() {
        if (cleaner != null || cleanup.isEmpty()) return;
        cleaner = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            if (cleanup.isEmpty()) { cleaner.cancel(); cleaner = null; persist(); return; }
            if (plugin.placer().busy()) return; // retry next tick; one placer job at a time
            String id = cleanup.peek();
            String err = plugin.placer().rollback(Bukkit.getConsoleSender(), id, null);
            if (err == null || err.startsWith("No structure")) cleanup.poll();
            else plugin.getLogger().warning(eventId + " cleanup of " + id + ": " + err + " (will retry)");
        }, 20L, 20L);
    }

    private void persist() {
        var c = new YamlConfiguration();
        List<String> all = new ArrayList<>(placed);
        all.addAll(cleanup);
        c.set("ids", all);
        try {
            plugin.getDataFolder().mkdirs();
            c.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save " + file.getName() + ": " + e.getMessage());
        }
    }
}
