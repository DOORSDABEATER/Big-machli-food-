package com.des.sea.command;

import com.des.sea.DesSeaPlugin;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Locale;

final class ItemSub implements SubCommand {
    private final DesSeaPlugin plugin;

    ItemSub(DesSeaPlugin plugin) { this.plugin = plugin; }

    @Override
    public void run(CommandSender s, String[] a) {
        if (!plugin.modules().isRunning("items")) { s.sendMessage("The items module is off. Set modules.items: true in config.yml and /dessea reload."); return; }
        var im = plugin.items();
        String sub = a.length == 0 ? "list" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "list" -> s.sendMessage("Items: " + String.join(", ", im.ids()));
            case "give" -> {
                if (a.length < 3) { s.sendMessage("Usage: /dessea item give <player> <item> [amount]"); return; }
                Player p = Bukkit.getPlayerExact(a[1]);
                if (p == null) { s.sendMessage("Player '" + a[1] + "' is not online."); return; }
                int n = 1;
                if (a.length > 3) try { n = Integer.parseInt(a[3]); } catch (NumberFormatException ex) { s.sendMessage("Amount must be a number."); return; }
                boolean ok = im.give(p, a[2], n);
                plugin.audit(s.getName(), "item give " + a[1] + " " + a[2] + " x" + n);
                s.sendMessage(ok ? "Gave " + a[2] + " to " + p.getName() + "." : "Unknown item '" + a[2] + "'.");
            }
            default -> s.sendMessage("Usage: /dessea item <list|give>");
        }
    }

    @Override
    public List<String> complete(CommandSender s, String[] a) {
        if (a.length == 1) return DiscoverySub.filter(List.of("list", "give"), a[0]);
        if (a.length == 2 && a[0].equals("give")) return DiscoverySub.filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), a[1]);
        if (a.length == 3 && a[0].equals("give") && plugin.items() != null) return DiscoverySub.filter(List.copyOf(plugin.items().ids()), a[2]);
        return List.of();
    }
}
