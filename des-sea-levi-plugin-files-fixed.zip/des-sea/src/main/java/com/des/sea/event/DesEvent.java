package com.des.sea.event;

public interface DesEvent {
    String id();
    boolean running();
    /** Begin the event. Call onEnd when it finishes on its own. Must be safe to stop() at any time. */
    void start(Runnable onEnd);
    /** Cancel all tasks and remove all temporary entities. Idempotent. */
    void stop();
    /** Called once when the event manager starts. Use to resume/clean leftovers from a previous run. */
    default void onEnable() {}
    /** Called when the plugin shuts down. Default stops the event; events with persistent leftovers override this. */
    default void onShutdown() { stop(); }
}
