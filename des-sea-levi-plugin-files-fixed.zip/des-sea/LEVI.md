# Levi, the Sovereign Beneath: model and animation guide

## Files
- `modelengine/blueprints/levi.bbmodel` -> copy to `plugins/ModelEngine/blueprints/` then `/meg reload`
- `modelengine/blueprints/levi_abyssal_spawn.bbmodel` (the adds from Call of the Deep) -> same folder
- `mythic/Mobs/levi.yml` -> `plugins/MythicMobs/Mobs/` then `/mm reload`
- Sounds, boss-part models and item models: already in `resourcepack/` (see ASSET_CHECKLIST.md)
- Regenerate the model any time: `python3 tools/levi.py` (edit proportions, markings, or any animation in that file)

## The model
Colossal serpent, 20 body segments (569 px = about 36 blocks at scale 1; config `model-scale: 2.5` makes him about 90 blocks). Dark abyssal scales,
glowing cyan flank markings, dorsal runes, gill slits, a dorsal sail with bone struts, pectoral and ventral fins, a tail fluke with a glowing tip.
Head: armoured skull with brow ridge, nostrils, large glowing eyes (halo + iris), two rows of fangs plus tusks, a lower jaw with its own fangs and a glowing
throat, four barbels on each side, and a crown of bone (central spike, four pairs of curved spikes with glow tips, two swept horns).
Chest: a cavity holding the glowing core, covered by four hinged armour plates (the "protective structures"; they open in `core_open`).
Bones (78): seg0..seg19, spine0..spine17, sail6..sail14, head, snout, jaw, crown, crown_l, crown_r, horn_l, horn_r, eye_l/eye_r, fin_l/fin_r, fin2_l/fin2_r, plate_l3/r3/l4/r4, core, maw_glow, barb_l0-3/barb_r0-3, fluke, hitbox. 253 cubes, 512 px texture, about 36,000 keyframes (6 MB file).
Origin is at the head, so beams, charges and slams start where his head is.

## Animations (33). Attack animation names are exactly the attack ids, so they play in sync with the engine
| Animation | Length | Played when |
|---|---|---|
| idle (loop) / swim (loop) / swim_fast (loop) | 6 / 4 / 2 s | idle when still, swim when the engine moves him |
| emerge | 10 s | the moment he spawns: eyes appear first, then he rises from 380 px below. Engine blocks damage and attacks for `emerge-ticks: 200` |
| intro | 5 s | start of phase 1 (Watcher studies the players, then a roar) |
| roar, enrage | 3.2 / 3.4 s | roar is available; enrage plays when the enrage timer fires |
| phase_change_1..4 | 3.5 / 4.5 / 5 / 5 s | entering Hunter, Sovereign, Catastrophe, Last Tide |
| core_open (hold) / core_close | 1.6 / 1.2 s | plates swing open when the Last Tide damage window starts, close when it ends |
| vulnerable (loop) | 3 s | slumped pose, available for custom use |
| hurt | 0.7 s | flinch, at most once per 1.5 s while not attacking |
| death (hold) | 12 s | thrash, slump, jaw falls open, eyes go dark, core fades, he sinks 26 blocks |
| abyssal_gaze | 6.6 s | head sweeps with the beam, eyes flare |
| undertow | 5.0 s | inhale: jaw wide, chest swells, fins swept back, barbels pulled in, snap shut |
| crushing_wake | 4.4 s | coils his tail beside his head, then slams it down |
| devouring_charge | 5.4 s | S-curve coil, then straight lunge with jaw wide and fins swept back |
| abyssal_coil | 7.8 s | spiral coil, constricting pulses, crush at 6.5 s, release |
| depth_breaker | 3.9 s | neck rises high, snaps down on the marked circle |
| tidal_collapse | 8.8 s | rears up and slams twice, matching the two shockwave rings |
| black_current | 5.4 s | wide thrashing wave, fins flapping, barbels streaming |
| call_of_the_deep | 3.4 s | rears back, throat glows, crown flares |
| abyssal_roar | 3.8 s | full roar, strong shake |
| worldbreaker | 8.8 s | tight spiral, head high, eyes blaze for 5 s, then a full-body slam |
| devouring_depths | 6.2 s | jaw wide with throat glowing, final bite and lunge |
| leviathans_wrath | 8.6 s | arches back, then spins a full turn with the 360 degree beam |
| rupture | 3.9 s | crouches, tail lifts, ripples out as the floor lines erupt |
| final_descent | 5.0 s | climbs high, dives head-first |
| sovereigns_maw | 5.4 s | violent jaw, bite and lunge |
| last_cataclysm | 12.6 s | three rear-and-slam cycles matching the three rings |

Every attack animation is at least as long as the attack it covers (checked by script) and its strike frame lands on the attack's telegraph time.

## Attack mechanics (unchanged design, implemented by the boss engine; numbers in `bosses/levi.yml`)
Watcher: Abyssal Gaze (sweeping beam), Undertow (vortex), Crushing Wake (shockwave, dodge vertically).
Hunter: Devouring Charge, Abyssal Coil (grab; damage him to break free), Depth Breaker (marked-circle slam).
Sovereign (untouchable until 3 Abyssal Nodes die): Tidal Collapse (2 rings), Black Current, Call of the Deep (summons Abyssal Spawn), Abyssal Roar.
Catastrophe (Tidebound Shelters; lethal attacks kill anyone outside an active shelter): Worldbreaker, Devouring Depths, Leviathan's Wrath, Rupture.
Last Tide (4 Core Plates; breaking all opens a 10 s x2.5 window): Final Descent, Sovereign's Maw, Last Cataclysm (3 rings).

## Things I could not verify (check these first)
1. **ModelEngine API calls** (`ModelBridge.java`) are written from memory of ModelEngine R4. If the first fight logs a "[ModelEngine bridge]" warning, send it.
2. **Rotation direction.** The animations assume +X tips the front down. If Levi rears the wrong way, set `SIGN_X = -1.0` at the top of `tools/levi.py`, run it, and reload.
3. **Model size limits.** Every rendered bone fits in a 48 px box (checked by `tools/validate_bbmodel.py`); only the invisible `hitbox` bone is larger. I split the head, crown, horns, spines and sail into separate bones for that reason.
4. **The body is rigid between the head and the animation.** The plugin turns the whole model to face the nearest player; the body waves via animation but does not trail along a path.
5. Entity type is `SQUID` in the mob file (any LivingEntity works), and the MythicMobs option and mechanic names are from memory.
