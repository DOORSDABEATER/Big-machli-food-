"""Minimal Blockbench (.bbmodel, 'free' format) writer for ModelEngine: bones, cubes, procedurally painted atlas, animations, preview."""
import base64, io, json, math, random
import numpy as np
from PIL import Image, ImageDraw
from scipy.ndimage import gaussian_filter

FACE_ORDER = ("north", "east", "south", "west", "up", "down")

def hexrgb(h):
    if isinstance(h, (tuple, list, np.ndarray)): return np.array(h, dtype=float)
    h = h.lstrip("#"); return np.array([int(h[i:i + 2], 16) for i in (0, 2, 4)], dtype=float)

class Bone:
    def __init__(self, name, parent, origin, rot, uid):
        self.name, self.parent, self.origin, self.rot, self.uuid = name, parent, list(origin), list(rot), uid
        self.children, self.cubes = [], []

class Cube:
    def __init__(self, name, bone, f, t, origin, rot, role, uid):
        self.name, self.bone, self.f, self.t, self.origin, self.rot, self.role, self.uuid = name, bone, list(f), list(t), list(origin), list(rot), role, uid
        self.region = None

class Anim:
    def __init__(self, name, length, loop):
        self.name, self.length, self.loop, self.keys = name, length, loop, {}
    def k(self, bone, channel, time, x, y, z, interp="catmullrom"):
        self.keys.setdefault(bone, {}).setdefault(channel, []).append((float(time), (float(x), float(y), float(z)), interp))
        return self

class Model:
    def __init__(self, mid, palette, uv_scale=1.0, seed=0, pattern="plain"):
        self.id, self.pal, self.s, self.pattern = mid, {k: hexrgb(v) if not isinstance(v, tuple) or isinstance(v[0], (int, float)) else (hexrgb(v[0]), hexrgb(v[1])) for k, v in palette.items()}, uv_scale, pattern
        self.rng = random.Random(seed); self.seed = seed
        self.bones, self.by_name, self.cubes, self.anims = [], {}, [], []
        self.meta = {}
    def uid(self): import uuid; return str(uuid.UUID(int=self.rng.getrandbits(128), version=4))
    def bone(self, name, parent=None, origin=(0, 0, 0), rot=(0, 0, 0)):
        b = Bone(name, self.by_name[parent] if parent else None, origin, rot, self.uid())
        (self.by_name[parent].children if parent else self.bones).append(b); self.by_name[name] = b; return b
    def cube(self, bone, f, t, role="body", rot=(0, 0, 0), origin=None, name=None):
        b = self.by_name[bone]; f = [min(a, c) for a, c in zip(f, t)]; t = [max(a, c) for a, c in zip(f, t)] if False else t
        lo = [min(a, c) for a, c in zip(f, t)]; hi = [max(a, c) for a, c in zip(f, t)]
        c = Cube(name or f"{bone}_c{len(b.cubes)}", b, lo, hi, origin or [(lo[i] + hi[i]) / 2 for i in range(3)], rot, role, self.uid())
        b.cubes.append(c); self.cubes.append(c); return c
    def anim(self, name, length, loop="loop"):
        a = Anim(name, length, loop); self.anims.append(a); return a

    # -------------------------------------------------- texture
    def _pack(self):
        sizes = []
        for c in self.cubes:
            dx, dy, dz = (c.t[i] - c.f[i] for i in range(3))
            w, h, d = (max(1, math.ceil(v / self.s)) for v in (dx, dy, dz))
            c.dims = (w, h, d); sizes.append((c, 2 * d + 2 * w, d + h))
        W = 64
        while True:
            x = y = rowh = 0; ok = True
            for c, cw, ch in sorted(sizes, key=lambda s: -s[2]):
                if x + cw > W: x, y, rowh = 0, y + rowh, 0
                c.region = (x, y); x += cw; rowh = max(rowh, ch)
                if y + max(rowh, ch) > W: ok = False; break
            if ok: break
            W *= 2
            if W > 2048: raise RuntimeError(f"{self.id}: texture too large")
        return W

    def _paint(self, W):
        rng = np.random.default_rng(self.seed); atlas = np.zeros((W, W, 4), dtype=np.uint8)
        for c in self.cubes:
            w, h, d = c.dims; x0, y0 = c.region
            rects = {"north": (x0 + d, y0 + d, x0 + d + w, y0 + d + h), "east": (x0, y0 + d, x0 + d, y0 + d + h), "south": (x0 + d + w + d, y0 + d, x0 + 2 * d + 2 * w, y0 + d + h),
                     "west": (x0 + d + w, y0 + d, x0 + d + w + d, y0 + d + h), "up": (x0 + d, y0, x0 + d + w, y0 + d), "down": (x0 + d + w, y0, x0 + d + 2 * w, y0 + d)}
            c.rects = rects
            for face, (ax, ay, bx, by) in rects.items(): self._face(atlas, ax, ay, bx, by, c.role, face, rng)
        return atlas

    def _face(self, atlas, x0, y0, x1, y1, role, face, rng):
        w, h = x1 - x0, y1 - y0
        if w <= 0 or h <= 0: return
        pal = self.pal.get(role, self.pal["body"])
        c1, c2 = (pal if isinstance(pal, tuple) else (pal * 0.72, pal))
        n = gaussian_filter(rng.random((h, w)), 0.8, mode="nearest"); n = (n - n.min()) / (np.ptp(n) + 1e-6)
        shade = {"up": 1.2, "down": 0.7, "north": 1.0, "south": 0.88, "east": 0.95, "west": 0.82}[face]
        img = (c1 + (c2 - c1) * n[..., None]) * shade
        ys, xs = np.mgrid[0:h, 0:w]
        if role in ("body", "shell", "armor", "fin") and self.pattern == "scales":
            m = (((xs + (ys // 2 % 2) * 2) % 4 == 0) | (ys % 4 == 0)); img[m] *= 0.82
        elif role in ("body", "shell", "armor") and self.pattern == "stripes":
            img[(xs // 2 % 3 == 0)] *= 0.78
        elif role in ("body", "shell", "armor") and self.pattern == "spots":
            sp = rng.random((h, w)) < 0.07; img[sp] = img[sp] * 0.5 + self.pal.get("accent", c2) * 0.5
        elif role in ("body", "shell", "armor") and self.pattern == "cracks":
            img[(rng.random((h, w)) < 0.05)] = self.pal.get("glow", c2)
        if role == "eye":
            img[:] = hexrgb("#05060a"); cx, cy = w // 2, h // 2; r = max(1, min(w, h) // 3)
            m = (xs - cx) ** 2 + (ys - cy) ** 2 <= r * r; img[m] = self.pal.get("glow", hexrgb("#ffffff"))
        elif role == "glow":
            g = self.pal.get("glow", c2); r = np.hypot(xs - w / 2, ys - h / 2) / (max(w, h) / 1.4 + 1e-6); img = g * (1.1 - 0.35 * np.clip(r, 0, 1))[..., None]
        elif role == "tooth":
            img = hexrgb("#e8e6d9") * (0.8 + 0.2 * (ys / max(1, h)))[..., None] * shade
        atlas[y0:y1, x0:x1, :3] = np.clip(img, 0, 255).astype(np.uint8); atlas[y0:y1, x0:x1, 3] = 255

    # -------------------------------------------------- export
    def build(self):
        W = self._pack(); atlas = self._paint(W)
        buf = io.BytesIO(); Image.fromarray(atlas, "RGBA").save(buf, "PNG")
        elements = []
        for c in self.cubes:
            faces = {}
            for fn in FACE_ORDER:
                ax, ay, bx, by = c.rects[fn]
                uv = [ax, by, bx, ay] if fn == "down" else [ax, ay, bx, by]
                faces[fn] = {"uv": [float(v) for v in uv], "texture": 0}
            elements.append({"name": c.name, "box_uv": False, "rescale": False, "locked": False, "light_emission": 15 if c.role in ("glow", "eye") else 0, "render_order": "default",
                             "allow_mirror_modeling": True, "from": c.f, "to": c.t, "autouv": 0, "color": 0, "origin": c.origin, "rotation": c.rot, "faces": faces, "type": "cube", "uuid": c.uuid})
        def outl(b):
            return {"name": b.name, "origin": b.origin, "rotation": b.rot, "color": 0, "uuid": b.uuid, "export": True, "mirror_uv": False, "isOpen": False, "locked": False,
                    "visibility": True, "autouv": 0, "children": [outl(ch) for ch in b.children] + [c.uuid for c in b.cubes]}
        anims = []
        for a in self.anims:
            animators = {}
            for bn, chans in a.keys.items():
                b = self.by_name[bn]; kfs = []
                for ch, lst in chans.items():
                    for t, (x, y, z), ip in sorted(lst, key=lambda e: e[0]):
                        kfs.append({"channel": ch, "data_points": [{"x": round(x, 4), "y": round(y, 4), "z": round(z, 4)}], "uuid": self.uid(), "time": round(t, 4), "color": -1, "interpolation": ip})
                animators[b.uuid] = {"name": bn, "type": "bone", "keyframes": kfs}
            anims.append({"uuid": self.uid(), "name": a.name, "loop": a.loop, "override": False, "length": round(a.length, 4), "snapping": 24, "selected": False,
                          "anim_time_update": "", "blend_weight": "", "start_delay": "", "loop_delay": "", "animators": animators})
        return {"meta": {"format_version": "4.10", "model_format": "free", "box_uv": False}, "name": self.id, "model_identifier": "", "visible_box": [1, 1, 0], "variable_placeholders": "",
                "bone_binding_expression": "", "resolution": {"width": W, "height": W}, "elements": elements, "outliner": [outl(b) for b in self.bones],
                "textures": [{"path": "", "name": f"{self.id}.png", "folder": "", "namespace": "", "id": "0", "particle": False, "render_mode": "default", "render_sides": "auto",
                              "frame_time": 1, "frame_order_type": "loop", "frame_order": "", "frame_interpolate": False, "visible": True, "mode": "bitmap", "saved": True,
                              "uuid": self.uid(), "relative_path": "", "source": "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()}],
                "animations": anims}

    def bounds(self):
        lo = [1e9] * 3; hi = [-1e9] * 3
        for c in self.cubes:
            for i in range(3): lo[i] = min(lo[i], c.f[i]); hi[i] = max(hi[i], c.t[i])
        return lo, hi

def _rot(p, o, r):
    x, y, z = (p[i] - o[i] for i in range(3)); rx, ry, rz = (math.radians(a) for a in r)
    y, z = y * math.cos(rx) - z * math.sin(rx), y * math.sin(rx) + z * math.cos(rx)
    x, z = x * math.cos(ry) + z * math.sin(ry), -x * math.sin(ry) + z * math.cos(ry)
    x, y = x * math.cos(rz) - y * math.sin(rz), x * math.sin(rz) + y * math.cos(rz)
    return (x + o[0], y + o[1], z + o[2])

def preview(m, size=300):
    """Side (looking along +X, head on the left) and top views of the rest pose, flat-shaded."""
    lo, hi = m.bounds(); ext = max(hi[i] - lo[i] for i in range(3)) or 1
    out = Image.new("RGB", (size * 2, size), (14, 18, 28))
    for view in (0, 1):
        im = Image.new("RGB", (size, size), (14, 18, 28)); dr = ImageDraw.Draw(im); polys = []
        sc = (size * 0.86) / ext
        for c in m.cubes:
            if c.role == "hitbox": continue
            pts = [(x, y, z) for x in (c.f[0], c.t[0]) for y in (c.f[1], c.t[1]) for z in (c.f[2], c.t[2])]
            pts = [_rot(p, c.origin, c.rot) for p in pts]
            col = m.pal.get(c.role, m.pal["body"]); col = col[1] if isinstance(col, tuple) else col
            idx = {"x": 0, "y": 1, "z": 2}
            for fa in ((0, 1, 3, 2), (4, 5, 7, 6), (0, 1, 5, 4), (2, 3, 7, 6), (0, 2, 6, 4), (1, 3, 7, 5)):
                q = [pts[i] for i in fa]; depth = sum(p[0] if view == 0 else p[1] for p in q) / 4
                if view == 0: xy = [(size * 0.07 + (p[2] - lo[2]) * sc, size * 0.93 - (p[1] - lo[1]) * sc) for p in q]
                else: xy = [(size * 0.07 + (p[2] - lo[2]) * sc, size * 0.93 - (p[0] - lo[0]) * sc) for p in q]
                polys.append((depth, xy, tuple(int(v) for v in np.clip(col * (0.7 + 0.3 * (fa[0] % 3) / 2), 0, 255))))
        for _, xy, col in sorted(polys, key=lambda p: p[0]): dr.polygon(xy, fill=col)
        out.paste(im, (view * size, 0))
    return out
