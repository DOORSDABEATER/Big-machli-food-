"""Levi, the Sovereign Beneath: bespoke ModelEngine model + complete animation library, timed from bosses/levi.yml.
Conventions (Blockbench animation): +X rotation tips the FRONT (-Z) DOWN, so 'up' is negative X. If your ModelEngine build renders the
opposite, flip SIGN_X / SIGN_Y below and regenerate. Positions are in model pixels (16 px = 1 block)."""
import math, os, sys
import yaml
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bbm import Model

SIGN_X, SIGN_Y = 1.0, 1.0
N = 20
SEG = [f"seg{i}" for i in range(N)]
PALETTE = {"body": ("#040b13", "#0d2c3d"), "belly": ("#0b3a4a", "#1d7284"), "fin": ("#052b3a", "#0f6079"), "armor": ("#08192a", "#1f4c68"),
           "accent": "#cfd8dc", "bone": ("#b9c4c8", "#eef3f4"), "tooth": "#e8e6d9", "glow": "#22e7ff", "eye": "#03121a", "shell": "#08192a", "cloth": "#08192a", "hitbox": "#08192a"}

def _box(m, bone, cx, cy, cz, sx, sy, sz, role="body", rot=(0, 0, 0), origin=None):
    return m.cube(bone, (cx - sx / 2, cy - sy / 2, cz - sz / 2), (cx + sx / 2, cy + sy / 2, cz + sz / 2), role, rot, origin)

def build_model():
    m = Model("levi", PALETTE, uv_scale=2.0, seed=2026, pattern="scales"); m.bone("root")
    W = [36, 40, 44, 46, 46, 45, 44, 42, 40, 38, 36, 33, 30, 27, 24, 21, 17, 14, 11, 8]
    SL = 24
    for i in range(N):
        n = SEG[i]; z0 = i * SL; zc = z0 + SL / 2; w = W[i]; h = w * 0.95
        m.bone(n, SEG[i - 1] if i else "root", (0, 0, z0))
        if i in (3, 4):                                                  # chest cavity that holds the core
            _box(m, n, 0, -h * 0.14, zc, w, h * 0.72, SL + 0.6, "body")
            for sx in (1, -1): _box(m, n, sx * (w / 2 - (w / 2 - 7) / 2), h * 0.2, zc, w / 2 - 7, h * 0.36, SL + 0.6, "armor")
            _box(m, n, 0, -h * 0.35, zc, w * 0.9, h * 0.25, SL + 0.6, "belly")
        else:
            _box(m, n, 0, 0, zc, w, h, SL + 0.6, "body")
            _box(m, n, 0, h * 0.5 - h * 0.08, zc, w * 0.72, h * 0.2, SL + 0.2, "armor")                 # dorsal armour plate
            _box(m, n, 0, -h * 0.5 + h * 0.13, zc, w * 0.9, h * 0.28, SL + 0.7, "belly")                # ventral plates
        if i < N - 2:
            m.bone(f"spine{i}", n, (0, h / 2, zc))                                                      # spine on its own small bone
            _box(m, f"spine{i}", 0, h / 2 + 3.5 + w * 0.06, zc + 2, 2.4, 6 + w * 0.14, 5, "bone", (-22, 0, 0))
        if i % 2 == 1 and i < N - 3:
            for sx in (1, -1):
                _box(m, n, sx * (w / 2 + 0.2), h * 0.08, zc, 0.9, 2.0, SL * 0.7, "glow")                # flank markings
                _box(m, n, sx * (w / 2 + 0.2), -h * 0.12, zc, 0.9, 1.1, SL * 0.45, "glow")
        if i % 3 == 0 and i > 0 and i < N - 3:
            _box(m, n, 0, h / 2 + 0.2, zc, 5, 0.9, 5, "glow", (0, 45, 0))                              # dorsal runes
        if 1 <= i <= 2:
            for sx in (1, -1):
                for k in range(3): _box(m, n, sx * (w / 2 + 0.25), h * 0.12 - k * 4.2, zc + 3, 0.8, 1.6, 8, "glow")   # gills
        if 6 <= i <= 14:                                                                                # dorsal sail with struts (own bone per segment)
            sh = (20 - abs(i - 10) * 2.4); sn = f"sail{i}"
            m.bone(sn, n, (0, h / 2 + 8, zc))
            _box(m, sn, 0, h / 2 + 9 + sh / 2, zc, 1.2, sh, SL - 1, "fin")
            _box(m, sn, 0, h / 2 + 9 + sh / 2, zc, 1.6, sh + 1, 1.8, "bone")
    # ---- chest core + covering plates
    m.bone("core", "seg3", (0, 8, 3 * SL + SL)); 
    for k, (s, r) in enumerate(((11, (0, 45, 0)), (9, (45, 0, 45)), (6, (0, 0, 0)))): _box(m, "core", 0, 11, 3 * SL + SL, s, s, s, "glow", r)
    for i in (3, 4):
        zc = i * SL + SL / 2; h = W[i] * 0.95
        for side, sx in (("l", 1), ("r", -1)):
            m.bone(f"plate_{side}{i}", SEG[i], (sx * 8.5, h * 0.38, zc))
            _box(m, f"plate_{side}{i}", sx * 4, h * 0.38 + 1.6, zc, 10, 3.4, SL - 0.6, "armor")
            _box(m, f"plate_{side}{i}", sx * 8.5, h * 0.38 + 2.6, zc, 1.8, 3, SL - 2, "bone")
    # ---- pectoral and ventral fins
    for side, sx in (("l", 1), ("r", -1)):
        m.bone(f"fin_{side}", "seg2", (sx * 22, -8, 2 * SL + 12))
        _box(m, f"fin_{side}", sx * 36, -10, 2 * SL + 14, 28, 1.8, 20, "fin", (0, sx * -18, sx * -10))
        _box(m, f"fin_{side}", sx * 30, -9, 2 * SL + 10, 18, 2.6, 3, "bone", (0, sx * -18, sx * -10))
        m.bone(f"fin2_{side}", "seg10", (sx * 15, -14, 10 * SL + 12)); _box(m, f"fin2_{side}", sx * 24, -15, 10 * SL + 14, 16, 1.4, 14, "fin", (0, sx * -22, sx * -14))
    # ---- tail fluke
    m.bone("fluke", SEG[N - 1], (0, 0, N * SL))
    for sx in (1, -1): _box(m, "fluke", sx * 11, 0, N * SL + 8, 22, 2.4, 14, "fin", (0, sx * -16, 0)); _box(m, "fluke", sx * 6, 0, N * SL + 6, 12, 3, 3, "bone", (0, sx * -16, 0))
    _box(m, "fluke", 0, 0, N * SL + 6, 6, 5, 12, "armor"); _box(m, "fluke", 0, 0, N * SL + 16, 3, 3, 8, "glow")
    # ---- head
    m.bone("head", "seg0", (0, 0, 0))
    _box(m, "head", 0, 3, -19, 38, 34, 36, "body"); _box(m, "head", 0, 18, -17, 30, 6, 30, "armor"); _box(m, "head", 0, 21, -20, 12, 4, 26, "bone")
    for sx in (1, -1): _box(m, "head", sx * 17, 9, -18, 7, 8, 26, "armor", (0, sx * 6, 0)); _box(m, "head", sx * 20, 4, -10, 2.4, 20, 18, "armor")
    m.bone("snout", "head", (0, 1, -36))
    _box(m, "snout", 0, 1, -46, 30, 22, 24, "body"); _box(m, "snout", 0, 0, -61, 24, 17, 12, "body"); _box(m, "snout", 0, 9, -52, 24, 4, 22, "armor")
    for sx in (1, -1): _box(m, "snout", sx * 5, 4, -67.4, 3, 3, 1.4, "armor")                               # nostrils
    for side, sx in (("l", 1), ("r", -1)):
        m.bone(f"eye_{side}", "head", (sx * 19.4, 9, -22))
        _box(m, f"eye_{side}", sx * 19.4, 9, -22, 3, 13, 13, "glow"); _box(m, f"eye_{side}", sx * 20.6, 9, -22, 2.4, 8, 8, "eye")
    # upper fangs
    for k in range(6):
        for sx in (1, -1): _box(m, "head" if k == 0 else "snout", sx * 13.5, -8.5, -30 - k * 6.4, 2.6, 8 + (k % 2) * 3, 2.6, "tooth", (0, 0, sx * 5))
    for sx in (1, -1): _box(m, "snout", sx * 6, -9, -67, 3.6, 14, 3.6, "tooth", (-8, 0, 0))
    # maw glow, jaw, tongue
    m.bone("maw_glow", "head", (0, -7, -34)); _box(m, "maw_glow", 0, -6.5, -36, 24, 4, 34, "glow")
    m.bone("jaw", "head", (0, -10, -6))
    _box(m, "jaw", 0, -17, -26, 32, 9, 40, "belly"); _box(m, "jaw", 0, -19.5, -24, 28, 3, 36, "armor"); _box(m, "jaw", 0, -13.5, -28, 16, 3, 28, "glow")
    for k in range(6):
        for sx in (1, -1): _box(m, "jaw", sx * 12.5, -9, -22 - k * 5.4, 2.4, 8 + ((k + 1) % 2) * 3, 2.4, "tooth", (0, 0, sx * -5))
    for sx in (1, -1): _box(m, "jaw", sx * 5, -9, -47, 3.6, 13, 3.6, "tooth", (8, 0, 0))
    # crown of bone: centre spike, left and right spike banks, and two swept horns (separate bones keep every bone small)
    m.bone("crown", "head", (0, 19, -8))
    _box(m, "crown", 0, 34, -6, 5.4, 32, 5.4, "bone", (-10, 0, 0)); _box(m, "crown", 0, 52, -10, 2.4, 6, 2.4, "glow", (-10, 0, 0))
    for side, sx in (("l", 1), ("r", -1)):
        m.bone(f"crown_{side}", "head", (sx * 12, 19, -8))
        for k, (x, hh, tz) in enumerate(((8, 26, 14), (14, 22, 24), (19, 18, 34), (23, 14, 44))):
            _box(m, f"crown_{side}", sx * x, 21 + hh / 2, -6 + k * 1.6, 4, hh, 4, "bone", (8, 0, sx * -tz))
            _box(m, f"crown_{side}", sx * (x + math.sin(math.radians(tz)) * hh * 0.5), 21 + hh - 1, -6 + k * 1.6, 2, 3, 2, "glow", (8, 0, sx * -tz))
        m.bone(f"horn_{side}", "head", (sx * 20, 8, 4))
        for k in range(3):
            _box(m, f"horn_{side}", sx * (21 + k * 6), 8 + k * 3, 4 + k * 9, 6 - k * 1.4, 6 - k * 1.4, 12, "bone", (-10 - k * 14, sx * (20 + k * 12), 0))
    # barbels
    for side, sx in (("l", 1), ("r", -1)):
        prev = "jaw"
        for j in range(4):
            n = f"barb_{side}{j}"; y0 = -22 - j * 6; m.bone(n, prev, (sx * 11, y0 + 3, -44)); _box(m, n, sx * 11, y0 - 0.5, -44, 2.6 - j * 0.4, 6.5, 2.6 - j * 0.4, "fin" if j % 2 else "bone"); prev = n
        _box(m, f"barb_{side}3", sx * 11, -47.5, -44, 2.4, 2.4, 2.4, "glow")
    # hitbox
    m.bone("hitbox", "root", (0, 0, 0)); _box(m, "hitbox", 0, 0, 20, 46, 46, 120, "hitbox")
    return m

# ================================================================== animation framework
class Pose:
    def __init__(self): self.d = {}
    def rot(self, b, x=0.0, y=0.0, z=0.0):
        v = self.d.setdefault((b, "rotation"), [0.0, 0.0, 0.0]); v[0] += x * SIGN_X; v[1] += y * SIGN_Y; v[2] += z
    def pos(self, b, x=0.0, y=0.0, z=0.0):
        v = self.d.setdefault((b, "position"), [0.0, 0.0, 0.0]); v[0] += x; v[1] += y; v[2] += z
    def scl(self, b, x=1.0, y=1.0, z=1.0):
        v = self.d.setdefault((b, "scale"), [1.0, 1.0, 1.0]); v[0] *= x; v[1] *= y; v[2] *= z

def sm(t, a, b):
    if b <= a: return 1.0 if t >= a else 0.0
    x = min(1.0, max(0.0, (t - a) / (b - a))); return x * x * (3 - 2 * x)
def trap(t, a, b, c, d): return sm(t, a, b) * (1 - sm(t, c, d))
def kp(t, pts):
    """smooth interpolation through (time, value) keypoints"""
    if t <= pts[0][0]: return pts[0][1]
    for (t0, v0), (t1, v1) in zip(pts, pts[1:]):
        if t <= t1: return v0 + (v1 - v0) * sm(t, t0, t1)
    return pts[-1][1]
TAU = 2 * math.pi
def S(t, per, ph=0.0): return math.sin(TAU * t / per - ph)

def wave(p, t, amp, per, step, axis="y", segs=range(N), gain=None, env=1.0):
    for i in segs:
        v = amp * env * S(t, per, i * step) * (gain(i) if gain else 1.0)
        p.rot(SEG[i], **{axis: v})
def pitch(p, total, segs):
    segs = list(segs)
    for i in segs: p.rot(SEG[i], x=total / len(segs))
def coil(p, per_seg, segs):
    for i in segs: p.rot(SEG[i], y=per_seg)
def jaw(p, d): p.rot("jaw", x=d); p.rot("snout", x=-d * 0.12)
def eyes(p, s): p.scl("eye_l", s, s, s); p.scl("eye_r", s, s, s)
CROWN = ("crown", "crown_l", "crown_r")
def crown(p, s):
    for b in CROWN: p.scl(b, s, s, s)
def crown_rot(p, x=0.0, flare=0.0):
    p.rot("crown", x=x); p.rot("crown_l", x=x, z=flare); p.rot("crown_r", x=x, z=-flare)
def sail(p, t, amp, per, step=0.3):
    for i in range(6, 15): p.rot(f"sail{i}", x=amp * S(t, per, i * step))
def fins(p, a): p.rot("fin_l", z=a); p.rot("fin_r", z=-a); p.rot("fin2_l", z=a * 0.8); p.rot("fin2_r", z=-a * 0.8)
def barbels(p, t, lean, sway=4.0, per=3.0):
    for side, sg in (("l", 1), ("r", -1)):
        for j in range(4): p.rot(f"barb_{side}{j}", x=lean + sway * S(t, per, j * 0.6), z=sg * sway * 0.7 * S(t, per, j * 0.6 + 1))
def plates(p, open_deg):
    for i in (3, 4): p.rot(f"plate_l{i}", z=open_deg); p.rot(f"plate_r{i}", z=-open_deg)
def shake(p, t, amp, per=0.28, segs=range(0, 14)): wave(p, t, amp, per, 0.25, "y", segs)

ANIMS = {}   # name -> (length, loop, fn, extra times)
def anim(name, length, loop="once", extra=()):
    def deco(fn): ANIMS[name] = (length, loop, fn, extra); return fn
    return deco

# ---------------------------------------------------------------- locomotion / presence
@anim("idle", 6.0, "loop")
def _(t):
    p = Pose(); wave(p, t, 2.4, 6, 0.35, "y"); wave(p, t, 1.0, 6, 0.22, "x"); jaw(p, 3 + 2 * S(t, 6)); eyes(p, 1 + 0.1 * S(t, 3)); fins(p, 6 * S(t, 3)); barbels(p, t, 6, 3, 3)
    p.rot("head", y=3 * S(t, 6, 0.8)); sail(p, t, 3, 6); p.scl("maw_glow", 1, 1 + 0.15 * S(t, 3), 1); p.scl("core", 1 + 0.06 * S(t, 3), 1 + 0.06 * S(t, 3), 1 + 0.06 * S(t, 3)); return p
@anim("swim", 4.0, "loop")
def _(t):
    p = Pose(); wave(p, t, 5.6, 4, 0.45, "y"); wave(p, t, 1.6, 4, 0.3, "x"); p.rot("head", y=-4 * S(t, 4, 0.6)); jaw(p, 4); eyes(p, 1.05); fins(p, 16 * S(t, 2)); barbels(p, t, 26, 5, 2); sail(p, t, 7, 4); return p
@anim("swim_fast", 2.0, "loop")
def _(t):
    p = Pose(); wave(p, t, 8.5, 2, 0.5, "y"); wave(p, t, 2.2, 2, 0.35, "x"); jaw(p, 6); eyes(p, 1.15); fins(p, 30 + 6 * S(t, 1)); barbels(p, t, 45, 4, 1); sail(p, t, -10, 2); return p
@anim("vulnerable", 3.0, "loop")
def _(t):
    p = Pose(); wave(p, t, 1.4, 3, 0.3, "y"); pitch(p, 12, range(0, 6)); p.rot("head", x=8); jaw(p, 14 + 4 * S(t, 3)); eyes(p, 0.8 + 0.1 * S(t, 1.5)); fins(p, -8); barbels(p, t, 12, 2, 3); plates(p, 75); return p
@anim("hurt", 0.7, "once")
def _(t):
    p = Pose(); d = math.exp(-5 * t); wave(p, t, 7 * d, 0.35, 0.4, "y", range(0, 12)); p.rot("head", y=-9 * d, x=6 * d); eyes(p, 1 + 0.25 * d); return p

# ---------------------------------------------------------------- emergence and voice
@anim("emerge", 10.0, "once", (0.2, 1.5, 3.0, 7.0, 8.5))
def _(t):
    p = Pose(); rise = sm(t, 3.0, 8.5)
    p.pos("root", y=-380 * (1 - rise) ** 1.4); p.rot("root", x=-75 * (1 - sm(t, 3.5, 9.0)) - 8 * sm(t, 3.5, 9.0))
    wave(p, t, 9 * sm(t, 2, 5) * (1 - sm(t, 8.6, 10)), 3.0, 0.5, "y"); wave(p, t, 3 * sm(t, 2, 5) * (1 - sm(t, 8.6, 10)), 3.0, 0.4, "x")
    e = 0.01 + 1.4 * sm(t, 0.2, 1.5); eyes(p, e + 0.15 * S(t, 1.5) * sm(t, 1.5, 2)); crown(p, 1 + 0.25 * trap(t, 7, 8.5, 9, 10))
    jaw(p, 45 * sm(t, 7.5, 8.8) * (1 - sm(t, 9.3, 10)) + 4); fins(p, 20 * (1 - sm(t, 6, 9))); barbels(p, t, 40 * (1 - sm(t, 6, 9)), 4, 2); p.rot("head", x=-10 * sm(t, 8, 9)); return p
@anim("intro", 5.0, "once", (3.2, 3.8, 4.6))
def _(t):
    p = Pose(); e = trap(t, 3.2, 3.8, 4.6, 5.0); p.rot("head", y=24 * S(t, 4) * (1 - sm(t, 3.0, 3.6)), x=-14 * e); jaw(p, 4 + 40 * e); eyes(p, 1.1 + 0.3 * e + 0.1 * S(t, 1)); wave(p, t, 2.5, 5, 0.35, "y"); pitch(p, -18 * e, range(0, 6)); crown(p, 1 + 0.12 * e); fins(p, 8 * S(t, 2.5)); barbels(p, t, 10, 3, 3); return p
@anim("roar", 3.2, "once", (0.8, 1.2, 2.2))
def _(t):
    p = Pose(); e = trap(t, 0.3, 1.0, 2.4, 3.1); pitch(p, -28 * e, range(0, 7)); p.rot("head", x=-12 * e); jaw(p, 4 + 46 * trap(t, 0.8, 1.2, 2.2, 2.9)); shake(p, t, 2.6 * e); eyes(p, 1 + 0.35 * e); crown(p, 1 + 0.12 * e); fins(p, 14 * e); p.scl("maw_glow", 1, 1 + 0.5 * e, 1); barbels(p, t, -20 * e, 4, 0.5); return p
@anim("enrage", 3.4, "once", (0.9, 2.4))
def _(t):
    p = Pose(); e = trap(t, 0.2, 0.9, 2.4, 3.2); pitch(p, -40 * e, range(0, 8)); p.rot("head", x=-14 * e); jaw(p, 4 + 55 * trap(t, 0.7, 1.1, 2.3, 3.0)); shake(p, t, 6 * e, 0.22); eyes(p, 1 + 1.0 * e + 0.15 * S(t, 0.3)); crown(p, 1 + 0.4 * e); plates(p, 10 * e * S(t, 0.2)); fins(p, 22 * e); return p

# ---------------------------------------------------------------- phase transitions
@anim("phase_change_1", 3.5, "once", (1.2, 2.8))     # Hunter
def _(t):
    p = Pose(); e = trap(t, 0.3, 1.2, 2.8, 3.4); coil(p, 6 * e, range(2, 18)); pitch(p, -22 * e, range(0, 5)); p.rot("head", x=-14 * e); jaw(p, 4 + 38 * trap(t, 0.9, 1.4, 2.2, 3.0)); eyes(p, 1 + 0.5 * e); crown(p, 1 + 0.15 * e); shake(p, t, 2 * e); fins(p, 16 * e); return p
@anim("phase_change_2", 4.5, "once", (2.5, 2.7, 3.3))   # Sovereign
def _(t):
    p = Pose(); e = trap(t, 0.4, 1.6, 3.4, 4.3); pitch(p, -55 * e, range(0, 11)); p.rot("head", x=-16 * e); jaw(p, 4 + 50 * trap(t, 1.4, 1.9, 3.0, 3.9)); crown(p, 1 + 0.3 * e)
    crown_rot(p, flare=12 * e * S(t, 0.4))
    pulse = trap(t, 2.5, 2.7, 2.8, 3.3); p.scl("root", 1 + 0.08 * pulse, 1 + 0.08 * pulse, 1 + 0.08 * pulse); eyes(p, 1 + 0.6 * e); shake(p, t, 3 * e); fins(p, 24 * e); return p
@anim("phase_change_3", 5.0, "once", (1.0, 3.8))        # Catastrophe
def _(t):
    p = Pose(); e = trap(t, 0.2, 1.0, 4.0, 4.9); wave(p, t, 18 * e, 0.9, 0.5, "y"); wave(p, t, 8 * e, 0.9, 0.4, "x"); p.rot("head", y=15 * S(t, 0.5) * e, x=-8 * e)
    plates(p, 8 * e * S(t, 0.35)); eyes(p, 1 + 0.55 * e); jaw(p, 4 + 40 * trap(t, 2.8, 3.2, 4.2, 4.8)); crown(p, 1 + 0.2 * e); fins(p, 30 * e * S(t, 0.6)); barbels(p, t, -30 * e, 8, 0.5); return p
@anim("phase_change_4", 5.0, "once", (1.5, 3.8))        # Last Tide
def _(t):
    p = Pose(); e = trap(t, 0.2, 1.4, 3.5, 4.9); p.scl("root", 1, 1, 1 - 0.06 * e); coil(p, 4 * e, range(1, 19)); wave(p, t, 10 * (1 - sm(t, 0.2, 2.2)) * sm(t, 0, 0.3), 0.7, 0.5, "y")
    plates(p, 12 * (1 - sm(t, 1.8, 2.4)) * S(t, 0.2)); pitch(p, -26 * trap(t, 3.4, 3.9, 4.6, 5.0), range(0, 6)); p.rot("head", x=-22 * trap(t, 3.4, 3.9, 4.6, 5.0)); jaw(p, 4 + 56 * trap(t, 3.5, 3.9, 4.4, 4.9)); eyes(p, 1 + 0.7 * e); crown(p, 1 + 0.25 * e); shake(p, t, 3 * trap(t, 3.5, 3.9, 4.6, 5.0)); return p

# ---------------------------------------------------------------- core window
@anim("core_open", 1.6, "hold")
def _(t):
    p = Pose(); o = sm(t, 0.0, 1.0); plates(p, 78 * o); c = 1 + 0.3 * o + 0.1 * S(t, 0.4) * o
    p.scl("core", c, c, c); eyes(p, 0.85); jaw(p, 10 * o); p.rot("head", x=6 * o); return p
@anim("core_close", 1.2, "once")
def _(t):
    p = Pose(); o = 1 - sm(t, 0.0, 1.0); plates(p, 78 * o); c = 1 + 0.3 * o; p.scl("core", c, c, c); return p

# ---------------------------------------------------------------- attacks (timings come from bosses/levi.yml)
@anim("abyssal_gaze", 6.6, "once", (2.0, 5.5))
def _(t):
    p = Pose()
    if t <= 2.0: yaw = -50 * sm(t, 0.2, 1.8)
    elif t <= 5.5: yaw = -50 + 100 * (t - 2.0) / 3.5
    else: yaw = 50 * (1 - sm(t, 5.5, 6.5))
    w = sm(t, 0.2, 1.8) * (1 - sm(t, 5.5, 6.5)); p.rot("head", y=yaw); coil(p, yaw * 0.04, range(0, 4)); eyes(p, 1 + 0.9 * w + 0.15 * S(t, 0.5) * w); jaw(p, 4 + 6 * w); crown(p, 1 + 0.12 * w)
    wave(p, t, 1.6, 4, 0.3, "y", range(4, N)); fins(p, 10 * w); p.scl("maw_glow", 1, 1 + 0.6 * w, 1); return p
@anim("undertow", 5.0, "once", (4.2, 4.6))
def _(t):
    p = Pose(); e = trap(t, 0.3, 1.0, 4.2, 4.62); jaw(p, 4 + 42 * e); pulse = 0.5 + 0.5 * S(t, 0.8)
    for i in range(1, 5): p.scl(SEG[i], 1 + 0.1 * e * pulse, 1 + 0.1 * e * pulse, 1)
    fins(p, -30 * e); barbels(p, t, -40 * e, 3, 0.8); p.rot("head", x=-8 * e); eyes(p, 1 + 0.3 * e); p.scl("maw_glow", 1, 1 + 0.9 * e, 1); wave(p, t, 2 * (1 - e), 4, 0.3, "y"); return p
@anim("crushing_wake", 4.4, "once", (1.8, 2.0))
def _(t):
    p = Pose(); cy = 9 * sm(t, 0.2, 1.7) * (1 - sm(t, 1.8, 3.4)); coil(p, cy, range(5, N))
    tp = -25 * sm(t, 0.2, 1.7) if t < 1.8 else (-25 + 60 * sm(t, 1.8, 2.0) if t < 2.0 else 35 * (1 - sm(t, 2.0, 3.6))); pitch(p, tp, range(10, N))
    p.rot("head", y=22 * cy / 9, x=6 * sm(t, 0.2, 1.7) * (1 - sm(t, 2, 3))); p.pos("root", z=-6 * sm(t, 1.8, 2.0) * (1 - sm(t, 2.0, 3.0))); eyes(p, 1 + 0.4 * sm(t, 0.2, 1.7) * (1 - sm(t, 2, 3))); shake(p, t, 4 * trap(t, 1.8, 2.0, 2.2, 3.0), 0.3); return p
@anim("devouring_charge", 5.4, "once", (2.0, 3.9))
def _(t):
    p = Pose(); c = sm(t, 0.2, 1.9) * (1 - sm(t, 2.0, 2.2)); L = sm(t, 2.0, 2.3) * (1 - sm(t, 3.9, 5.1))
    for i in range(N): p.rot(SEG[i], y=14 * c * math.sin(i * 0.7))
    wave(p, t, 7.5 * L, 0.5, 0.5, "y"); p.rot("head", x=-10 * c); jaw(p, 4 + 30 * sm(t, 1.4, 1.9) * (1 - sm(t, 2.0, 2.2)) + 52 * L); fins(p, -12 * c + 38 * L); eyes(p, 1 + 0.5 * c + 0.4 * L); barbels(p, t, 50 * L, 3, 0.5); p.scl("maw_glow", 1, 1 + 0.7 * L, 1); return p
@anim("abyssal_coil", 7.8, "once", (1.5, 6.5, 6.8))
def _(t):
    p = Pose(); c = sm(t, 0.2, 1.5) * (1 - sm(t, 6.8, 7.6)); hold = sm(t, 1.5, 2.0) * (1 - sm(t, 6.4, 6.6))
    coil(p, 14 * c, range(3, 15)); pitch(p, 10 * c, range(0, 3)); p.rot("head", x=20 * c); jaw(p, 4 + 12 * c)
    sq = 1 - 0.05 * S(t, 1.2) * hold - 0.12 * trap(t, 6.3, 6.5, 6.8, 7.2)
    for i in range(3, 15): p.scl(SEG[i], sq, sq, 1)
    eyes(p, 1 + 0.4 * c); crown(p, 1 + 0.1 * c); barbels(p, t, 20 * c, 3, 1); return p
@anim("depth_breaker", 3.9, "once", (2.2, 2.4))
def _(t):
    p = Pose(); tot = -55 * sm(t, 0.2, 2.0) if t < 2.2 else (-55 + 105 * sm(t, 2.2, 2.4) if t < 2.4 else 50 * (1 - sm(t, 2.4, 3.6)))
    pitch(p, tot, range(0, 7)); p.rot("head", x=-10 * sm(t, 0.2, 2.0) * (t < 2.3)); jaw(p, 4 + 30 * sm(t, 1.0, 2.0) * (1 - sm(t, 2.2, 2.45)))
    p.pos("root", y=14 * sm(t, 0.2, 2.0) * (1 - sm(t, 2.2, 2.4)) - 10 * trap(t, 2.2, 2.4, 2.6, 3.2)); shake(p, t, 6 * trap(t, 2.4, 2.5, 2.6, 3.6), 0.3); eyes(p, 1 + 0.6 * sm(t, 0.2, 2.0) * (1 - sm(t, 2.4, 3))); crown(p, 1 + 0.15 * sm(t, 0.2, 2.0)); return p
_TC = [(0, 0), (2.0, -45), (2.2, -45), (2.4, 40), (3.4, 10), (4.6, 0), (5.7, -35), (5.9, -35), (6.1, 40), (7.2, 10), (8.6, 0)]
@anim("tidal_collapse", 8.8, "once", (2.2, 2.4, 5.9, 6.1))
def _(t):
    p = Pose(); v = kp(t, _TC); pitch(p, v, range(0, 10)); crown(p, 1 + 0.25 * max(0, -v) / 45); jaw(p, 4 + 30 * max(0, -v) / 45)
    p.pos("root", y=12 * max(0, -v) / 45 - 8 * max(0, v) / 40); eyes(p, 1 + 0.5 * max(0, -v) / 45); shake(p, t, 5 * (trap(t, 2.4, 2.5, 2.6, 3.4) + trap(t, 6.1, 6.2, 6.3, 7.2)), 0.3); fins(p, 20 * max(0, -v) / 45); return p
@anim("black_current", 5.4, "once")
def _(t):
    p = Pose(); e = trap(t, 0.3, 1.0, 4.6, 5.2); wave(p, t, 18 * e, 1.6, 0.5, "y"); wave(p, t, 6 * e, 1.6, 0.4, "x"); fins(p, 30 * e * S(t, 0.8)); p.rot("head", y=10 * S(t, 1.6) * e); barbels(p, t, -35 * e, 6, 0.8); jaw(p, 4 + 8 * e); eyes(p, 1 + 0.25 * e); return p
@anim("call_of_the_deep", 3.4, "once", (1.5,))
def _(t):
    p = Pose(); u = sm(t, 0.2, 1.5) * (1 - sm(t, 2.4, 3.2)); pitch(p, -30 * u, range(0, 6)); p.rot("head", x=-20 * u); jaw(p, 4 + 40 * trap(t, 0.8, 1.4, 2.4, 3.0)); crown(p, 1 + 0.3 * u)
    p.scl("maw_glow", 1, 1 + 0.5 * u + 0.4 * u * S(t, 0.4), 1); eyes(p, 1 + 0.5 * u); fins(p, 14 * u); shake(p, t, 1.5 * u, 0.3); return p
@anim("abyssal_roar", 3.8, "once", (1.7,))
def _(t):
    p = Pose(); e = trap(t, 0.2, 1.0, 2.6, 3.5); pitch(p, -32 * e, range(0, 7)); p.rot("head", x=-14 * e); jaw(p, 4 + 55 * trap(t, 1.2, 1.7, 2.4, 3.0)); shake(p, t, 4 * e, 0.25); eyes(p, 1 + 0.5 * e); crown(p, 1 + 0.18 * e); fins(p, 20 * e); p.scl("maw_glow", 1, 1 + 0.7 * e, 1); return p
@anim("worldbreaker", 8.8, "once", (4.8, 5.0, 5.3))
def _(t):
    p = Pose(); c = sm(t, 0.3, 4.8) * (1 - sm(t, 5.0, 5.3)); coil(p, 20 * c, range(2, 19))
    tot = -70 * c if t < 5.0 else (-70 + 130 * sm(t, 5.0, 5.25) if t < 5.3 else 60 * (1 - sm(t, 5.3, 8.4)))
    pitch(p, tot, range(0, 5)); p.pos("root", y=30 * c - 35 * trap(t, 5.0, 5.25, 5.5, 6.5)); eyes(p, 1 + 1.0 * c + 0.15 * S(t, 0.35) * c); crown(p, 1 + 0.35 * c); jaw(p, 4 + 36 * c)
    plates(p, 6 * c * S(t, 0.3)); fins(p, 28 * c); shake(p, t, 8 * trap(t, 5.0, 5.2, 5.6, 7.5), 0.3); p.scl("maw_glow", 1, 1 + 1.2 * c, 1); return p
@anim("devouring_depths", 6.2, "once", (4.35, 4.5))
def _(t):
    p = Pose(); e = trap(t, 0.3, 1.2, 4.35, 4.5); jaw(p, 4 + 58 * e); pulse = 0.5 + 0.5 * S(t, 0.7)
    for i in range(1, 6): p.scl(SEG[i], 1 + 0.12 * e * pulse, 1 + 0.12 * e * pulse, 1)
    p.scl("maw_glow", 1, 1 + 1.0 * e * (0.7 + 0.3 * S(t, 0.4)), 1); p.rot("head", x=-10 * e); barbels(p, t, -45 * e, 3, 0.7); p.pos("root", z=-22 * trap(t, 4.35, 4.5, 4.7, 5.6)); eyes(p, 1 + 0.3 * e); fins(p, -25 * e)
    shake(p, t, 4 * trap(t, 4.5, 4.6, 4.8, 5.8), 0.3); return p
@anim("leviathans_wrath", 8.6, "once", (1.8, 7.3))
def _(t):
    p = Pose(); arch = sm(t, 0.2, 1.6) * (1 - sm(t, 7.3, 8.4))
    yaw = -180 * sm(t, 0.2, 1.8) if t < 1.8 else (-180 + 360 * (t - 1.8) / 5.5 if t < 7.3 else 180 + 180 * sm(t, 7.3, 8.5))
    p.rot("root", y=yaw); pitch(p, -35 * arch, range(0, 7)); p.rot("head", x=-12 * arch); jaw(p, 4 + 20 * arch); eyes(p, 1 + 0.8 * arch + 0.1 * S(t, 0.4)); crown(p, 1 + 0.3 * arch)
    wave(p, t, 4, 1.5, 0.35, "y", range(7, N)); fins(p, 14 * arch); p.scl("maw_glow", 1, 1 + 0.9 * arch, 1); barbels(p, t, -20 * arch, 5, 0.7); return p
@anim("rupture", 3.9, "once", (2.0, 2.2))
def _(t):
    p = Pose(); c = sm(t, 0.2, 2.0) * (1 - sm(t, 2.2, 2.6)); pitch(p, -20 * c, range(8, N)); pitch(p, 10 * c, range(0, 4)); p.rot("head", x=10 * c)
    b = sm(t, 2.2, 2.4) * (1 - sm(t, 2.4, 3.6)); wave(p, t, 28 * b, 0.6, 0.6, "y"); jaw(p, 4 + 25 * trap(t, 2.1, 2.3, 2.6, 3.0)); eyes(p, 1 + 0.5 * c); fins(p, 20 * b); return p
@anim("final_descent", 5.0, "once", (2.5, 2.75))
def _(t):
    p = Pose(); up = sm(t, 0.2, 2.3)
    ry = -80 * up if t < 2.5 else (-80 + 155 * sm(t, 2.5, 2.75) if t < 2.8 else 75 * (1 - sm(t, 2.8, 4.8)))
    py = 48 * up if t < 2.5 else (48 - 108 * sm(t, 2.5, 2.75) if t < 2.8 else -60 * (1 - sm(t, 2.8, 4.8)))
    p.rot("root", x=ry); p.pos("root", y=py); eyes(p, 1 + 0.8 * up * (1 - sm(t, 2.6, 3.2))); jaw(p, 4 + 40 * trap(t, 2.2, 2.6, 2.9, 3.4)); crown(p, 1 + 0.25 * up); wave(p, t, 4 * sm(t, 0.2, 2) * (1 - sm(t, 2.5, 2.7)), 0.8, 0.4, "y")
    shake(p, t, 7 * trap(t, 2.75, 2.9, 3.0, 4.2), 0.3); fins(p, 30 * up * (1 - sm(t, 2.6, 2.9))); return p
@anim("sovereigns_maw", 5.4, "once", (3.4, 3.6))
def _(t):
    p = Pose(); e = trap(t, 0.3, 1.0, 3.4, 3.58); jaw(p, 4 + 62 * e); wave(p, t, 8 * e, 0.5, 0.4, "y"); pulse = 0.5 + 0.5 * S(t, 0.5)
    for i in range(1, 6): p.scl(SEG[i], 1 + 0.14 * e * pulse, 1 + 0.14 * e * pulse, 1)
    p.scl("maw_glow", 1, 1 + 1.3 * e, 1); p.pos("root", z=-26 * trap(t, 3.4, 3.55, 3.8, 4.8)); p.rot("head", x=-12 * e); eyes(p, 1 + 0.5 * e); barbels(p, t, -50 * e, 4, 0.5); shake(p, t, 5 * trap(t, 3.5, 3.6, 3.9, 5.0), 0.3); return p
_LC = [(0, 0), (2.8, -50), (3.0, -50), (3.2, 45), (4.4, 12), (4.8, 0), (6.0, -45), (6.4, -45), (6.6, 45), (7.8, 12), (8.2, 0), (9.4, -45), (9.8, -45), (10.0, 45), (11.4, 10), (12.4, 0)]
@anim("last_cataclysm", 12.6, "once", (3.0, 3.2, 6.4, 6.6, 9.8, 10.0))
def _(t):
    p = Pose(); v = kp(t, _LC); up = max(0, -v) / 50; pitch(p, v, range(0, 12)); p.pos("root", y=16 * up - 10 * max(0, v) / 45); crown(p, 1 + 0.4 * up); eyes(p, 1 + 0.9 * up); jaw(p, 4 + 40 * up)
    plates(p, 10 * up * S(t, 0.3)); fins(p, 28 * up); shake(p, t, 7 * (trap(t, 3.2, 3.3, 3.4, 4.4) + trap(t, 6.6, 6.7, 6.8, 7.8) + trap(t, 10.0, 10.1, 10.2, 11.4)), 0.28); p.scl("maw_glow", 1, 1 + 0.8 * up, 1); return p

# ---------------------------------------------------------------- defeat
@anim("death", 12.0, "hold", (2.2, 4.0))
def _(t):
    p = Pose(); thr = (1 - sm(t, 1.4, 2.4)); slump = sm(t, 2.0, 5.0)
    wave(p, t, 14 * thr, 0.8, 0.5, "y"); wave(p, t, 4 * (1 - sm(t, 2.5, 8)), 3, 0.3, "x"); pitch(p, 36 * slump, range(0, 9)); p.rot("head", x=26 * slump, y=8 * S(t, 2) * (1 - sm(t, 3, 6)))
    jaw(p, 4 + 52 * sm(t, 2.4, 4.0)); eyes(p, max(0.01, 1 + 0.5 * thr - sm(t, 4.0, 7.0))); crown(p, 1 - 0.1 * sm(t, 3, 6)); crown_rot(p, x=20 * sm(t, 3, 6)); fins(p, 40 * (1 - sm(t, 2, 5)) - 20 * sm(t, 2, 5))
    barbels(p, t, 15 * slump, 2, 3); p.scl("maw_glow", 1, max(0.05, 1 - sm(t, 3.5, 7)), 1); p.scl("core", *( [max(0.05, 1 - sm(t, 3, 8))] * 3 )); plates(p, 60 * sm(t, 2.5, 4.0))
    p.pos("root", y=-420 * sm(t, 4, 12) ** 1.6); p.rot("root", z=20 * sm(t, 3, 9)); return p

# ================================================================== export
def apply_anims(m, dt=0.2):
    for name, (length, loop, fn, extra) in ANIMS.items():
        times = sorted({round(i * dt, 4) for i in range(int(length / dt) + 1)} | {round(length, 4)} | {round(e + d, 4) for e in extra for d in (-0.1, 0.0, 0.1) if 0 < e + d < length})
        samples = {}; keys = set()
        for t in times:
            pose = fn(t)
            samples[t] = pose.d; keys |= set(pose.d)
        a = m.anim(name, length, loop)
        for (bone, ch) in keys:
            base = 1.0 if ch == "scale" else 0.0
            vals = [samples[t].get((bone, ch), [base] * 3) for t in times]
            if all(abs(c - base) < 1e-3 for v in vals for c in v): continue
            for t, v in zip(times, vals): a.k(bone, ch, t, *[round(c, 3) for c in v], interp="catmullrom" if loop != "once" or name in ("emerge", "intro", "roar") else "catmullrom")
    return m

def spawn_model():
    """Small abyssal spawn summoned by Call of the Deep (a short serpent with its own idle/swim/attack/death)."""
    import arche as A
    pal = A.P(("#050e18", "#0e3042"), ("#0b3a4a", "#1d7284"), "#073447", "#cfd8dc", "#22e7ff", bone="#dfe6e8")
    m = A.serpent("levi_abyssal_spawn", pal, segs=7, seglen=8, w=(7, 10, 3), h=(7, 10, 3), head_len=12, crown=3, fins=0, spikes=True, jaw_open_teeth=4, uv=1.0, seed=77)
    ch = m.meta["chain"]
    def add(name, length, loop, fn):
        times = [round(i * 0.1, 3) for i in range(int(length / 0.1) + 1)]; a = m.anim(name, length, loop)
        for t in times:
            for bone, (x, y, z) in fn(t).items(): a.k(bone, "rotation", t, x, y, z)
    add("idle", 2.0, "loop", lambda t: {c: (0, 2.5 * math.sin(TAU * t / 2 - i * 0.5), 0) for i, c in enumerate(ch)} | {"jaw": (3 + 2 * math.sin(TAU * t / 2), 0, 0)})
    add("swim", 1.0, "loop", lambda t: {c: (0, 9 * math.sin(TAU * t - i * 0.7), 0) for i, c in enumerate(ch)} | {"jaw": (4, 0, 0)})
    add("walk", 1.0, "loop", lambda t: {c: (0, 9 * math.sin(TAU * t - i * 0.7), 0) for i, c in enumerate(ch)} | {"jaw": (4, 0, 0)})
    add("attack", 0.8, "once", lambda t: {"head": (-14 * sm(t, 0, .25) * (1 - sm(t, .35, .8)), 0, 0), "jaw": (50 * trap(t, .15, .3, .4, .6), 0, 0), "seg0": (0, 0, 0)})
    add("death", 1.6, "hold", lambda t: {c: (0, 16 * math.sin(TAU * t * 2 - i * 0.6) * (1 - sm(t, 0.2, 1.2)), 25 * sm(t, 0.3, 1.4)) for i, c in enumerate(ch)} | {"jaw": (45 * sm(t, 0.2, 0.6), 0, 0)})
    return m

if __name__ == "__main__":
    import json, bbm
    ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    out = os.path.join(ROOT, "modelengine", "blueprints"); os.makedirs(out, exist_ok=True)
    m = apply_anims(build_model())
    d = m.build(); json.dump(d, open(os.path.join(out, "levi.bbmodel"), "w"), separators=(",", ":"))
    s = spawn_model(); json.dump(s.build(), open(os.path.join(out, "levi_abyssal_spawn.bbmodel"), "w"), separators=(",", ":"))
    bbm.preview(m, 520).save("/tmp/levi_preview.png")
    lo, hi = m.bounds()
    print("levi: cubes", len(m.cubes), "bones", len(m.by_name), "tex", d["resolution"]["width"], "extent px", [round(hi[i] - lo[i]) for i in range(3)], "animations", len(m.anims))
    print("keyframes:", sum(len(v) for a in d["animations"] for an in a["animators"].values() for v in [an["keyframes"]]))
    print("file KB:", os.path.getsize(os.path.join(out, "levi.bbmodel")) // 1024)
