#!/usr/bin/env python3
"""Structural check of generated .bbmodel files (what ModelEngine will parse) plus a per-bone size report."""
import json, sys, glob, os, math
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
bad = []; report = []
for f in sorted(glob.glob(os.path.join(ROOT, "modelengine", "blueprints", "*.bbmodel"))):
    d = json.load(open(f)); name = os.path.basename(f)
    W = d["resolution"]["width"]; H = d["resolution"]["height"]
    els = {e["uuid"]: e for e in d["elements"]}; seen = set(); bones = {}
    if len(els) != len(d["elements"]): bad.append(f"{name}: duplicate element uuids")
    def walk(b, parent):
        if b["uuid"] in bones: bad.append(f"{name}: duplicate bone uuid {b['name']}")
        bones[b["uuid"]] = b
        for c in b["children"]:
            if isinstance(c, str):
                if c not in els: bad.append(f"{name}: bone {b['name']} references missing cube {c}")
                if c in seen: bad.append(f"{name}: cube {c} listed in two bones")
                seen.add(c)
            else: walk(c, b)
    for b in d["outliner"]: walk(b, None)
    if seen != set(els): bad.append(f"{name}: {len(set(els) - seen)} cubes not in any bone")
    names = [b["name"] for b in bones.values()]
    if len(names) != len(set(names)): bad.append(f"{name}: duplicate bone names")
    for e in d["elements"]:
        for fn, fc in e["faces"].items():
            u = fc["uv"]
            if not all(0 <= v <= W for v in (u[0], u[2])) or not all(0 <= v <= H for v in (u[1], u[3])): bad.append(f"{name}: uv out of atlas on {e['name']}")
        for v in e["from"] + e["to"] + e["origin"]:
            if not math.isfinite(v): bad.append(f"{name}: non-finite coordinate in {e['name']}")
    if len(d["textures"]) != 1 or not d["textures"][0]["source"].startswith("data:image/png;base64,"): bad.append(f"{name}: texture not embedded")
    nk = 0
    for a in d["animations"]:
        if a["loop"] not in ("loop", "once", "hold"): bad.append(f"{name}: bad loop mode in {a['name']}")
        for uid, an in a["animators"].items():
            if uid not in bones: bad.append(f"{name}: animation {a['name']} animates an unknown bone")
            for k in an["keyframes"]:
                nk += 1
                if k["time"] < 0 or k["time"] > a["length"] + 1e-6: bad.append(f"{name}: key outside {a['name']} length")
                if k["channel"] not in ("rotation", "position", "scale"): bad.append(f"{name}: bad channel")
                if not all(math.isfinite(v) for v in k["data_points"][0].values()): bad.append(f"{name}: NaN keyframe in {a['name']}")
    # per-bone extent from its own cubes
    big = []
    for b in bones.values():
        cs = [els[c] for c in b["children"] if isinstance(c, str)]
        if not cs: continue
        ext = max(max(abs(c["from"][i] - b["origin"][i]) for c in cs) if True else 0 for i in range(3)) if False else 0
        lo = [min(c["from"][i] for c in cs) for i in range(3)]; hi = [max(c["to"][i] for c in cs) for i in range(3)]
        span = max(hi[i] - lo[i] for i in range(3)); reach = max(max(abs(lo[i] - b["origin"][i]), abs(hi[i] - b["origin"][i])) for i in range(3))
        if span > 48 or reach > 48: big.append((b["name"], round(span), round(reach)))
    report.append(f"{name}: {len(d['elements'])} cubes, {len(bones)} bones, {len(d['animations'])} animations, {nk} keyframes, atlas {W}px, "
                  f"{len(big)} bones larger than 48 px" + (f" (largest: {sorted(big, key=lambda x: -x[1])[:4]})" if big else ""))
print("\n".join(report)); print("problems:", len(bad))
for b in bad[:20]: print("  -", b)
sys.exit(1 if bad else 0)
