#!/usr/bin/env python3
"""Checks the generated resourcepack/ against everything the plugin references. Exit code 1 on any problem."""
import json, os, re, sys, yaml, glob
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RP = os.path.join(ROOT, "resourcepack", "assets", "des_sea")
bad = []
def need(path, why):
    if not os.path.exists(path): bad.append(f"missing {os.path.relpath(path, ROOT)}  ({why})")

# 1. every json parses
for p in glob.glob(os.path.join(ROOT, "resourcepack", "**", "*.json"), recursive=True) + glob.glob(os.path.join(ROOT, "datapack", "**", "*.json"), recursive=True):
    try: json.load(open(p))
    except Exception as e: bad.append(f"bad json {p}: {e}")

# 2. item definitions -> models -> textures
for p in glob.glob(os.path.join(RP, "items", "**", "*.json"), recursive=True):
    m = json.load(open(p))["model"]["model"]
    if m.startswith("des_sea:"): need(os.path.join(RP, "models", m.split(":")[1] + ".json"), f"item def {os.path.relpath(p, RP)}")
for p in glob.glob(os.path.join(RP, "models", "**", "*.json"), recursive=True):
    m = json.load(open(p))
    par = m.get("parent", "")
    if par.startswith("des_sea:"): need(os.path.join(RP, "models", par.split(":")[1] + ".json"), "parent of " + os.path.relpath(p, RP))
    for k, v in m.get("textures", {}).items():
        if v.startswith("des_sea:"): need(os.path.join(RP, "textures", v.split(":")[1] + ".png"), f"texture of {os.path.relpath(p, RP)}")

# 3. sounds.json -> files
sj = json.load(open(os.path.join(RP, "sounds.json")))
for ev, d in sj.items():
    for s in d["sounds"]: need(os.path.join(RP, "sounds", s["name"].split(":")[1] + ".ogg"), f"sound event {ev}")

# 4. what the Java code and configs reference
java = "".join(open(f).read() for f in glob.glob(os.path.join(ROOT, "src/main/java/**/*.java"), recursive=True))
cfg = yaml.safe_load(open(os.path.join(ROOT, "src/main/resources/config.yml")))
vehicles = ["motorboat", "jet_boat", "racing_jet_boat", "mini_submarine", "deep_sea_submersible", "ghost_vessel"]
bosses = [yaml.safe_load(open(f)) for f in glob.glob(os.path.join(ROOT, "src/main/resources/bosses/*.yml"))]
for v in vehicles:
    need(os.path.join(RP, "items", "item", f"vehicle_{v}.json"), "vehicle item"); need(os.path.join(RP, "items", "vehicle", f"{v}.json"), "vehicle model")
    if f"vehicle.{v}.engine" not in sj: bad.append(f"no sound event vehicle.{v}.engine")
for sid in set(re.findall(r'"des_sea:([a-z_.]+)"', java)):
    if sid.startswith(("ambient.", "event.")) and sid not in sj: bad.append(f"code plays missing sound des_sea:{sid}")
for n in range(1, 10):
    if f"levi.awaken.step{n}" not in sj: bad.append(f"no levi.awaken.step{n}")
for b in bosses:
    for key in ["intro", "defeat", "enrage", "window", "shelter"] + [f"phase{i + 1}" for i in range(len(b["phases"]))] + [f"{a}.{s}" for a in b["attacks"] for s in ("windup", "strike")]:
        if f"boss.{b['id']}.{key}" not in sj: bad.append(f"no sound event boss.{b['id']}.{key}")
    for part in ("node", "shelter", "shelter_active"): need(os.path.join(RP, "items", "boss", f"{b['id']}_{part}.json"), "boss part")
    for ph in b["phases"]:
        for a in ph["attacks"]:
            if a["use"] not in b["attacks"]: bad.append(f"boss {b['id']} phase uses undefined attack {a['use']}")
for it in cfg["items"].values(): need(os.path.join(RP, "items", "item", it["model"] + ".json"), "config item")
for c in ["biome", "creature", "boss_encountered", "boss_defeated", "structure", "blueprint", "recipe", "artifact", "fishing", "secret", "location"]:
    need(os.path.join(RP, "items", "ui", f"entry_{c}.json"), "journal"); need(os.path.join(RP, "items", "ui", f"tab_{c}.json"), "journal")
for n in ("entry_unknown", "prev", "next"): need(os.path.join(RP, "items", "ui", n + ".json"), "journal")
need(os.path.join(RP, "items", "event", "levi_shadow.json"), "levi shadow")
blocks = yaml.safe_load(open(os.path.join(ROOT, "src/main/resources/blocks.yml")))["blocks"]
for b in blocks: need(os.path.join(RP, "items", "block", b + ".json"), "block item"); need(os.path.join(RP, "textures", "block", b + ".png"), "block texture")
for b in ["crystal_depths", "black_trench", "verdant_reef", "volcanic_expanse", "forgotten_waters", "frozen_abyss", "drowned_kingdom", "luminous_wilds"]:
    need(os.path.join(ROOT, "datapack", "data", "des_sea", "worldgen", "biome", b + ".json"), "biome")
# terrain populator block ids must exist
for bid in set(re.findall(r'"([a-z_]+)"', open(os.path.join(ROOT, "src/main/java/com/des/sea/terrain/TerrainPopulator.java")).read())):
    pass
terr = open(os.path.join(ROOT, "src/main/java/com/des/sea/terrain/TerrainPopulator.java")).read()
used = set(re.findall(r'(?:put|plant)\([^;]*?"([a-z_]+)"', terr)) | set(re.findall(r'new String\[\]\{([^}]*)\}', terr) and re.findall(r'"([a-z_]+)"', " ".join(re.findall(r'new String\[\]\{([^}]*)\}', terr))))
for u in sorted(used):
    if "_" in u and u not in blocks and u not in BIOMES if (BIOMES := ["crystal_depths", "black_trench", "verdant_reef", "volcanic_expanse", "forgotten_waters", "frozen_abyss", "drowned_kingdom", "luminous_wilds"]) else False:
        bad.append(f"terrain uses unknown block id '{u}'")
print("problems:", len(bad))
for b in bad[:40]: print("  -", b)
sys.exit(1 if bad else 0)
