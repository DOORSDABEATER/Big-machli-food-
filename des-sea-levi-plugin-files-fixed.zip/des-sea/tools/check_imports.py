#!/usr/bin/env python3
"""Offline sanity check: every Bukkit/Paper/Adventure class used in the Java sources has a matching import (the JDK compiler cannot check this without the Paper jar)."""
import re, glob, os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PKG = {"Player":"org.bukkit.entity","Entity":"org.bukkit.entity","LivingEntity":"org.bukkit.entity","ItemDisplay":"org.bukkit.entity","ArmorStand":"org.bukkit.entity","Interaction":"org.bukkit.entity","Projectile":"org.bukkit.entity","Shulker":"org.bukkit.entity","WaterMob":"org.bukkit.entity","Display":"org.bukkit.entity",
 "Location":"org.bukkit","World":"org.bukkit","Chunk":"org.bukkit","Material":"org.bukkit","NamespacedKey":"org.bukkit","Particle":"org.bukkit","Color":"org.bukkit","OfflinePlayer":"org.bukkit","Keyed":"org.bukkit","Registry":"org.bukkit","HeightMap":"org.bukkit","Bukkit":"org.bukkit","SoundCategory":"org.bukkit","GameMode":"org.bukkit","FluidCollisionMode":"org.bukkit","Input":"org.bukkit",
 "ConfigurationSection":"org.bukkit.configuration","YamlConfiguration":"org.bukkit.configuration.file","CommandSender":"org.bukkit.command","Command":"org.bukkit.command","CommandExecutor":"org.bukkit.command","TabCompleter":"org.bukkit.command","PluginCommand":"org.bukkit.command",
 "ItemStack":"org.bukkit.inventory","ItemMeta":"org.bukkit.inventory.meta","Inventory":"org.bukkit.inventory","InventoryHolder":"org.bukkit.inventory","ShapelessRecipe":"org.bukkit.inventory","EquipmentSlot":"org.bukkit.inventory",
 "EventHandler":"org.bukkit.event","Listener":"org.bukkit.event","HandlerList":"org.bukkit.event","EventPriority":"org.bukkit.event","Event":"org.bukkit.event","BukkitTask":"org.bukkit.scheduler",
 "Block":"org.bukkit.block","BlockFace":"org.bukkit.block","BlockState":"org.bukkit.block","Biome":"org.bukkit.block","BlockData":"org.bukkit.block.data","Light":"org.bukkit.block.data.type","Waterlogged":"org.bukkit.block.data","Container":"org.bukkit.block",
 "PotionEffect":"org.bukkit.potion","PotionEffectType":"org.bukkit.potion","Vector":"org.bukkit.util","Transformation":"org.bukkit.util","RayTraceResult":"org.bukkit.util",
 "PlayerJoinEvent":"org.bukkit.event.player","PlayerInteractEvent":"org.bukkit.event.player","PlayerFishEvent":"org.bukkit.event.player","PlayerInteractEntityEvent":"org.bukkit.event.player","PlayerInteractAtEntityEvent":"org.bukkit.event.player","PlayerArmorStandManipulateEvent":"org.bukkit.event.player","PlayerTeleportEvent":"org.bukkit.event.player",
 "EntityDeathEvent":"org.bukkit.event.entity","EntityDamageByEntityEvent":"org.bukkit.event.entity","EntityDamageEvent":"org.bukkit.event.entity","PrepareItemCraftEvent":"org.bukkit.event.inventory","InventoryDragEvent":"org.bukkit.event.inventory","InventoryClickEvent":"org.bukkit.event.inventory",
 "ChunkLoadEvent":"org.bukkit.event.world","BlockPlaceEvent":"org.bukkit.event.block","BlockPhysicsEvent":"org.bukkit.event.block","BlockFadeEvent":"org.bukkit.event.block","BlockBreakEvent":"org.bukkit.event.block","Action":"org.bukkit.event.block",
 "Lootable":"org.bukkit.loot","LootTable":"org.bukkit.loot","Plugin":"org.bukkit.plugin","JavaPlugin":"org.bukkit.plugin.java","BossBar":"net.kyori.adventure.bossbar","Component":"net.kyori.adventure.text","Vector3f":"org.joml","AxisAngle4f":"org.joml","Attribute":"org.bukkit.attribute","Title":"net.kyori.adventure.title",
 "NamedTextColor":"net.kyori.adventure.text.format","TextDecoration":"net.kyori.adventure.text.format","TextColor":"net.kyori.adventure.text.format","PersistentDataType":"org.bukkit.persistence"}
bad = 0
for f in sorted(glob.glob(os.path.join(ROOT, "src/main/java/**/*.java"), recursive=True)):
    src = open(f).read(); body = re.sub(r'/\*.*?\*/', '', src, flags=re.S); body = re.sub(r'"(?:\\.|[^"\\])*"', '""', body); body = re.sub(r'//.*', '', body)
    imports = re.findall(r'^import\s+([\w.*]+);', src, re.M)
    for name, p in PKG.items():
        if not re.search(r'(?<![\w.])' + name + r'\b', body) or re.search(re.escape(p) + r'\.' + name + r'\b', body): continue
        if any(i in (f"{p}.{name}", f"{p}.*") for i in imports): continue
        print(f"{os.path.basename(f)}: uses {name} without importing {p}"); bad += 1
print("import problems:", bad); sys.exit(1 if bad else 0)
