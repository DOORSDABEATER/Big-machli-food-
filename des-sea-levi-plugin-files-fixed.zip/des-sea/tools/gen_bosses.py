#!/usr/bin/env python3
"""Authoring source for every boss. Run: python3 tools/gen_bosses.py
Writes src/main/resources/bosses/<id>.yml, BOSSES.md (design doc) and BOSS_AUDIO.md (sound checklist).
Needs PyYAML for dumping (pip install pyyaml)."""
import yaml, os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "src/main/resources/bosses")
os.makedirs(OUT, exist_ok=True)

def A(type, **kw):
    d = {"type": type}
    d.update({k.replace("_", "-"): v for k, v in kw.items()})
    return d

def use(name, w=1):
    return {"use": name, "weight": w}

def phase(name, until, movement, interval, attacks, mechanics=None, announce=None, **kw):
    p = {"name": name, "until": until, "movement": movement, "interval": interval, "attacks": attacks}
    if mechanics: p["mechanics"] = mechanics
    if announce: p["announce"] = announce
    p.update({k.replace("_", "-"): v for k, v in kw.items()})
    return p

def nodes(label, count, radius, health, around="arena", shield=True, respawn=False, window=0, mult=1.0, yoff=0, msg=None):
    return {"type": "nodes", "label": label, "count": count, "radius": radius, "health": health, "around": around,
            "shield": shield, "respawn": respawn, "window": window, "window-mult": mult, "y-offset": yoff, **({"clear-message": msg} if msg else {})}

def shelters(label, count, radius, duration, protect, yoff=0):
    return {"type": "shelters", "label": label, "count": count, "radius": radius, "duration": duration, "protect-radius": protect, "y-offset": yoff}

BOSSES = {}
DOC = {}

# ------------------------------------------------------------------ LEVI (established concept preserved)
BOSSES["levi"] = {
    "id": "levi", "name": "Levi, the Sovereign Beneath", "color": "#22d3ee", "accent": "SOUL_FIRE_FLAME", "bar-color": "BLUE",
    "base-health": 4500, "speed": 0.55, "enrage-seconds": 1080, "arena-radius": 100,
    "model": "levi", "model-scale": 2.5, "emerge-ticks": 200, "window-anim": "core_open", "window-end-anim": "core_close",
    "intro": "The water goes still.", "defeat": "The deep exhales. Something vast sinks away.",
    "attacks": {
        "abyssal_gaze": A("beam", telegraph=40, duration=70, range=70, width=3.0, damage=8, sweep=100, interval=6),
        "undertow": A("pull", duration=80, radius=34, strength=0.07, damage=6, inner=5),
        "crushing_wake": A("shockwave", telegraph=36, speed=0.9, max_radius=44, height=3.5, thickness=3.0, damage=14),
        "devouring_charge": A("charge", telegraph=40, distance=46, speed=1.3, width=6.0, damage=22),
        "abyssal_coil": A("grab", telegraph=30, count=2, hold=100, dps=3, crush=16, **{"break": 90}, pull=True),
        "depth_breaker": A("slam", telegraph=44, radius=13, damage=24, center="target", knockback=1.4),
        "tidal_collapse": A("shockwave", telegraph=44, speed=1.0, max_radius=50, height=4, thickness=3.5, damage=18, rings=2, ring_gap=24),
        "black_current": A("current", duration=100, radius=45, strength=0.14, damage=3),
        "call_of_the_deep": A("summon", telegraph=30, mob="levi_abyssal_spawn", count=4, radius=20),
        "abyssal_roar": A("roar", telegraph=34, radius=30, damage=12, knockback=1.8, slow=50),
        "worldbreaker": A("slam", telegraph=100, radius=38, damage=14, center="self", lethal=True, sheltered_damage=6, knockback=2.0),
        "devouring_depths": A("pull", duration=90, radius=42, strength=0.10, damage=8, inner=6, finisher=True, lethal=True, sheltered_damage=8),
        "leviathans_wrath": A("beam", telegraph=36, duration=110, range=80, width=3.5, damage=11, sweep=360, interval=5),
        "rupture": A("rupture", telegraph=44, lines=7, length=60, width=3.5, damage=18),
        "final_descent": A("slam", telegraph=50, radius=17, damage=38, center="target", knockback=2.2),
        "sovereigns_maw": A("pull", duration=70, radius=36, strength=0.12, damage=10, inner=6, finisher=True),
        "last_cataclysm": A("shockwave", telegraph=60, speed=1.1, max_radius=55, height=4.5, thickness=3.5, damage=30, rings=3, ring_gap=18),
    },
    "phases": [
        phase("Watcher", 0.80, "orbit", 90, [use("abyssal_gaze", 3), use("undertow", 2), use("crushing_wake", 2)], orbit_radius=38, transition=100,
              announce=None),
        phase("Hunter", 0.60, "chase", 70, [use("devouring_charge", 3), use("abyssal_coil", 2), use("depth_breaker", 3)],
              announce="He has stopped watching.", transition=70),
        phase("Sovereign", 0.35, "orbit", 75, [use("tidal_collapse", 3), use("black_current", 2), use("call_of_the_deep", 2), use("abyssal_roar", 2)],
              mechanics=[nodes("Abyssal Node", 3, 28, 220, msg="The nodes shatter. The Sovereign's hide is open.")], orbit_radius=30,
              announce="The sea itself kneels.", transition=90),
        phase("Catastrophe", 0.10, "hover", 60, [use("worldbreaker", 2), use("devouring_depths", 2), use("leviathans_wrath", 3), use("rupture", 2)],
              mechanics=[shelters("Tidebound Shelter", 4, 22, 170, 4.5)], announce="Find shelter. Nothing else will save you.", transition=100),
        phase("Last Tide", 0.0, "hover", 50, [use("final_descent", 3), use("sovereigns_maw", 2), use("last_cataclysm", 2)],
              mechanics=[nodes("Core Plate", 4, 11, 260, around="boss", respawn=True, window=200, mult=2.5, msg="The core is bare. Strike now.")],
              announce="The last tide has come.", transition=100),
    ],
}
DOC["levi"] = ("LEVI, THE SOVEREIGN BENEATH", "Legendary (ritual-summoned). Concept, five phases, attack names, nodes/structures/core rules and rewards are exactly as established; the numbers and how each named attack plays are the new design.",
  ["Watcher (100-80%): orbits at range. Gaze = slow cyan beam sweep (break line of sight); Undertow = vortex at his maw; Crushing Wake = low shockwave from the tail (swim above/below it).",
   "Hunter (80-60%): chases. Devouring Charge = long telegraphed dash; Abyssal Coil = constricts two divers (damage him to break free); Depth Breaker = overhead slam on a marked circle.",
   "Sovereign (60-35%): untouchable until 3 Abyssal Nodes are destroyed. Tidal Collapse = double shockwave; Black Current = arena-wide push; Call of the Deep = spawn adds; Abyssal Roar = knockback + slow.",
   "Catastrophe (35-10%): Tidebound Shelters must be right-clicked to activate (they time out). Worldbreaker / Devouring Depths are lethal outside an active shelter. Leviathan's Wrath = 360 degree beam; Rupture = floor lines.",
   "Last Tide (10-0%): Core Plates shield him. Breaking all four exposes the core for a 10 second x2.5 damage window, then they regrow. Final Descent, Sovereign's Maw (pull, lethal near the mouth), Last Cataclysm (3 shockwave rings)."])

# ------------------------------------------------------------------ KRAK'THOR
BOSSES["krakthor"] = {
    "id": "krakthor", "name": "Krak'thor, the World Devourer", "color": "#9f1239", "accent": "SQUID_INK", "bar-color": "RED",
    "base-health": 4000, "speed": 0.0, "enrage-seconds": 900, "arena-radius": 90,
    "intro": "The wrecks groan as something beneath them stirs.", "defeat": "Every tentacle goes slack at once.",
    "attacks": {
        "tentacle_slam": A("slam", telegraph=30, radius=6, damage=15, center="target", knockback=1.2),
        "tentacle_sweep": A("cone", telegraph=34, range=26, angle=110, damage=13),
        "ink_cloud": A("darkness", telegraph=20, duration=180, radius=34),
        "tentacle_grab": A("grab", telegraph=32, count=2, hold=130, dps=3, crush=20, **{"break": 130}, pull=True),
        "crushing_coil": A("slam", telegraph=42, radius=11, damage=22, center="self", knockback=1.6),
        "maelstrom": A("pull", duration=100, radius=38, strength=0.09, damage=8, inner=6),
        "wreck_rain": A("rupture", telegraph=40, lines=9, length=48, width=3.0, damage=17),
        "abyssal_whirlpool": A("pull", duration=90, radius=44, strength=0.12, damage=10, inner=7, finisher=True, lethal=True, sheltered_damage=8),
        "devouring_surge": A("shockwave", telegraph=44, speed=1.0, max_radius=48, height=4, thickness=3.5, damage=20, rings=2, ring_gap=22),
    },
    "phases": [
        phase("Lurker", 0.70, "static", 80, [use("tentacle_slam", 3), use("tentacle_sweep", 3), use("ink_cloud", 1)],
              mechanics=[nodes("Tentacle", 6, 22, 130, shield=False)], announce=None),
        phase("Devourer", 0.35, "static", 65, [use("tentacle_grab", 3), use("crushing_coil", 2), use("maelstrom", 2), use("tentacle_slam", 2)],
              mechanics=[nodes("Tentacle", 6, 22, 170, respawn=True, window=170, mult=2.0, msg="The tentacles are severed. The body is open.")],
              announce="He is done playing."),
        phase("World Devourer", 0.0, "static", 50, [use("abyssal_whirlpool", 2), use("wreck_rain", 3), use("devouring_surge", 2), use("tentacle_grab", 2)],
              mechanics=[shelters("Hull Fragment", 3, 24, 150, 5.5)], announce="The graveyard begins to fall."),
    ],
}
DOC["krakthor"] = ("KRAK'THOR, THE WORLD DEVOURER", "Ship Graveyard. Six independent, killable tentacles; the body is only vulnerable after they are cut.",
  ["Lurker (100-70%): tentacles slam and sweep. They are separate targets: cut them down to thin his attacks. Ink Cloud blinds the arena.",
   "Devourer (70-35%): body is shielded. Tentacle Grab pins and drags two players to the maw (damage him to free them). Cutting all six tentacles opens a 8.5s x2 window, then they regrow.",
   "World Devourer (35-0%): Hull Fragments (wreck cover, right-click to brace) are the only protection from Abyssal Whirlpool's lethal core. Wreck Rain drops debris lines; Devouring Surge sends rings."])

# ------------------------------------------------------------------ THAL'ZAR
BOSSES["thalzar"] = {
    "id": "thalzar", "name": "Thal'zar, the Drowned King", "color": "#eab308", "accent": "SOUL", "bar-color": "YELLOW",
    "base-health": 4200, "speed": 0.6, "enrage-seconds": 960, "arena-radius": 70,
    "intro": "You stand in my court uninvited.", "defeat": "The crown falls. The court is silent at last.",
    "attacks": {
        "royal_decree": A("cone", telegraph=24, range=15, angle=120, damage=16),
        "tidal_prison": A("slam", telegraph=36, radius=5, damage=10, center="target", slow=80),
        "summon_guards": A("summon", telegraph=30, mob="thalzar_guard", count=3, radius=14),
        "flood_surge": A("current", duration=90, radius=42, strength=0.13, damage=4),
        "crown_wave": A("slam", telegraph=84, radius=30, damage=14, center="self", lethal=True, sheltered_damage=5, knockback=1.8),
        "sovereigns_edict": A("beam", telegraph=36, duration=80, range=42, width=3.0, damage=12, sweep=140, interval=6),
        "drowning_court": A("pull", duration=90, radius=32, strength=0.10, damage=9, inner=5, finisher=True),
        "throne_cracks": A("rupture", telegraph=40, lines=6, length=34, width=3.0, damage=17),
    },
    "phases": [
        phase("The Court", 0.65, "chase", 80, [use("royal_decree", 3), use("tidal_prison", 3), use("summon_guards", 2)], announce="Kneel, or be drowned."),
        phase("Wrath of the Tides", 0.30, "chase", 65, [use("royal_decree", 2), use("flood_surge", 2), use("crown_wave", 2), use("summon_guards", 1)],
              mechanics=[shelters("Tide Pillar", 4, 16, 150, 4.0)], announce="The sea answers its king."),
        phase("The Last Royal", 0.0, "chase", 55, [use("sovereigns_edict", 3), use("drowning_court", 2), use("tidal_prison", 2), use("throne_cracks", 2)],
              mechanics=[nodes("Crown Shard", 3, 12, 200, around="boss", respawn=True, window=180, mult=2.2, msg="The crown cracks. The king is exposed.")],
              announce="I will not be forgotten!"),
    ],
}
DOC["thalzar"] = ("THAL'ZAR, THE DROWNED KING", "Drowned Kingdom throne room. A duelist-king with a guard court and spoken voice lines at every stage.",
  ["The Court (100-65%): fights up close. Royal Decree (scepter cone), Tidal Prison (slows a marked circle), calls guards.",
   "Wrath of the Tides (65-30%): Tide Pillars must be right-clicked to activate; Crown Wave is lethal outside one. Flood Surge shoves everyone.",
   "The Last Royal (30-0%): three Crown Shards shield him; breaking them opens a x2.2 window, then they re-form. Edict beam, Drowning Court vortex, cracking floor."])

# ------------------------------------------------------------------ NYXARA
BOSSES["nyxara"] = {
    "id": "nyxara", "name": "Nyxara, the Lightless Mother", "color": "#312e81", "accent": "LARGE_SMOKE", "bar-color": "PURPLE",
    "base-health": 3800, "speed": 0.5, "enrage-seconds": 960, "arena-radius": 80,
    "intro": "The light leaves first.", "defeat": "Darkness folds inward and is gone.",
    "attacks": {
        "darkness_veil": A("darkness", telegraph=20, duration=220, radius=42),
        "shadow_spawn": A("summon", telegraph=28, mob="nyxara_shadow", count=3, radius=16),
        "gaze_of_nothing": A("beam", telegraph=34, duration=70, range=50, width=2.5, damage=10, sweep=100, interval=6),
        "corrupted_call": A("summon", telegraph=30, mob="nyxara_corrupted", count=4, radius=20),
        "void_embrace": A("pull", duration=80, radius=34, strength=0.10, damage=8, inner=5, finisher=True),
        "eclipse": A("slam", telegraph=90, radius=32, damage=14, center="self", lethal=True, sheltered_damage=5, knockback=1.6),
        "distortion": A("current", duration=90, radius=40, strength=0.12, damage=3),
        "mothers_wail": A("roar", telegraph=30, radius=28, damage=11, knockback=1.6, slow=60),
    },
    "phases": [
        phase("Veil", 0.70, "hover", 80, [use("darkness_veil", 2), use("shadow_spawn", 2), use("gaze_of_nothing", 3)],
              mechanics=[shelters("Lantern", 4, 18, 220, 5.5)], announce="Do you remember what the dark is for?"),
        phase("Mother of Mirrors", 0.35, "hover", 65, [use("corrupted_call", 2), use("void_embrace", 2), use("gaze_of_nothing", 2), use("eclipse", 2)],
              mechanics=[nodes("Shadow Anchor", 3, 24, 150, msg="The anchors break. She is real again."), shelters("Lantern", 4, 18, 220, 5.5)],
              announce="Which of us is real?"),
        phase("Lightless Mother", 0.0, "hover", 50, [use("eclipse", 3), use("distortion", 2), use("void_embrace", 2), use("mothers_wail", 2), use("darkness_veil", 1)],
              mechanics=[shelters("Lantern", 5, 20, 200, 5.0)], announce="Come into the dark, little ones."),
    ],
}
DOC["nyxara"] = ("NYXARA, THE LIGHTLESS MOTHER", "Black Trench. A darkness-and-illusion fight; light is the resource.",
  ["Veil (100-70%): darkness fills the arena. Lanterns (right-click) are your only safe light. Shadows and a sweeping gaze.",
   "Mother of Mirrors (70-35%): she is shielded by three Shadow Anchors (the illusions); break them, then keep a Lantern lit for Eclipse (lethal in the dark).",
   "Lightless Mother (35-0%): constant Eclipse, environment-bending currents, Void Embrace. Light is everything."])

# ------------------------------------------------------------------ OROVAX
BOSSES["orovax"] = {
    "id": "orovax", "name": "Orovax, the Tidal Colossus", "color": "#f97316", "accent": "LAVA", "bar-color": "RED",
    "base-health": 5000, "speed": 0.0, "enrage-seconds": 1000, "arena-radius": 80,
    "intro": "The seabed itself stands up.", "defeat": "The colossus crumbles into the vents that made it.",
    "attacks": {
        "colossus_stomp": A("slam", telegraph=40, radius=12, damage=21, center="self", knockback=1.8),
        "tremor": A("shockwave", telegraph=34, speed=0.7, max_radius=38, height=3.0, thickness=3.0, damage=18),
        "magma_lines": A("rupture", telegraph=42, lines=6, length=42, width=3.0, damage=17),
        "geyser_pull": A("pull", duration=80, radius=32, strength=0.10, damage=10, inner=5),
        "eruption": A("slam", telegraph=92, radius=34, damage=14, center="self", lethal=True, sheltered_damage=6, knockback=2.0),
        "tremor_chain": A("shockwave", telegraph=44, speed=0.9, max_radius=42, height=3.5, thickness=3.0, damage=20, rings=3, ring_gap=16),
    },
    "phases": [
        phase("Awakened Stone", 0.66, "static", 85, [use("colossus_stomp", 3), use("tremor", 3), use("magma_lines", 2)], announce=None),
        phase("Coral Carapace", 0.33, "static", 70, [use("tremor", 2), use("geyser_pull", 2), use("colossus_stomp", 2), use("magma_lines", 2)],
              mechanics=[nodes("Carapace Plate", 4, 9, 240, around="boss", respawn=True, window=200, mult=2.2, msg="The carapace splits. Hit the exposed stone.")],
              announce="Stone. Coral. Fire."),
        phase("Eruption", 0.0, "static", 55, [use("eruption", 2), use("tremor_chain", 3), use("magma_lines", 2), use("colossus_stomp", 2)],
              mechanics=[shelters("Obsidian Shell", 4, 22, 150, 4.5)], announce="The vents open."),
    ],
}
DOC["orovax"] = ("OROVAX, THE TIDAL COLOSSUS", "Volcanic Expanse arena. A slow, heavy, environment-driven fight.",
  ["Awakened Stone (100-66%): stomps, ground-hugging shockwaves, magma lines across the floor.",
   "Coral Carapace (66-33%): four Carapace Plates shield him; breaking them opens a 10s x2.2 window, then regrows.",
   "Eruption (33-0%): Obsidian Shells (right-click to brace) are the only cover from Eruption (lethal). Triple tremor rings."])

# ------------------------------------------------------------------ REGIONAL BOSSES
def simple(id, name, color, accent, hp, movement, attacks, phases, doc, mechanics=None, bar="WHITE", speed=0.5, arena=60, intro=None, defeat=None):
    BOSSES[id] = {"id": id, "name": name, "color": color, "accent": accent, "bar-color": bar, "base-health": hp, "speed": speed,
                  "enrage-seconds": 600, "arena-radius": arena, "intro": intro or "", "defeat": defeat or "", "attacks": attacks, "phases": phases}
    DOC[id] = (name.upper(), doc[0], doc[1])

simple("drowned_admiral", "Drowned Admiral", "#34d399", "SOUL", 1800, "chase", {
    "ghostly_broadside": A("rupture", telegraph=34, lines=5, length=30, width=3.0, damage=13),
    "anchor_hook": A("grab", telegraph=28, count=1, hold=90, dps=2, crush=12, **{"break": 60}, pull=True),
    "spectral_crew": A("summon", telegraph=26, mob="admiral_crew", count=3, radius=12),
    "cutlass_arc": A("cone", telegraph=22, range=10, angle=130, damage=12)},
    [phase("Captain", 0.5, "chase", 75, [use("cutlass_arc", 3), use("anchor_hook", 2), use("spectral_crew", 1)]),
     phase("Doomed Fleet", 0.0, "chase", 60, [use("ghostly_broadside", 3), use("anchor_hook", 2), use("cutlass_arc", 2), use("spectral_crew", 1)],
           announce="All hands. All hands!")],
    ("Forgotten Waters / Ghost Fleet. Roaming guardian of the ghost ships.", ["Phase 1 close-quarters cone and anchor hook that drags a diver in; phase 2 adds broadsides across the water and a ghostly crew."]),
    bar="GREEN", arena=60)

simple("the_lightless", "The Lightless", "#0f172a", "LARGE_SMOKE", 2200, "hover", {
    "dark_pulse": A("roar", telegraph=26, radius=22, damage=10, knockback=1.4, slow=40),
    "lightless_charge": A("charge", telegraph=34, distance=34, speed=1.2, width=4.0, damage=18),
    "blackout": A("darkness", telegraph=16, duration=160, radius=30)},
    [phase("Stalking", 0.5, "hover", 80, [use("blackout", 2), use("lightless_charge", 3), use("dark_pulse", 2)]),
     phase("Hunting", 0.0, "chase", 60, [use("lightless_charge", 3), use("dark_pulse", 2), use("blackout", 2)], announce=None)],
    ("Black Trench regional boss. Hunts in total darkness.", ["Blacks out the arena then charges from the dark; pulses push divers off."]),
    bar="PURPLE", arena=60)

simple("coral_colossus", "Coral Colossus", "#fb7185", "BUBBLE_POP", 2400, "static", {
    "coral_slam": A("slam", telegraph=36, radius=9, damage=16, center="self", knockback=1.5),
    "spore_burst": A("roar", telegraph=30, radius=18, damage=8, knockback=1.2, slow=60),
    "root_lines": A("rupture", telegraph=38, lines=6, length=26, width=2.5, damage=14)},
    [phase("Grown", 0.5, "static", 80, [use("coral_slam", 3), use("spore_burst", 2), use("root_lines", 2)],
           mechanics=[nodes("Coral Heart", 3, 12, 120, around="boss", respawn=True, window=140, mult=2.0, msg="The hearts burst. It is open.")]),
     phase("Overgrowth", 0.0, "static", 60, [use("root_lines", 3), use("coral_slam", 2), use("spore_burst", 2)])],
    ("Verdant Reef regional boss. A walking reef.", ["Shielded by three Coral Hearts (window when broken); root lines cross the floor."]),
    bar="PINK", arena=55)

simple("vesper_the_pale", "Vesper, the Pale", "#bae6fd", "SNOWFLAKE", 2600, "hover", {
    "frost_breath": A("cone", telegraph=30, range=22, angle=90, damage=13, slow=60),
    "ice_spikes": A("rupture", telegraph=36, lines=7, length=32, width=2.5, damage=15),
    "whiteout": A("current", duration=100, radius=34, strength=0.10, damage=2),
    "glacial_crash": A("slam", telegraph=44, radius=11, damage=20, center="target", knockback=1.4, slow=40)},
    [phase("Pale", 0.5, "hover", 75, [use("frost_breath", 3), use("ice_spikes", 3), use("glacial_crash", 2)]),
     phase("Blizzard", 0.0, "hover", 55, [use("whiteout", 2), use("ice_spikes", 3), use("frost_breath", 2), use("glacial_crash", 2)], announce=None)],
    ("Frozen Abyss regional boss. Slows and shatters.", ["Frost cone and spikes; below 50% a whiteout current pushes divers around the cavern."]),
    bar="WHITE", arena=60)

# mini-bosses (structure guardians / roaming rares)
simple("abyssal_stalker_alpha", "Abyssal Stalker Alpha", "#0ea5e9", "SQUID_INK", 900, "chase", {
    "lunge": A("charge", telegraph=24, distance=24, speed=1.3, width=3.0, damage=14),
    "shriek": A("roar", telegraph=22, radius=16, damage=7, knockback=1.2, slow=40)},
    [phase("Alpha", 0.0, "chase", 60, [use("lunge", 3), use("shriek", 1)])], ("Roaming mini-boss in the Black Trench.", ["Fast lunges from the dark."]), arena=45)
simple("reef_breaker", "Reef Breaker", "#f43f5e", "BUBBLE_POP", 1000, "chase", {
    "claw_slam": A("slam", telegraph=26, radius=6, damage=14, center="target"),
    "shell_charge": A("charge", telegraph=28, distance=20, speed=1.1, width=3.5, damage=15)},
    [phase("Breaker", 0.0, "chase", 65, [use("claw_slam", 3), use("shell_charge", 2)])], ("Mini-boss that wrecks reef structures (not your builds).", ["Slams and shell charges."]), arena=45)
simple("siren_matriarch", "Siren Matriarch", "#a78bfa", "GLOW", 1100, "hover", {
    "lure_song": A("pull", duration=60, radius=24, strength=0.07, damage=5, inner=4),
    "call_of_the_deep": A("summon", telegraph=24, mob="siren_thrall", count=3, radius=12),
    "shriek": A("roar", telegraph=24, radius=18, damage=8, knockback=1.2, slow=40)},
    [phase("Matriarch", 0.0, "hover", 70, [use("lure_song", 2), use("call_of_the_deep", 2), use("shriek", 2)])], ("Mini-boss. Lures divers with song.", ["Pulls divers in and summons thralls."]), arena=45)
simple("shipwreck_guardian", "Shipwreck Guardian", "#94a3b8", "SOUL", 1300, "static", {
    "anchor_slam": A("slam", telegraph=34, radius=9, damage=16, center="self"),
    "bilge_wave": A("shockwave", telegraph=30, speed=0.7, max_radius=26, height=3, thickness=2.5, damage=13)},
    [phase("Guardian", 0.0, "static", 75, [use("anchor_slam", 3), use("bilge_wave", 2)])], ("Structure guardian of sunken ships.", ["Slams and shockwaves while you loot."]), arena=40)
simple("deepwater_devourer", "Deepwater Devourer", "#1d4ed8", "SQUID_INK", 1500, "chase", {
    "gulp": A("pull", duration=60, radius=22, strength=0.10, damage=8, inner=4, finisher=True),
    "maw_charge": A("charge", telegraph=26, distance=26, speed=1.2, width=4.0, damage=17)},
    [phase("Devourer", 0.0, "chase", 65, [use("maw_charge", 3), use("gulp", 2)])], ("Rare roaming mini-boss.", ["Gulp pull with a bite at the center."]), arena=50)
simple("ancient_shellback", "Ancient Shellback", "#84cc16", "BUBBLE_POP", 1400, "static", {
    "shell_slam": A("slam", telegraph=34, radius=8, damage=15, center="self"),
    "tremor": A("shockwave", telegraph=30, speed=0.6, max_radius=22, height=3, thickness=2.5, damage=12)},
    [phase("Ancient", 0.0, "static", 80, [use("shell_slam", 3), use("tremor", 2)])], ("Neutral giant that fights only when provoked.", ["Slow heavy slams."]), arena=40)

# ---------------------------------------------------------------- write
for bid, data in BOSSES.items():
    with open(os.path.join(OUT, bid + ".yml"), "w") as f:
        f.write("# Generated by tools/gen_bosses.py. Edit that script, or edit this file directly on a live server.\n")
        yaml.safe_dump(data, f, sort_keys=False, width=140)

with open(os.path.join(ROOT, "BOSSES.md"), "w") as f:
    f.write("# Boss Designs\n\nAll numbers are first-pass and untested. Boss behaviour is driven by the plugin's boss engine (data in `bosses/*.yml`).\n"
            "Models and animations come from ModelEngine; sound events are listed in BOSS_AUDIO.md.\n\n")
    for bid, (title, blurb, lines) in DOC.items():
        f.write(f"## {title}\n*{blurb}*\n\n")
        for l in lines: f.write(f"- {l}\n")
        d = BOSSES[bid]
        f.write(f"\nBase health {d['base-health']} (at 4 players), enrage {d['enrage-seconds']}s, VFX colour {d['color']} + {d['accent']}.\n\n")

with open(os.path.join(ROOT, "BOSS_AUDIO.md"), "w") as f:
    f.write("# Boss Sound Events (all need .ogg files + sounds.json entries)\n\nPattern: des_sea:boss.<boss>.<event>\n\n")
    for bid, d in BOSSES.items():
        evs = ["intro", "defeat", "enrage"] + [f"phase{i+1}" for i in range(len(d['phases']))]
        for n in d["attacks"]: evs += [n + ".windup", n + ".strike"]
        f.write(f"## {bid}\n" + ", ".join(evs) + "\n\n")
print("wrote", len(BOSSES), "bosses")
