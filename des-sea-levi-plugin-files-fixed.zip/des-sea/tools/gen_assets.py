#!/usr/bin/env python3
"""Generates the COMPLETE DeS Sea resource pack and datapack from code.
Run from the project root:  python3 tools/gen_assets.py [--pack-format N]
Outputs: resourcepack/ , datapack/ , and (zipped) build/des_sea_resourcepack.zip + build/des_sea_datapack.zip
Needs: Pillow, numpy, scipy, PyYAML, ffmpeg (with libvorbis)."""
import argparse, json, os, shutil, subprocess, sys, zipfile
import yaml
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import tex, aud, mdl

ap = argparse.ArgumentParser(); ap.add_argument("--pack-format", type=int, default=75, help="PLACEHOLDER: set to your client version's resource pack format")
args = ap.parse_args()

RP = os.path.join(ROOT, "resourcepack"); DP = os.path.join(ROOT, "datapack"); BUILD = os.path.join(ROOT, "build")
for d in (RP, DP): shutil.rmtree(d, ignore_errors=True)
os.makedirs(BUILD, exist_ok=True)
A = lambda *p: os.path.join(RP, "assets", *p)
def wj(path, obj): os.makedirs(os.path.dirname(path), exist_ok=True); json.dump(obj, open(path, "w"), indent=1)
def wp(path, im): os.makedirs(os.path.dirname(path), exist_ok=True); im.save(path)
def item_def(rel, model): wj(A("des_sea", "items", rel + ".json"), {"model": {"type": "minecraft:model", "model": model}})

# ---------------------------------------------------------------- 1. block models/blockstates/item defs (reuses build_pack.py)
subprocess.run([sys.executable, os.path.join(HERE, "build_pack.py"), "--pack-format", str(args.pack_format), "--out", os.path.join(BUILD, "bp")], check=True, stdout=subprocess.DEVNULL)
shutil.copytree(os.path.join(BUILD, "bp", "resourcepack", "assets"), os.path.join(RP, "assets"))
blocks = yaml.safe_load(open(os.path.join(ROOT, "src/main/resources/blocks.yml")))["blocks"]

# ---------------------------------------------------------------- 2. textures
n = 0
for i, (bid, (kind, a, b, c)) in enumerate(tex.CUBE_SPECS.items()):
    wp(A("des_sea", "textures", "block", bid + ".png"), tex.block_tex(kind, a, b, c, i + 11)); n += 1
for i, (bid, (kind, c1, c2, g)) in enumerate(tex.PLANT_SPECS.items()):
    wp(A("des_sea", "textures", "block", bid + ".png"), tex.plant_tex(kind, c1, c2, g, i + 5)); n += 1
assert all(os.path.exists(A("des_sea", "textures", "block", b + ".png")) for b in blocks), "a block has no texture"

# items (ItemManager)
for iid, (shape, c1, c2) in tex.ITEM_SPECS.items():
    wp(A("des_sea", "textures", "item", iid + ".png"), tex.icon(shape, c1, c2, hash(iid) % 1000)); n += 1
    wj(A("des_sea", "models", "item", iid + ".json"), {"parent": "minecraft:item/generated", "textures": {"layer0": f"des_sea:item/{iid}"}})
    item_def("item/" + iid, f"des_sea:item/{iid}")
cfg_items = yaml.safe_load(open(os.path.join(ROOT, "src/main/resources/config.yml")))["items"]
missing_items = [k for k in cfg_items if k not in tex.ITEM_SPECS]
assert not missing_items, f"config items with no icon: {missing_items}"

# journal UI
CATS = ["biome", "creature", "boss_encountered", "boss_defeated", "structure", "blueprint", "recipe", "artifact", "fishing", "secret", "location"]
ui = {"entry_unknown": tex.glyph("unknown", "#9ca3af"), "prev": tex.glyph("prev", "#e5e7eb", "#1f2937"), "next": tex.glyph("next", "#e5e7eb", "#1f2937")}
for c in CATS:
    ui["entry_" + c] = tex.glyph(c, "#67e8f9", "#0f172a"); ui["tab_" + c] = tex.glyph(c, "#f8fafc", "#164e63")
for name, im in ui.items():
    wp(A("des_sea", "textures", "ui", name + ".png"), im); n += 1
    wj(A("des_sea", "models", "ui", name + ".json"), {"parent": "minecraft:item/generated", "textures": {"layer0": f"des_sea:ui/{name}"}})
    item_def("ui/" + name, f"des_sea:ui/{name}")

# vehicles
PAINT = {"motorboat": ("#7c2d12", "#c2410c", "#fde68a"), "jet_boat": ("#0c4a6e", "#0ea5e9", "#e0f2fe"), "racing_jet_boat": ("#7f1d1d", "#ef4444", "#fef08a"),
         "mini_submarine": ("#a16207", "#facc15", "#1e293b"), "deep_sea_submersible": ("#1e293b", "#475569", "#38bdf8"), "ghost_vessel": ("#334155", "#94a3b8", "#a7f3d0")}
trim = tex.block_tex("iron", "#27272a", "#52525b", "#71717a", 3)
glass = tex.Image.new("RGBA", (32, 32), (120, 200, 235, 140))
wp(A("des_sea", "textures", "vehicle", "trim.png"), trim); wp(A("des_sea", "textures", "vehicle", "glass.png"), glass)
for vid, els in mdl.vehicles().items():
    wp(A("des_sea", "textures", "vehicle", vid + ".png"), tex.paint(*PAINT[vid], 5)); n += 1
    texs = {"0": f"des_sea:vehicle/{vid}", "1": "des_sea:vehicle/trim", "2": "des_sea:vehicle/glass", "particle": f"des_sea:vehicle/{vid}"}
    wj(A("des_sea", "models", "vehicle", vid + ".json"), mdl.model(els, texs))
    wj(A("des_sea", "models", "item", f"vehicle_{vid}.json"), {"parent": f"des_sea:vehicle/{vid}"})
    item_def("vehicle/" + vid, f"des_sea:vehicle/{vid}"); item_def(f"item/vehicle_{vid}", f"des_sea:item/vehicle_{vid}")

# bosses: node/shelter parts
boss_defs = {}
for f in sorted(os.listdir(os.path.join(ROOT, "src/main/resources/bosses"))):
    d = yaml.safe_load(open(os.path.join(ROOT, "src/main/resources/bosses", f))); boss_defs[d["id"]] = d
node, shelter, active = mdl.boss_parts()
for i, (bid, d) in enumerate(boss_defs.items()):
    col = d["color"]
    for part, els, kind in (("node", node, "node"), ("shelter", shelter, "shelter"), ("shelter_active", active, "active")):
        wp(A("des_sea", "textures", "boss", f"{bid}_{part}.png"), tex.part_tex(col, kind, i + 40)); n += 1
        texs = {"0": f"des_sea:boss/{bid}_{part}", "1": f"des_sea:boss/{bid}_shelter_active", "particle": f"des_sea:boss/{bid}_{part}"}
        wj(A("des_sea", "models", "boss", f"{bid}_{part}.json"), mdl.model(els, texs))
        item_def(f"boss/{bid}_{part}", f"des_sea:boss/{bid}_{part}")

# levi shadow
wp(A("des_sea", "textures", "event", "levi_shadow.png"), tex.shadow_tex())
wj(A("des_sea", "models", "event", "levi_shadow.json"), mdl.model(mdl.levi_shadow(), {"0": "des_sea:event/levi_shadow", "particle": "des_sea:event/levi_shadow"}))
item_def("event/levi_shadow", "des_sea:event/levi_shadow")
print("textures:", n)

# ---------------------------------------------------------------- 3. sounds
SND = A("des_sea", "sounds"); sj = {}
def S(path, x, q=3): aud.save_ogg(os.path.join(SND, path + ".ogg"), x, q)
BIOMES = ["crystal_depths", "black_trench", "verdant_reef", "volcanic_expanse", "forgotten_waters", "frozen_abyss", "drowned_kingdom", "luminous_wilds"]
cnt = 0
for b in BIOMES:
    S(f"ambient/{b}", aud.ambient(b), 2); S(f"ambient/{b}_mood", aud.mood(b), 2); cnt += 2
    sj[f"ambient.{b}.mood"] = {"sounds": [{"name": f"des_sea:ambient/{b}_mood", "stream": True, "attenuation_distance": 24}]}
ev = aud.event_sounds()
for k, v in ev.items(): S(k, v); cnt += 1
sj["event.crystal_surge.pulse"] = {"sounds": [{"name": "des_sea:event/crystal_surge_pulse", "attenuation_distance": 48}]}
sj["event.abyssal_storm.rumble"] = {"sounds": [{"name": "des_sea:event/abyssal_storm_rumble", "attenuation_distance": 48}]}
sj["event.blood_tide.pulse"] = {"sounds": [{"name": "des_sea:event/blood_tide_pulse", "attenuation_distance": 48}]}
sj["event.volcanic_awakening.eruption"] = {"sounds": [{"name": "des_sea:event/volcanic_eruption", "attenuation_distance": 96}]}
sj["event.silent_waters.breath"] = {"sounds": [{"name": "des_sea:event/silent_waters_breath"}]}
for k, v in aud.levi_steps().items():
    S(k, v); cnt += 1; step = k.split("step")[1]
    sj[f"levi.awaken.step{step}"] = {"sounds": [{"name": f"des_sea:{k}", "attenuation_distance": 160}]}
for k, v in aud.vehicle_sounds().items():
    S(k, v, 2); cnt += 1; vid = k.split("/")[1]
    sj[f"vehicle.{vid}.engine"] = {"sounds": [{"name": f"des_sea:{k}", "attenuation_distance": 32}]}
classes = aud.boss_classes()
for k, v in classes.items(): S("boss/class/" + k, v); cnt += 1
for boss in boss_defs:
    for kind in ("intro", "defeat", "phase", "enrage"):
        S(f"boss/voice/{boss}_{kind}", aud.voice(boss, kind)); cnt += 1
    d = boss_defs[boss]; pitch_scale = max(0.6, min(1.35, 1.35 - d["base-health"] / 7500))   # bigger bosses sound lower
    V = lambda kind: {"name": f"des_sea:boss/voice/{boss}_{kind}", "attenuation_distance": 160}
    sj[f"boss.{boss}.intro"] = {"sounds": [V("intro")]}; sj[f"boss.{boss}.defeat"] = {"sounds": [V("defeat")]}
    sj[f"boss.{boss}.enrage"] = {"sounds": [V("enrage")]}
    for i in range(len(d["phases"])): sj[f"boss.{boss}.phase{i + 1}"] = {"sounds": [V("phase")]}
    sj[f"boss.{boss}.window"] = {"sounds": [{"name": "des_sea:boss/class/window_open", "pitch": pitch_scale, "attenuation_distance": 96}]}
    sj[f"boss.{boss}.shelter"] = {"sounds": [{"name": "des_sea:boss/class/shelter_activate", "pitch": 1.0, "attenuation_distance": 48}]}
    for an, ad in d["attacks"].items():
        w, st = aud.attack_class(ad["type"])
        sj[f"boss.{boss}.{an}.windup"] = {"sounds": [{"name": f"des_sea:boss/class/{w}", "pitch": round(pitch_scale, 2), "attenuation_distance": 128}]}
        sj[f"boss.{boss}.{an}.strike"] = {"sounds": [{"name": f"des_sea:boss/class/{st}", "pitch": round(pitch_scale, 2), "attenuation_distance": 128}]}
wj(A("des_sea", "sounds.json"), sj)
print("sound files:", cnt, "sound events:", len(sj))

# ---------------------------------------------------------------- 4. pack.mcmeta + datapack
wj(os.path.join(RP, "pack.mcmeta"), {"pack": {"pack_format": args.pack_format, "description": "DeS Sea expansion assets (merge into the DeS pack)"}})
BIO = {  # fog, water, water_fog, sky
 "crystal_depths": (0x0b1c4a, 0x1d5fb4, 0x0a2c6b, 0x0b1c4a), "black_trench": (0x03050c, 0x0a1224, 0x02040a, 0x03050c),
 "verdant_reef": (0x0e5a52, 0x1fa28a, 0x0c6d5e, 0x0e5a52), "volcanic_expanse": (0x3a0f0a, 0x7a2a12, 0x2a0b07, 0x3a0f0a),
 "forgotten_waters": (0x1d2c2c, 0x3e5f5a, 0x16231f, 0x1d2c2c), "frozen_abyss": (0x4a7ba8, 0x93c5e8, 0x3a6a95, 0x4a7ba8),
 "drowned_kingdom": (0x123a40, 0x2c7a80, 0x0e2b30, 0x123a40), "luminous_wilds": (0x0b3b2c, 0x14a67a, 0x0a4a37, 0x0b3b2c)}
for b, (fog, water, wfog, sky) in BIO.items():
    wj(os.path.join(DP, "data", "des_sea", "worldgen", "biome", b + ".json"), {
        "has_precipitation": False, "temperature": 0.5, "downfall": 0.5,
        "effects": {"fog_color": fog, "water_color": water, "water_fog_color": wfog, "sky_color": sky,
                    "mood_sound": {"sound": f"des_sea:ambient.{b}.mood", "tick_delay": 6000, "block_search_extent": 8, "offset": 2.0}},
        "spawners": {k: [] for k in ("monster", "creature", "ambient", "axolotls", "underground_water_creature", "water_creature", "water_ambient", "misc")},
        "spawn_costs": {}, "carvers": [], "features": [[] for _ in range(11)]})
wj(os.path.join(DP, "pack.mcmeta"), {"pack": {"pack_format": args.pack_format, "description": "DeS Sea worldgen"}})

# ---------------------------------------------------------------- 5. zip
def zipdir(src, dst):
    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as z:
        for r, _, fs in os.walk(src):
            for f in fs: p = os.path.join(r, f); z.write(p, os.path.relpath(p, src))
zipdir(RP, os.path.join(BUILD, "des_sea_resourcepack.zip")); zipdir(DP, os.path.join(BUILD, "des_sea_datapack.zip"))
shutil.rmtree(os.path.join(BUILD, "bp"), ignore_errors=True)
print("done:", {f: os.path.getsize(os.path.join(BUILD, f)) // 1024 for f in os.listdir(BUILD)}, "KB")
