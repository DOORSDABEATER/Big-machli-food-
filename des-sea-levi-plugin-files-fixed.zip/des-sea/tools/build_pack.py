#!/usr/bin/env python3
"""Builds resource-pack assets from src/main/resources/blocks.yml and the datapack skeleton.
Usage: build_pack.py --pack-format N [--out build/]
Writes models, block item definitions and carrier blockstates (note_block + coral carriers). Needs PyYAML.
MERGE the output into your existing DeS pack; `minecraft/blockstates/*.json` REPLACE vanilla files of the same name."""
import argparse, json, os, yaml

INSTRUMENTS = ["harp","basedrum","snare","hat","bass","flute","bell","guitar","chime","xylophone","iron_xylophone","cow_bell",
               "didgeridoo","bit","banjo","pling","zombie","skeleton","creeper","dragon","wither_skeleton","piglin","custom_head"]

ap = argparse.ArgumentParser()
ap.add_argument("--pack-format", required=True, type=int)
ap.add_argument("--out", default="build")
a = ap.parse_args()

here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
blocks = yaml.safe_load(open(os.path.join(here, "src/main/resources/blocks.yml")))["blocks"]
out = a.out
assets = os.path.join(out, "resourcepack", "assets")
def mk(*p):
    d = os.path.join(assets, *p); os.makedirs(d, exist_ok=True); return d

def wjson(path, obj):
    with open(path, "w") as f: json.dump(obj, f, indent=2)

missing = []
note_map, coral_files = {}, {}
for bid, b in blocks.items():
    parent, tex = ("minecraft:block/cube_all", "all") if b["kind"] == "cube" else ("minecraft:block/cross", "cross")
    wjson(os.path.join(mk("des_sea", "models", "block"), bid + ".json"), {"parent": parent, "textures": {tex: f"des_sea:block/{bid}"}})
    wjson(os.path.join(mk("des_sea", "items", "block"), bid + ".json"), {"model": {"type": "minecraft:model", "model": f"des_sea:block/{bid}"}})
    mk("des_sea", "textures", "block")
    if not os.path.exists(os.path.join(here, "pack-src/assets/textures/block", bid + ".png")): missing.append(bid + ".png")
    if b["kind"] == "cube":
        props = dict(p.split("=") for p in b["state"].split(","))
        note_map[(props["instrument"], props["note"], props["powered"])] = bid
    else:
        coral_files[b["material"].lower()] = bid

# note_block: every vanilla state keeps the vanilla model unless it is one of ours
variants = {}
for ins in INSTRUMENTS:
    for n in range(25):
        for pw in ("false", "true"):
            key = f"instrument={ins},note={n},powered={pw}"
            bid = note_map.get((ins, str(n), pw))
            variants[key] = {"model": f"des_sea:block/{bid}" if bid else "minecraft:block/note_block"}
wjson(os.path.join(mk("minecraft", "blockstates"), "note_block.json"), {"variants": variants})
# coral carriers: a single model for every state (waterlogged or not)
for coral, bid in coral_files.items():
    wjson(os.path.join(mk("minecraft", "blockstates"), coral + ".json"), {"variants": {"": {"model": f"des_sea:block/{bid}"}}})

wjson(os.path.join(out, "resourcepack", "pack.mcmeta"), {"pack": {"pack_format": a.pack_format, "description": "des_sea assets (merge into DeS pack)"}})
os.makedirs(os.path.join(out, "datapack"), exist_ok=True)
wjson(os.path.join(out, "datapack", "pack.mcmeta"), {"pack": {"pack_format": a.pack_format, "description": "DeS Sea worldgen"}})
print("Wrote", out, f"({len(blocks)} blocks)")
if missing:
    print("MISSING ART (shows the missing-texture pattern until supplied):")
    for m in missing: print("  pack-src/assets/textures/block/" + m)
