"""Archetype model builders + animation generators (ModelEngine-ready skeletons).
Orientation: model front is -Z (north), up is +Y. Bone origins are absolute pivots; every chain is authored straight and animated by rotation."""
import math
from bbm import Model

def P(body, belly=None, fin=None, accent=None, glow="#67e8f9", eye="#05060a", shell=None, bone="#d8d4c4", armor=None, cloth=None):
    d = {"body": body, "belly": belly or body, "fin": fin or body, "accent": accent or body, "glow": glow, "eye": eye, "shell": shell or body, "bone": bone, "tooth": bone,
         "armor": armor or shell or body, "cloth": cloth or body, "hitbox": body}
    return d

def box(m, bone, cx, cy, cz, sx, sy, sz, role="body", rot=(0, 0, 0), origin=None, name=None):
    return m.cube(bone, (cx - sx / 2, cy - sy / 2, cz - sz / 2), (cx + sx / 2, cy + sy / 2, cz + sz / 2), role, rot, origin, name)

def hitbox(m, w, h, l, cy=0):
    m.bone("hitbox", "root", (0, 0, 0)); box(m, "hitbox", 0, cy, 0, w, h, l, "hitbox")

def eyes(m, bone, x, y, z, s=2.0, role="eye", n=("l", "r")):
    for side, sx in zip(n, (1, -1)): box(m, bone, sx * x, y, z, s, s, s * 0.6, role)

def lerp(a, b, t): return a + (b - a) * t

# =============================================================== SERPENT / WHALE
def serpent(mid, pal, segs=8, seglen=14, w=(10, 22, 6), h=(10, 20, 6), head_len=20, headw=1.0, crown=0, spikes=True, glow_marks=True, fins=0, flukes=False,
            flippers=False, jaw_open_teeth=6, eyes_glow=True, uv=1.0, pattern="scales", seed=1, whale=False, big_eyes=False):
    m = Model(mid, pal, uv, seed, pattern); m.bone("root")
    names = []
    prof = lambda i, a: lerp(a[0], a[1], min(1, i / (segs * 0.3))) if i < segs * 0.3 else lerp(a[1], a[2], (i - segs * 0.3) / (segs * 0.7 + 1e-6))
    yc = 0
    for i in range(segs):
        z0 = i * seglen; n = f"seg{i}"; names.append(n)
        m.bone(n, names[-2] if i else "root", (0, yc, z0))
        wi, hi = prof(i, w), prof(i, h)
        box(m, n, 0, yc, z0 + seglen / 2, wi, hi, seglen + 0.6, "body")
        box(m, n, 0, yc - hi * 0.32, z0 + seglen / 2, wi * 0.92, hi * 0.4, seglen + 0.6, "belly")
        if spikes and i % 2 == 0 and i < segs - 1: box(m, n, 0, yc + hi / 2 + 1.6, z0 + seglen / 2, 1.6, 3.4, 3.2, "bone", (20, 0, 0))
        if glow_marks and i % 2 == 1:
            for sx in (1, -1): box(m, n, sx * (wi / 2 + 0.1), yc + hi * 0.15, z0 + seglen / 2, 0.8, 1.6, seglen * 0.55, "glow")
        if fins and i > 1 and i % fins == 0 and not whale:
            for sx in (1, -1): box(m, n, sx * (wi / 2 + 3), yc - hi * 0.1, z0 + seglen / 2, 6, 1.2, 6, "fin", (0, 0, sx * -14))
    # head
    m.bone("head", "seg0", (0, yc, 0))
    hw, hh = w[0] * 1.15 * headw, h[0] * 1.05
    box(m, "head", 0, yc + hh * 0.05, -head_len * 0.45, hw, hh * 0.78, head_len * 0.9, "body")
    box(m, "head", 0, yc - hh * 0.05, -head_len - 1, hw * 0.78, hh * 0.5, head_len * 0.25, "body")
    box(m, "head", 0, yc + hh * 0.38, -head_len * 0.3, hw * 0.55, hh * 0.3, head_len * 0.6, "armor")
    es = 2.4 if not big_eyes else 4.5
    for sx in (1, -1): box(m, "head", sx * (hw / 2 + 0.2), yc + hh * 0.25, -head_len * 0.55, es * 0.6, es, es, "eye" if not eyes_glow else "eye")
    m.bone("jaw", "head", (0, yc - hh * 0.15, -head_len * 0.15))
    box(m, "jaw", 0, yc - hh * 0.35, -head_len * 0.5, hw * 0.8, hh * 0.28, head_len * 0.85, "belly")
    for k in range(jaw_open_teeth):
        z = -head_len * 0.15 - k * (head_len * 0.8 / max(1, jaw_open_teeth))
        for sx in (1, -1):
            box(m, "jaw", sx * hw * 0.34, yc - hh * 0.2, z, 1.2, 3.0, 1.2, "tooth"); box(m, "head", sx * hw * 0.34, yc - hh * 0.2, z + 0.5, 1.2, 3.0, 1.2, "tooth")
    if crown:
        m.bone("crown", "head", (0, yc + hh * 0.5, -head_len * 0.3))
        for k in range(crown):
            ang = math.pi * (k / max(1, crown - 1) - 0.5) * 1.15
            box(m, "crown", math.sin(ang) * hw * 0.5, yc + hh * 0.5 + 4, -head_len * 0.25 - abs(math.sin(ang)) * 2, 2.2, 8 + 2 * math.cos(ang), 2.2, "bone", (0, 0, -math.degrees(ang) * 0.6))
    if whale or flippers:
        for side, sx in (("l", 1), ("r", -1)):
            m.bone(f"flip_{side}", "seg1", (sx * w[1] / 2, yc - h[1] * 0.25, 1 * seglen + seglen / 2))
            box(m, f"flip_{side}", sx * (w[1] / 2 + 8), yc - h[1] * 0.3, seglen * 1.5, 16, 2.4, 9, "fin", (0, 0, sx * -20))
    if flukes:
        last = names[-1]; zt = segs * seglen
        m.bone("fluke", last, (0, yc, zt))
        for sx in (1, -1): box(m, "fluke", sx * 10, yc, zt + 5, 20, 2.2, 10, "fin", (0, sx * -14, 0))
        box(m, "fluke", 0, yc, zt + 3, 6, 4, 8, "body")
    hitbox(m, w[1] * 0.9, h[1] * 0.9, segs * seglen * 0.5, 0); m.by_name["hitbox"]
    m.meta = dict(kind="serpent", chain=names, head="head", jaw="jaw", arms=[[f"flip_{s}"] for s in "lr"] if (whale or flippers) else [], tentacles=[], body="seg0",
                  eyes=[], tail=["fluke"] if flukes else [], whale=whale, segs=segs)
    return m

# =============================================================== FISH
def fish(mid, pal, L=14, W=6, H=8, tail=2, dorsal=1.0, predator=False, lure=False, longfins=False, glow_dots=False, uv=1.0, pattern="scales", seed=2, shark=False):
    m = Model(mid, pal, uv, seed, pattern); m.bone("root"); m.bone("body", "root", (0, 0, 0))
    box(m, "body", 0, 0, 0, W, H, L, "body"); box(m, "body", 0, -H * 0.3, 0, W * 0.9, H * 0.4, L * 0.95, "belly")
    box(m, "body", 0, H * 0.05, -L / 2 - L * 0.12, W * 0.8, H * 0.8, L * 0.25, "body"); box(m, "body", 0, -H * 0.05, -L / 2 - L * 0.28, W * 0.5, H * 0.5, L * 0.18, "body")
    eyes(m, "body", W * 0.42, H * 0.18, -L / 2 - L * 0.08, max(1.6, W * 0.28))
    m.bone("jaw", "body", (0, -H * 0.2, -L / 2 - L * 0.1))
    box(m, "jaw", 0, -H * 0.3, -L / 2 - L * 0.22, W * 0.5, H * 0.18, L * 0.22, "belly")
    if predator:
        for k in range(4):
            for sx in (1, -1): box(m, "jaw", sx * W * 0.2, -H * 0.18, -L / 2 - L * (0.12 + 0.05 * k), 0.9, 2.2, 0.9, "tooth"); box(m, "body", sx * W * 0.2, -H * 0.1, -L / 2 - L * (0.12 + 0.05 * k), 0.9, 2.2, 0.9, "tooth")
    tl = L * 0.35; names = ["body"]
    m.bone("tail0", "body", (0, 0, L / 2)); box(m, "tail0", 0, 0, L / 2 + tl / 2, W * 0.7, H * 0.7, tl, "body"); names.append("tail0")
    m.bone("tail1", "tail0", (0, 0, L / 2 + tl)); box(m, "tail1", 0, 0, L / 2 + tl + tl / 2, W * 0.4, H * 0.45, tl, "body"); names.append("tail1")
    m.bone("tailfin", "tail1", (0, 0, L / 2 + tl * 2)); box(m, "tailfin", 0, 0, L / 2 + tl * 2 + tl * 0.45, 1.2, H * (1.5 if not shark else 1.9), tl * 0.9, "fin"); names.append("tailfin")
    m.bone("dorsal", "body", (0, H / 2, 0)); box(m, "dorsal", 0, H / 2 + H * 0.35 * dorsal, L * 0.05, 1.2, H * 0.8 * dorsal, L * 0.35, "fin", (-12, 0, 0))
    fl = 1.7 if longfins else 1.0
    for side, sx in (("l", 1), ("r", -1)):
        m.bone(f"pec_{side}", "body", (sx * W / 2, -H * 0.2, -L * 0.15)); box(m, f"pec_{side}", sx * (W / 2 + L * 0.18 * fl), -H * 0.25, -L * 0.1, L * 0.36 * fl, 0.9, L * 0.28, "fin", (0, sx * -20, sx * -12))
    if glow_dots:
        for k in range(4): box(m, "body", 0, H * 0.3, -L * 0.3 + k * L * 0.2, 1.0, 1.0, 1.0, "glow")
    if lure:
        m.bone("lure0", "body", (0, H / 2, -L / 2)); box(m, "lure0", 0, H / 2 + 3, -L / 2 - 2, 0.8, 7, 0.8, "bone", (-30, 0, 0))
        m.bone("lure1", "lure0", (0, H / 2 + 6, -L / 2 - 5)); box(m, "lure1", 0, H / 2 + 7.5, -L / 2 - 7, 2.6, 2.6, 2.6, "glow")
    hitbox(m, W * 1.1, H * 1.1, L * 1.2)
    m.meta = dict(kind="fish", chain=names, head="body", jaw="jaw", arms=[["pec_l"], ["pec_r"]], tentacles=[["lure0", "lure1"]] if lure else [], body="body", eyes=[], tail=[])
    return m

# =============================================================== RAY
def ray(mid, pal, span=16, L=12, T=3, tail=5, spikes=False, glowtips=False, bolts=False, uv=1.0, pattern="spots", seed=3):
    m = Model(mid, pal, uv, seed, pattern); m.bone("root"); m.bone("body", "root", (0, 0, 0))
    box(m, "body", 0, 0, 0, span * 0.34, T, L, "body"); box(m, "body", 0, -T * 0.35, 0, span * 0.3, T * 0.4, L * 0.9, "belly")
    box(m, "body", 0, 0, -L * 0.55, span * 0.2, T * 0.8, L * 0.25, "body"); eyes(m, "body", span * 0.07, T * 0.55, -L * 0.45, 1.8)
    box(m, "body", 0, -T * 0.4, -L * 0.62, span * 0.1, 0.8, 1.6, "tooth")
    wings = [[], []]
    for wi, (side, sx) in enumerate((("l", 1), ("r", -1))):
        prev = "body"; x = span * 0.17
        for j in range(3):
            n = f"wing_{side}{j}"; m.bone(n, prev, (sx * x, 0, 0)); ww = span * (0.2 - 0.04 * j)
            box(m, n, sx * (x + ww / 2), 0, L * (0.02 + 0.06 * j), ww, 0.9 + (2 - j) * 0.3, L * (0.9 - 0.2 * j), "fin" if j else "body")
            if glowtips and j == 2: box(m, n, sx * (x + ww), 0, L * 0.2, 1.4, 1.4, 4, "glow")
            if bolts and j == 1: box(m, n, sx * (x + ww * 0.5), 1.5, L * 0.1, 0.9, 2.8, 0.9, "glow", (0, 0, sx * 25))
            wings[wi].append(n); prev = n; x += ww
    tl = ["tail0", "tail1", "tail2", "tail3"]; prev = "body"
    for j, n in enumerate(tl):
        z = L / 2 + j * tail; m.bone(n, prev, (0, 0, z)); box(m, n, 0, 0, z + tail / 2, max(0.9, 2.2 - j * 0.45), max(0.9, 1.6 - j * 0.3), tail + 0.3, "body"); prev = n
    if spikes:
        for k in range(5): box(m, "body", 0, T / 2 + 1.5, -L * 0.3 + k * L * 0.18, 1.2, 3.6, 1.2, "bone", (10, 0, 0))
    box(m, "tail3", 0, 0, L / 2 + 4 * tail + 1.5, 1.0, 1.0, 5, "glow" if glowtips or bolts else "bone")
    hitbox(m, span * 0.7, T * 2, L * 1.3)
    m.meta = dict(kind="ray", chain=tl, head="body", jaw=None, arms=wings, tentacles=[], body="body", eyes=[], tail=tl)
    return m

# =============================================================== JELLY
def jelly(mid, pal, R=10, tents=8, tlen=18, arms=4, uv=1.0, seed=4, spikes=False):
    m = Model(mid, pal, uv, seed, "plain"); m.bone("root"); m.bone("bell", "root", (0, 0, 0))
    for k, (s, hh, y) in enumerate(((2.0, 3.0, 0), (1.7, 4.0, 3), (1.25, 4.0, 7), (0.75, 2.5, 10.5))): box(m, "bell", 0, y + hh / 2, 0, R * s, hh, R * s, "body" if k else "accent")
    box(m, "bell", 0, 4, 0, R * 0.7, R * 0.7, R * 0.7, "glow")
    if spikes:
        for k in range(8): a = k * math.pi / 4; box(m, "bell", math.cos(a) * R, 1, math.sin(a) * R, 1.4, 4, 1.4, "glow", (0, 0, 0))
    chains = []
    for i in range(arms):
        a = i * 2 * math.pi / arms + 0.4; x, z = math.cos(a) * R * 0.45, math.sin(a) * R * 0.45; ch = []; prev = "bell"
        for j in range(4):
            n = f"arm{i}_{j}"; y0 = -j * 5; m.bone(n, prev, (x, y0, z)); box(m, n, x, y0 - 2.5, z, 3.2 - j * 0.5, 5.2, 3.2 - j * 0.5, "belly"); ch.append(n); prev = n
        chains.append(ch)
    for i in range(tents):
        a = i * 2 * math.pi / tents; x, z = math.cos(a) * R * 0.85, math.sin(a) * R * 0.85; ch = []; prev = "bell"
        for j in range(5):
            n = f"tent{i}_{j}"; y0 = -j * (tlen / 5); m.bone(n, prev, (x, y0, z)); box(m, n, x, y0 - tlen / 10, z, 1.0, tlen / 5 + 0.4, 1.0, "glow" if j == 4 else "fin"); ch.append(n); prev = n
        chains.append(ch)
    hitbox(m, R * 2, R * 3, R * 2, -4)
    m.meta = dict(kind="jelly", chain=["bell"], head="bell", jaw=None, arms=[], tentacles=chains, body="bell", eyes=[], tail=[])
    return m

# =============================================================== TURTLE
def turtle(mid, pal, L=22, W=18, H=8, head=6, extra=None, uv=1.0, pattern="scales", seed=5):
    m = Model(mid, pal, uv, seed, pattern); m.bone("root"); m.bone("shell", "root", (0, 0, 0))
    box(m, "shell", 0, 0, 0, W, H * 0.45, L, "belly"); box(m, "shell", 0, H * 0.4, 0, W * 0.92, H * 0.55, L * 0.92, "shell"); box(m, "shell", 0, H * 0.78, 0, W * 0.64, H * 0.4, L * 0.64, "armor")
    for k in range(3):
        for sx in (-1, 1): box(m, "shell", sx * W * 0.22, H * 1.0, -L * 0.2 + k * L * 0.2, W * 0.2, 0.9, L * 0.17, "accent")
    box(m, "shell", 0, H * 1.0, 0, W * 0.2, 0.9, L * 0.55, "accent")
    m.bone("neck0", "shell", (0, H * 0.2, -L / 2)); box(m, "neck0", 0, H * 0.2, -L / 2 - head * 0.5, head * 0.7, head * 0.6, head, "body")
    m.bone("head", "neck0", (0, H * 0.2, -L / 2 - head)); box(m, "head", 0, H * 0.25, -L / 2 - head * 1.5, head, head * 0.8, head * 1.1, "body"); eyes(m, "head", head * 0.46, H * 0.4, -L / 2 - head * 1.6, 1.4)
    m.bone("jaw", "head", (0, H * 0.1, -L / 2 - head * 1.2)); box(m, "jaw", 0, H * 0.02, -L / 2 - head * 1.6, head * 0.7, head * 0.2, head * 0.7, "belly"); box(m, "head", 0, H * 0.22, -L / 2 - head * 2.0, head * 0.5, head * 0.3, head * 0.3, "tooth")
    arms = []; legs = []
    for side, sx in (("l", 1), ("r", -1)):
        m.bone(f"flip_f{side}0", "shell", (sx * W / 2, -H * 0.05, -L * 0.28)); box(m, f"flip_f{side}0", sx * (W / 2 + 4), -H * 0.1, -L * 0.28, 8, 2.2, 5, "fin", (0, 0, sx * -10))
        m.bone(f"flip_f{side}1", f"flip_f{side}0", (sx * (W / 2 + 8), -H * 0.1, -L * 0.28)); box(m, f"flip_f{side}1", sx * (W / 2 + 12), -H * 0.12, -L * 0.28, 8, 1.6, 4, "fin"); arms.append([f"flip_f{side}0", f"flip_f{side}1"])
        m.bone(f"flip_b{side}", "shell", (sx * W * 0.4, -H * 0.05, L * 0.35)); box(m, f"flip_b{side}", sx * (W * 0.4 + 3), -H * 0.1, L * 0.38, 6, 1.8, 5, "fin"); legs.append([f"flip_b{side}"])
    m.bone("tail", "shell", (0, 0, L / 2)); box(m, "tail", 0, -H * 0.05, L / 2 + 3, 2.2, 1.6, 6, "body")
    if extra:
        for e in extra(m): pass
    hitbox(m, W * 1.1, H * 1.6, L * 1.3, H * 0.3)
    m.meta = dict(kind="turtle", chain=["neck0", "head"], head="head", jaw="jaw", arms=arms, legs=legs, tentacles=[], body="shell", eyes=[], tail=["tail"])
    return m

# =============================================================== CRAB
def crab(mid, pal, W=14, L=10, H=4, claw=1.0, blades=False, uv=1.0, pattern="spots", seed=6):
    m = Model(mid, pal, uv, seed, pattern); m.bone("root"); m.bone("body", "root", (0, 0, 0))
    box(m, "body", 0, 0, 0, W, H, L, "body"); box(m, "body", 0, H * 0.45, 0, W * 0.85, H * 0.5, L * 0.85, "armor"); box(m, "body", 0, -H * 0.35, 0, W * 0.8, H * 0.35, L * 0.8, "belly")
    for k in range(5 if blades else 2): box(m, "body", 0, H * 0.9 + 1, -L * 0.3 + k * L * 0.16, 1.0, 3.5 if blades else 1.5, 1.2, "bone" if blades else "accent", (12, 0, 0))
    for side, sx in (("l", 1), ("r", -1)):
        m.bone(f"eyestalk_{side}", "body", (sx * W * 0.2, H / 2, -L / 2)); box(m, f"eyestalk_{side}", sx * W * 0.2, H / 2 + 1.5, -L / 2 - 0.5, 0.9, 3, 0.9, "body"); box(m, f"eyestalk_{side}", sx * W * 0.2, H / 2 + 3.4, -L / 2 - 0.5, 1.8, 1.8, 1.8, "eye")
    legs = []
    for side, sx in (("l", 1), ("r", -1)):
        for i in range(3):
            z = -L * 0.2 + i * L * 0.28; a, b = f"leg_{side}{i}_0", f"leg_{side}{i}_1"
            m.bone(a, "body", (sx * W / 2, 0, z)); box(m, a, sx * (W / 2 + 2.5), -0.5, z, 5, 1.1, 1.1, "body", (0, 0, sx * -14))
            m.bone(b, a, (sx * (W / 2 + 5), -1, z)); box(m, b, sx * (W / 2 + 7), -3.2, z, 1.1, 5, 1.1, "body", (0, 0, sx * 14)); legs.append([a, b])
    arms = []
    for side, sx in (("l", 1), ("r", -1)):
        a0, a1, pt, pb = f"arm_{side}0", f"arm_{side}1", f"pinch_t{side}", f"pinch_b{side}"
        c = claw
        m.bone(a0, "body", (sx * W / 2, 0, -L * 0.4)); box(m, a0, sx * (W / 2 + 3 * c), 0, -L * 0.45, 6 * c, 2 * c, 2 * c, "body")
        m.bone(a1, a0, (sx * (W / 2 + 6 * c), 0, -L * 0.45)); box(m, a1, sx * (W / 2 + 8 * c), 0, -L * 0.7, 3 * c, 3 * c, 6 * c, "armor")
        m.bone(pt, a1, (sx * (W / 2 + 8 * c), 1 * c, -L * 0.95)); box(m, pt, sx * (W / 2 + 8 * c), 1.6 * c, -L * 0.95 - 3 * c, 1.6 * c, 1.2 * c, 6 * c, "bone")
        m.bone(pb, a1, (sx * (W / 2 + 8 * c), -0.5 * c, -L * 0.95)); box(m, pb, sx * (W / 2 + 8 * c), -1 * c, -L * 0.95 - 3 * c, 1.6 * c, 1.2 * c, 6 * c, "bone")
        arms.append([a0, a1, pt, pb])
    hitbox(m, W * 1.4, H * 3, L * 1.6, 1)
    m.meta = dict(kind="crab", chain=["body"], head="body", jaw=None, arms=arms, legs=legs, tentacles=[], body="body", eyes=[], tail=[])
    return m

# =============================================================== SNAIL
def snail(mid, pal, L=10, W=5, H=3, uv=1.0, seed=7):
    m = Model(mid, pal, uv, seed, "plain"); m.bone("root"); m.bone("foot", "root", (0, 0, 0))
    box(m, "foot", 0, 0, 0, W, H, L, "body"); box(m, "foot", 0, -H * 0.4, 0, W * 0.9, H * 0.3, L, "belly")
    m.bone("head", "foot", (0, H / 2, -L / 2)); box(m, "head", 0, H * 0.7, -L / 2 - 1.5, W * 0.8, H * 0.9, 3.2, "body")
    for side, sx in (("l", 1), ("r", -1)):
        m.bone(f"eye_{side}0", "head", (sx * W * 0.25, H, -L / 2 - 1.5)); box(m, f"eye_{side}0", sx * W * 0.25, H + 2, -L / 2 - 1.8, 0.8, 4, 0.8, "body", (-14, 0, 0))
        m.bone(f"eye_{side}1", f"eye_{side}0", (sx * W * 0.25, H + 4, -L / 2 - 2.5)); box(m, f"eye_{side}1", sx * W * 0.25, H + 4.8, -L / 2 - 2.8, 1.6, 1.6, 1.6, "eye")
    m.bone("shell", "foot", (0, H / 2, L * 0.1))
    for k, (s, y, dz) in enumerate(((6, 3, 0), (5, 6.2, 0.6), (3.8, 8.8, 1.2), (2.4, 10.8, 1.6))): box(m, "shell", 0, H / 2 + y, L * 0.1 + dz, s, 3.4, s * 1.1, "shell" if k % 2 == 0 else "armor", (0, 14 * k, 0))
    box(m, "shell", 0, H / 2 + 4, L * 0.1 - 3.4, 2.2, 2.2, 1.0, "glow")
    hitbox(m, W * 1.4, 11, L * 1.2, 4)
    m.meta = dict(kind="snail", chain=["foot", "head"], head="head", jaw=None, arms=[], tentacles=[["eye_l0", "eye_l1"], ["eye_r0", "eye_r1"]], body="foot", eyes=[], tail=[])
    return m

# =============================================================== HUMANOID
def humanoid(mid, pal, s=1.0, bulk=1.0, lanky=False, crown=None, hat=False, hood=False, cloak=0, tail=False, shoulders=False, scepter=False, glow_eyes=True,
             horns=False, fins=False, uv=1.0, pattern="plain", seed=8, arm_len=1.0, ribs=False):
    m = Model(mid, pal, uv, seed, pattern); m.bone("root")
    leg = 12 * s * (1.25 if lanky else 1); tor = 14 * s * (1.2 if lanky else 1); bw = 9 * s * bulk; bd = 5 * s * bulk; al = 12 * s * arm_len * (1.5 if lanky else 1)
    m.bone("body", "root", (0, leg, 0)); box(m, "body", 0, leg + 1.5 * s, 0, bw * 0.95, 4 * s, bd * 0.95, "cloth")
    m.bone("torso", "body", (0, leg + 3 * s, 0)); box(m, "torso", 0, leg + 3 * s + tor / 2, 0, bw, tor, bd, "body"); box(m, "torso", 0, leg + 3 * s + tor / 2, -bd / 2 - 0.2, bw * 0.6, tor * 0.7, 0.8, "belly")
    if ribs:
        for k in range(4): box(m, "torso", 0, leg + 6 * s + k * 2.4 * s, -bd / 2 - 0.5, bw * 0.8, 0.9, 0.9, "bone")
    if shoulders:
        for sx in (1, -1): box(m, "torso", sx * (bw / 2 + 1.5 * s), leg + 3 * s + tor - 1, 0, 5 * s * bulk, 4 * s, 7 * s * bulk, "armor", (0, 0, sx * -10))
    hy = leg + 3 * s + tor
    m.bone("head", "torso", (0, hy, 0)); hs = 7.5 * s * (0.8 if lanky else 1)
    box(m, "head", 0, hy + hs / 2, 0, hs, hs, hs, "body"); box(m, "head", 0, hy + hs * 0.3, -hs / 2 - 0.3, hs * 0.7, hs * 0.3, 0.8, "belly")
    for sx in (1, -1): box(m, "head", sx * hs * 0.24, hy + hs * 0.58, -hs / 2 - 0.4, hs * 0.2, hs * 0.14, 0.7, "eye" if glow_eyes else "eye")
    if crown:
        m.bone("crown", "head", (0, hy + hs, 0)); box(m, "crown", 0, hy + hs + 0.8, 0, hs * 1.05, 1.6, hs * 1.05, crown)
        for k in range(5): a = k * math.pi / 2.5; box(m, "crown", math.cos(a) * hs * 0.46, hy + hs + 3.2, math.sin(a) * hs * 0.46, 1.4, 3.6, 1.4, crown)
    if hat:
        m.bone("hat", "head", (0, hy + hs, 0)); box(m, "hat", 0, hy + hs + 1, 0, hs * 1.5, 1.2, hs * 1.5, "cloth"); box(m, "hat", 0, hy + hs + 3.4, 0, hs * 1.0, 4, hs * 0.95, "cloth")
    if hood:
        box(m, "head", 0, hy + hs * 0.55, hs * 0.15, hs * 1.25, hs * 1.3, hs * 1.15, "cloth")
    if horns:
        for sx in (1, -1): box(m, "head", sx * hs * 0.5, hy + hs + 3, 0, 1.6, 7, 1.6, "bone", (0, 0, sx * -22))
    arms = []
    for side, sx in (("l", 1), ("r", -1)):
        a0, a1 = f"arm_{side}0", f"arm_{side}1"; ax = sx * (bw / 2 + 1.8 * s * bulk); ay = hy - 2
        m.bone(a0, "torso", (ax, ay, 0)); box(m, a0, ax, ay - al * 0.25, 0, 3.6 * s * bulk, al * 0.5, 3.6 * s * bulk, "body")
        m.bone(a1, a0, (ax, ay - al * 0.5, 0)); box(m, a1, ax, ay - al * 0.75, 0, 3.2 * s * bulk, al * 0.5, 3.2 * s * bulk, "body"); box(m, a1, ax, ay - al - 0.8, 0, 3.8 * s * bulk, 2.2, 3.8 * s * bulk, "bone" if not fins else "fin")
        arms.append([a0, a1])
    if scepter:
        box(m, "arm_l1", bw / 2 + 1.8 * s, hy - al - 8, -3, 1.2, 22, 1.2, "bone"); box(m, "arm_l1", bw / 2 + 1.8 * s, hy - al + 4, -3, 3.2, 3.2, 3.2, "glow")
    legs = []
    if tail:
        prev = "body"
        for j in range(4):
            n = f"tail{j}"; y0 = leg - j * 4 * s; m.bone(n, prev, (0, y0 + 2, 0)); box(m, n, 0, y0 - 1, 0.5, bw * (0.85 - 0.15 * j), 5 * s, 6 * s, "body"); prev = n
        box(m, "tail3", 0, leg - 14 * s, 0.5, 1.2, 8 * s, 8 * s, "fin")
        legs = [["tail0", "tail1", "tail2", "tail3"]]
    else:
        for side, sx in (("l", 1), ("r", -1)):
            l0, l1 = f"leg_{side}0", f"leg_{side}1"; lx = sx * bw * 0.25
            m.bone(l0, "body", (lx, leg, 0)); box(m, l0, lx, leg * 0.75, 0, 4 * s * bulk, leg * 0.5, 4 * s * bulk, "cloth")
            m.bone(l1, l0, (lx, leg * 0.5, 0)); box(m, l1, lx, leg * 0.25, 0, 3.6 * s * bulk, leg * 0.5, 3.6 * s * bulk, "cloth"); box(m, l1, lx, 0.8, -1.4, 4 * s * bulk, 1.6, 6 * s, "armor")
            legs.append([l0, l1])
    prevc = "torso"
    for j in range(cloak):
        n = f"cloak{j}"; y0 = hy - 2 - j * (tor / (cloak + 0.5)); m.bone(n, prevc, (0, y0, bd / 2)); box(m, n, 0, y0 - tor / (cloak + 0.5) / 2, bd / 2 + 1.2 + j * 0.6, bw * (1.15 + 0.12 * j), tor / (cloak + 0.5) + 0.6, 1.2, "cloth"); prevc = n
    if fins:
        for sx in (1, -1): box(m, "head", sx * hs * 0.62, hy + hs * 0.5, 0, 0.8, hs * 0.7, hs * 0.6, "fin", (0, sx * 20, 0))
    hitbox(m, bw * 1.2, leg + tor + hs, bw * 1.2, (leg + tor + hs) / 2)
    m.meta = dict(kind="humanoid", chain=["body", "torso", "head"], head="head", jaw=None, arms=arms, legs=legs, tentacles=[[f"cloak{j}" for j in range(cloak)]] if cloak else [], body="body", eyes=[], tail=[f"tail{j}" for j in range(4)] if tail else [])
    return m

# =============================================================== KRAKEN
def kraken(mid, pal, R=26, tents=8, segs=6, tlen=16, uv=2.0, seed=9, eyes_n=2):
    m = Model(mid, pal, uv, seed, "spots"); m.bone("root"); m.bone("mantle", "root", (0, 0, 0))
    for k, (s, hh, y) in enumerate(((1.6, 8, 0), (1.45, 10, 8), (1.15, 10, 18), (0.7, 7, 28))): box(m, "mantle", 0, y + hh / 2, 6, R * s, hh, R * s * 1.15, "body" if k % 2 == 0 else "armor")
    box(m, "mantle", 0, 14, 4 + R * 0.7, R * 0.9, 12, 4, "belly")
    for sx in (1, -1): box(m, "mantle", sx * R * 0.55, 10, -R * 0.78, 7, 7, 3, "eye")
    m.bone("beak", "mantle", (0, 2, -R * 0.55)); box(m, "beak", 0, 0, -R * 0.62, 8, 3, 8, "bone"); box(m, "beak", 0, 3, -R * 0.62, 7, 3, 7, "bone", (-20, 0, 0))
    chains = []
    for i in range(tents):
        ang = 360.0 * i / tents; rad = math.radians(ang); bx, bz = math.cos(rad) * R * 0.6, math.sin(rad) * R * 0.6; ch = []; prev = "mantle"
        for j in range(segs):
            n = f"tent{i}_{j}"; z0 = j * tlen; w = max(2.4, 9 - j * 1.3)
            if j == 0: m.bone(n, prev, (bx, 1, bz), (0, -ang + 90, 0))
            else: m.bone(n, prev, (bx, 1, bz - j * tlen + tlen))      # straight chain along -Z in absolute space; the first bone's rest yaw swings the whole arm
            box(m, n, bx, 1, bz - j * tlen - tlen / 2, w, w * 0.9, tlen + 0.6, "body" if j % 2 == 0 else "armor")
            if j >= 1: box(m, n, bx, 1 - w * 0.5 - 0.3, bz - j * tlen - tlen / 2, w * 0.6, 0.8, tlen * 0.8, "belly")
            ch.append(n); prev = n
    # note: chain bones after the first inherit the first bone's yaw
        chains.append(ch)
    hitbox(m, R * 1.8, R * 1.2, R * 1.8, 14)
    m.meta = dict(kind="kraken", chain=["mantle"], head="mantle", jaw="beak", arms=[], tentacles=chains, body="mantle", eyes=[], tail=[])
    return m

# =============================================================== FLOATING HORRORS
def watcher(mid, pal, R=12, tents=6, tl=20, uv=1.0, seed=10):
    m = Model(mid, pal, uv, seed, "plain"); m.bone("root"); m.bone("core", "root", (0, 0, 0))
    for k, s in enumerate((1.0, 0.85, 0.65)): box(m, "core", 0, 0, 0, R * 2 * s, R * 2 * s, R * 2 * s, "body", (0, 45 * k, 45 * k))
    box(m, "core", 0, 0, -R - 0.4, R * 1.3, R * 1.3, 1.4, "belly"); box(m, "core", 0, 0, -R - 1.2, R * 0.7, R * 0.7, 1.4, "glow"); box(m, "core", 0, 0, -R - 1.9, R * 0.28, R * 0.45, 1.0, "eye")
    m.bone("lid_top", "core", (0, R * 0.65, -R)); box(m, "lid_top", 0, R * 0.8, -R - 0.8, R * 1.5, 2.2, R * 0.5, "armor"); m.bone("lid_bot", "core", (0, -R * 0.65, -R)); box(m, "lid_bot", 0, -R * 0.8, -R - 0.8, R * 1.5, 2.2, R * 0.5, "armor")
    chains = []
    for i in range(tents):
        a = i * 2 * math.pi / tents; x, z = math.cos(a) * R * 0.7, math.sin(a) * R * 0.7 + R * 0.4; ch = []; prev = "core"
        for j in range(4):
            n = f"tent{i}_{j}"; y0 = -R * 0.5 - j * tl / 4; m.bone(n, prev, (x, y0, z)); box(m, n, x, y0 - tl / 8, z, 2.6 - j * 0.45, tl / 4 + 0.5, 2.6 - j * 0.45, "fin"); ch.append(n); prev = n
        box(m, ch[-1], x, -R * 0.5 - tl - 0.5, z, 2, 2, 2, "glow"); chains.append(ch)
    hitbox(m, R * 2.2, R * 3.5, R * 2.2, -R * 0.4)
    m.meta = dict(kind="floating", chain=["core"], head="core", jaw=None, arms=[], tentacles=chains, body="core", eyes=["lid_top", "lid_bot"], tail=[], lids=["lid_top", "lid_bot"])
    return m

def maw(mid, pal, W=22, L=34, teeth=7, uv=1.0, seed=11):
    m = Model(mid, pal, uv, seed, "scales"); m.bone("root"); m.bone("upper", "root", (0, 0, 0))
    box(m, "upper", 0, 4, 0, W, 10, L, "body"); box(m, "upper", 0, 9.5, 2, W * 0.8, 4, L * 0.7, "armor")
    for sx in (1, -1): box(m, "upper", sx * W * 0.32, 9, -L * 0.35, 4.6, 4.6, 3, "eye"); box(m, "upper", sx * W * 0.2, 11, -L * 0.1, 3, 3, 2, "glow")
    m.bone("lower", "upper", (0, 0, L / 2)); box(m, "lower", 0, -2, 0, W * 0.9, 5, L * 0.95, "belly"); box(m, "lower", 0, -4.5, -L * 0.1, W * 0.6, 2, L * 0.7, "tooth")
    for k in range(teeth):
        z = -L / 2 + 2 + k * (L - 6) / max(1, teeth - 1)
        for sx in (1, -1): box(m, "upper", sx * (W / 2 - 1.2), -2.5, z, 2.0, 7, 2.0, "tooth", (0, 0, sx * 6)); box(m, "lower", sx * (W / 2 - 2), 2.5, z, 2.0, 7, 2.0, "tooth", (0, 0, sx * -6))
    prev = "upper"; names = []
    for j in range(3):
        n = f"tail{j}"; z = L / 2 + j * 12; m.bone(n, prev, (0, 4, z)); box(m, n, 0, 4, z + 6, W * (0.7 - 0.2 * j), 8 - 2 * j, 12.6, "body"); names.append(n); prev = n
    m.bone("lure0", "upper", (0, 10, -L / 2)); box(m, "lure0", 0, 14, -L / 2 - 4, 1, 10, 1, "bone", (-35, 0, 0)); m.bone("lure1", "lure0", (0, 18, -L / 2 - 10)); box(m, "lure1", 0, 19, -L / 2 - 11, 4, 4, 4, "glow")
    hitbox(m, W * 1.1, 16, L * 1.6, 2)
    m.meta = dict(kind="maw", chain=["upper"] + names, head="upper", jaw="lower", arms=[], tentacles=[["lure0", "lure1"]], body="upper", eyes=[], tail=names)
    return m

def nyxara(mid, pal, uv=2.0, seed=12):
    m = Model(mid, pal, uv, seed, "plain"); m.bone("root"); m.bone("body", "root", (0, 6, 0))
    for k, (w, h, y) in enumerate(((16, 12, 6), (13, 12, 18), (10, 10, 30), (8, 8, 40))): box(m, "body", 0, y + h / 2, 0, w, h, w * 0.7, "body" if k % 2 == 0 else "cloth")
    m.bone("head", "body", (0, 46, 0)); box(m, "head", 0, 50, 0, 9, 9, 8, "body")
    for sx in (1, -1): box(m, "head", sx * 2.2, 51, -4.3, 2.0, 1.4, 0.8, "glow")
    box(m, "head", 0, 55, -3, 3, 3, 0.8, "glow")
    for k, (x, y, z, sz) in enumerate(((-6.5, 53, -2, 1.6), (6.5, 53, -2, 1.6), (-5, 56, 1, 1.4), (5, 56, 1, 1.4))): box(m, "head", x, y, z, sz, sz, sz, "eye")
    m.bone("crown", "head", (0, 54, 0))
    for k in range(7): a = (k / 6 - 0.5) * math.pi * 1.2; box(m, "crown", math.sin(a) * 5.5, 57 + 3 * math.cos(a), 0, 1.8, 8 + 3 * math.cos(a), 1.8, "bone", (0, 0, -math.degrees(a) * 0.7))
    arms = []
    for side, sx in (("l", 1), ("r", -1)):
        prev = "body"; ch = []
        for j in range(3):
            n = f"arm_{side}{j}"; y0 = 40 - j * 10; m.bone(n, prev, (sx * (8 + j * 3), y0, 0)); box(m, n, sx * (10 + j * 3.2), y0 - 5, -1, 3 - j * 0.6, 10.6, 3 - j * 0.6, "cloth"); ch.append(n); prev = n
        box(m, ch[-1], sx * 17, 17, -1, 2, 4, 1.4, "glow"); arms.append(ch)
    veils = []
    for i in range(6):
        a = i * math.pi / 3; x, z = math.cos(a) * 7, math.sin(a) * 6; prev = "body"; ch = []
        for j in range(4):
            n = f"veil{i}_{j}"; y0 = 8 - j * 9; m.bone(n, prev, (x, y0, z)); box(m, n, x, y0 - 4.5, z, 5 - j * 0.9, 9.5, 0.9, "cloth" if j % 2 else "fin"); ch.append(n); prev = n
        veils.append(ch)
    for i in range(4):
        a = (i + 0.5) * math.pi / 2 + 0.7; x, z = math.cos(a) * 6, math.sin(a) * 6 + 3; prev = "body"; ch = []
        for j in range(4):
            n = f"tendril{i}_{j}"; zz = z + j * 9; m.bone(n, prev, (x, 24, zz)); box(m, n, x, 24, zz + 4.5, 2.4 - j * 0.4, 2.4 - j * 0.4, 9.6, "body"); ch.append(n); prev = n
        box(m, ch[-1], x, 24, z + 38, 2.2, 2.2, 2.2, "glow"); veils.append(ch)
    hitbox(m, 18, 56, 14, 28)
    m.meta = dict(kind="floating", chain=["body", "head"], head="head", jaw=None, arms=arms, tentacles=veils, body="body", eyes=[], tail=[])
    return m

def stalker(mid, pal, s=1.0, uv=1.0, seed=13):
    m = Model(mid, pal, uv, seed, "scales"); m.bone("root"); legh = 22 * s
    m.bone("body", "root", (0, legh, 0)); box(m, "body", 0, legh, 0, 9 * s, 9 * s, 22 * s, "body"); box(m, "body", 0, legh - 3 * s, 0, 8 * s, 3 * s, 20 * s, "belly")
    for k in range(5): box(m, "body", 0, legh + 5.5 * s, -8 * s + k * 4 * s, 1.2 * s, 5 * s, 1.4 * s, "bone", (14, 0, 0))
    m.bone("neck", "body", (0, legh + 1 * s, -11 * s)); box(m, "neck", 0, legh + 3 * s, -16 * s, 4 * s, 4 * s, 9 * s, "body", (-12, 0, 0))
    m.bone("head", "neck", (0, legh + 4 * s, -20 * s)); box(m, "head", 0, legh + 4 * s, -25 * s, 6 * s, 5 * s, 11 * s, "body")
    for sx in (1, -1): box(m, "head", sx * 2.6 * s, legh + 5.6 * s, -23 * s, 1.6 * s, 1.8 * s, 1.4 * s, "glow")
    m.bone("jaw", "head", (0, legh + 3 * s, -22 * s)); box(m, "jaw", 0, legh + 1.6 * s, -27 * s, 4.6 * s, 1.6 * s, 9 * s, "belly")
    for k in range(5):
        for sx in (1, -1): box(m, "jaw", sx * 1.8 * s, legh + 3 * s, -22 * s - k * 2 * s, 0.7 * s, 2.2 * s, 0.7 * s, "tooth")
    legs = []
    for side, sx in (("l", 1), ("r", -1)):
        for i, z in enumerate((-7 * s, 8 * s)):
            a, b, c = f"leg_{side}{i}_0", f"leg_{side}{i}_1", f"leg_{side}{i}_2"
            m.bone(a, "body", (sx * 5 * s, legh, z)); box(m, a, sx * 8 * s, legh + 2 * s, z, 8 * s, 1.8 * s, 1.8 * s, "body", (0, 0, sx * 28))
            m.bone(b, a, (sx * 11 * s, legh + 4 * s, z)); box(m, b, sx * 12 * s, legh * 0.45, z, 1.6 * s, legh * 0.8, 1.6 * s, "body", (0, 0, sx * -8))
            m.bone(c, b, (sx * 13 * s, 2, z)); box(m, c, sx * 13.4 * s, 1.2, z - 1.4 * s, 1.6 * s, 1.4 * s, 4.5 * s, "bone"); legs.append([a, b, c])
    names = []; prev = "body"
    for j in range(3):
        n = f"tail{j}"; z = 11 * s + j * 8 * s; m.bone(n, prev, (0, legh, z)); box(m, n, 0, legh, z + 4 * s, (4 - j) * s, (4 - j) * s, 8.4 * s, "body"); names.append(n); prev = n
    hitbox(m, 14 * s, legh + 10 * s, 30 * s, (legh + 10 * s) / 2)
    m.meta = dict(kind="stalker", chain=["body", "neck", "head"], head="head", jaw="jaw", arms=[], legs=legs, tentacles=[], body="body", eyes=[], tail=names)
    return m
