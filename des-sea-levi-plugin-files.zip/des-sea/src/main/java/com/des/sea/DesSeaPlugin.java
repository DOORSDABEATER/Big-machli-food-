package com.des.sea;

import com.des.sea.command.DesSeaCommand;
import com.des.sea.core.CompatReport;
import com.des.sea.core.ModuleManager;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class DesSeaPlugin extends JavaPlugin {
    private ModuleManager modules;
    private com.des.sea.discovery.DiscoveryManager discovery;
    private com.des.sea.structure.StructureRegistry structures;
    private com.des.sea.event.EventManager events;
    private com.des.sea.boss.LeviEncounter levi;
    private com.des.sea.vehicle.VehicleManager vehicles;
    private com.des.sea.creature.CreatureSpawner creatures;
    private com.des.sea.boss.BossManager bosses;
    private com.des.sea.structure.StructurePlacer placer;
    private com.des.sea.blueprint.BlueprintManager blueprints;
    private com.des.sea.boss.engine.BossEngine engine;
    private com.des.sea.item.ItemManager items;
    private com.des.sea.vent.VentRegistry vents;
    private com.des.sea.block.CustomBlockManager blocks;
    private com.des.sea.terrain.TerrainPopulator terrain;
    private com.des.sea.model.ModelBridge models;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        models = new com.des.sea.model.ModelBridge(this);
        modules = new ModuleManager(this);
        discovery = new com.des.sea.discovery.DiscoveryManager(this);
        structures = new com.des.sea.structure.StructureRegistry(this);
        events = new com.des.sea.event.EventManager(this);
        vents = new com.des.sea.vent.VentRegistry(this);
        events.register(new com.des.sea.event.CrystalSurgeEvent(this));
        events.register(new com.des.sea.event.BloodTideEvent(this));
        events.register(new com.des.sea.event.WhaleMigrationEvent(this));
        events.register(new com.des.sea.event.GreatHuntEvent(this));
        events.register(new com.des.sea.event.VolcanicAwakeningEvent(this));
        events.register(new com.des.sea.event.TempStructureEvent(this, "lost_cargo"));
        events.register(new com.des.sea.event.TempStructureEvent(this, "ghost_fleet"));
        events.register(new com.des.sea.event.AbyssalStormEvent(this));
        events.register(new com.des.sea.event.SilentWatersEvent(this));
        events.register(new com.des.sea.event.LevisShadowEvent(this));
        levi = new com.des.sea.boss.LeviEncounter(this);
        modules.register(discovery);
        modules.register(new com.des.sea.discovery.JournalGui(this));
        engine = new com.des.sea.boss.engine.BossEngine(this);
        items = new com.des.sea.item.ItemManager(this);
        modules.register(engine);
        blocks = new com.des.sea.block.CustomBlockManager(this, new com.des.sea.block.BlockRegistry(this));
        modules.register(blocks);
        terrain = new com.des.sea.terrain.TerrainPopulator(this, blocks.registry());
        modules.register(terrain);
        modules.register(items);
        modules.register(new com.des.sea.behavior.BehaviorManager(this));
        modules.register(levi);
        bosses = new com.des.sea.boss.BossManager(this);
        modules.register(bosses);
        vehicles = new com.des.sea.vehicle.VehicleManager(this);
        modules.register(vehicles);
        modules.register(blueprints);
        creatures = new com.des.sea.creature.CreatureSpawner(this);
        modules.register(creatures);
        placer = new com.des.sea.structure.StructurePlacer(this, structures);
        modules.register(structures);
        blueprints = new com.des.sea.blueprint.BlueprintManager(this);
        modules.register(new com.des.sea.fishing.FishingDiscoveries(this));
        modules.register(events);
        modules.register(new com.des.sea.crystal.CrystalDepthsModule(this));

        PluginCommand cmd = getCommand("dessea");
        if (cmd != null) {
            DesSeaCommand handler = new DesSeaCommand(this);
            cmd.setExecutor(handler);
            cmd.setTabCompleter(handler);
        }

        PluginCommand journal = getCommand("journal");
        if (journal != null) {
            // Default until the journal GUI module takes over the command
            journal.setExecutor((sender, c, l, a) -> { sender.sendMessage("The ocean journal is not available right now."); return true; });
        }

        CompatReport.write(this);
        modules.enableConfigured();
        getLogger().info("DeS Sea foundation loaded. Gameplay modules are disabled until built and tested.");
    }

    @Override
    public void onDisable() {
        if (modules != null) modules.disableAll();
        if (placer != null) placer.shutdown();
        getServer().getScheduler().cancelTasks(this);
    }

    public com.des.sea.discovery.DiscoveryManager discovery() { return discovery; }
    public com.des.sea.structure.StructureRegistry structures() { return structures; }
    public com.des.sea.event.EventManager events() { return events; }

    public com.des.sea.boss.LeviEncounter levi() { return levi; }

    public com.des.sea.vehicle.VehicleManager vehicles() { return vehicles; }

    public com.des.sea.boss.BossManager bosses() { return bosses; }

    public com.des.sea.structure.StructurePlacer placer() { return placer; }

    public com.des.sea.blueprint.BlueprintManager blueprints() { return blueprints; }

    public com.des.sea.boss.engine.BossEngine engine() { return engine; }
    public com.des.sea.item.ItemManager items() { return items; }

    public com.des.sea.vent.VentRegistry vents() { return vents; }

    public com.des.sea.block.CustomBlockManager blocks() { return blocks; }

    public com.des.sea.terrain.TerrainPopulator terrain() { return terrain; }

    public com.des.sea.model.ModelBridge models() { return models; }

    public ModuleManager modules() {
        return modules;
    }

    public void reload() {
        modules.disableAll();
        reloadConfig();
        modules.enableConfigured();
    }

    /** Admin actions are always logged. */
    public void audit(String who, String action) {
        getLogger().info("[AUDIT] " + who + ": " + action);
    }
}
